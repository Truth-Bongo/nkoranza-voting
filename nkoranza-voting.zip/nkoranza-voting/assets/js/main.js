// Main Application Script
import { Auth } from './auth.js';
import { Voting } from './voting.js';

class App {
  static async init() {
    // Check authentication status
    const session = await Auth.checkSession();
    
    // Update UI based on auth status
    this.updateUI(session);
    
    // Initialize event listeners
    this.initEventListeners();
    
    // Load initial data if needed
    if (window.location.pathname.includes('vote')) {
      Voting.loadElections();
    }
  }
  
  static updateUI(session) {
    const loginNav = document.getElementById('login-nav');
    const logoutNav = document.getElementById('logout-nav');
    const adminNav = document.getElementById('admin-nav');
    
    if (session.loggedIn) {
      loginNav?.classList.add('hidden');
      logoutNav?.classList.remove('hidden');
      
      if (session.isAdmin) {
        adminNav?.classList.remove('hidden');
      }
    }
  }
  
  static initEventListeners() {
    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', async () => {
        await Auth.logout();
        window.location.href = '/';
      });
    }
    
    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenuBtn && mobileMenu) {
      mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
      });
    }
  }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => App.init());