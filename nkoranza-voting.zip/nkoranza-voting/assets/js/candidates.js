document.addEventListener("DOMContentLoaded", () => {
    const electionSelect = document.getElementById("election_id");
    const positionSelect = document.getElementById("position_id");
    const candidateForm  = document.getElementById("candidateForm");
    const candidatesTable = document.getElementById("candidatesTableBody");

    // --- Load elections
    function loadElections() {
        fetch("api/voting/elections.php")
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    electionSelect.innerHTML = `<option value="">Select Election</option>`;
                    data.elections.forEach(e => {
                        electionSelect.innerHTML += `<option value="${e.id}">${e.title}</option>`;
                    });
                }
            })
            .catch(err => console.error("Election load error:", err));
    }

    // --- Load positions by election
    function loadPositions(electionId) {
        if (!electionId) {
            positionSelect.innerHTML = `<option value="">Select Position</option>`;
            return;
        }
        fetch(`api/voting/positions.php?election_id=${electionId}`)
            .then(res => res.json())
            .then(data => {
                positionSelect.innerHTML = `<option value="">Select Position</option>`;
                if (data.success) {
                    data.positions.forEach(p => {
                        positionSelect.innerHTML += `<option value="${p.id}">${p.name}</option>`;
                    });
                }
            })
            .catch(err => console.error("Position load error:", err));
    }

    // --- Load candidates list
    function loadCandidates() {
        fetch("api/admin/candidates.php")
            .then(res => res.json())
            .then(data => {
                candidatesTable.innerHTML = "";
                if (data.success && data.candidates.length > 0) {
                    data.candidates.forEach(c => {
                        candidatesTable.innerHTML += `
                            <tr>
                                <td><img src="${c.photo_path ? c.photo_path : 'assets/img/no-photo.png'}" width="50" class="rounded"></td>
                                <td>${c.first_name} ${c.last_name}</td>
                                <td>${c.department}</td>
                                <td>${c.election_title}</td>
                                <td>${c.position_name}</td>
                                <td>${c.manifesto ?? ''}</td>
                                <td>
                                    <button class="btn btn-sm btn-primary edit-btn" data-id="${c.id}">Edit</button>
                                    <button class="btn btn-sm btn-danger delete-btn" data-id="${c.id}">Delete</button>
                                </td>
                            </tr>`;
                    });
                } else {
                    candidatesTable.innerHTML = `<tr><td colspan="7" class="text-center">No candidates found</td></tr>`;
                }
            })
            .catch(err => console.error("Candidate load error:", err));
    }

    // --- Save candidate (insert/update)
    candidateForm.addEventListener("submit", e => {
        e.preventDefault();
        const formData = new FormData(candidateForm);

        fetch("api/admin/candidates.php", {
            method: "POST",
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    candidateForm.reset();
                    loadCandidates();
                }
            })
            .catch(err => {
                console.error("Save error:", err);
                alert("Failed to save candidate");
            });
    });

    // --- Delegate delete & edit actions
    candidatesTable.addEventListener("click", e => {
        if (e.target.classList.contains("delete-btn")) {
            const id = e.target.dataset.id;
            if (!confirm("Are you sure you want to delete this candidate?")) return;

            fetch(`api/admin/candidates.php?id=${id}`, {
                method: "DELETE"
            })
                .then(res => res.json())
                .then(data => {
                    alert(data.message);
                    if (data.success) loadCandidates();
                })
                .catch(err => {
                    console.error("Delete error:", err);
                    alert("Failed to delete candidate");
                });
        }

        if (e.target.classList.contains("edit-btn")) {
            const id = e.target.dataset.id;
            // fetch candidate and populate form for editing
            fetch("api/admin/candidates.php")
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const cand = data.candidates.find(c => c.id == id);
                        if (cand) {
                            document.getElementById("id").value = cand.id;
                            document.getElementById("user_id").value = cand.user_id;
                            electionSelect.value = cand.election_id;
                            loadPositions(cand.election_id);
                            setTimeout(() => {
                                positionSelect.value = cand.position_id;
                            }, 500);
                            document.getElementById("manifesto").value = cand.manifesto;
                        }
                    }
                });
        }
    });

    // --- Event listeners
    electionSelect.addEventListener("change", () => {
        loadPositions(electionSelect.value);
    });

    // init
    loadElections();
    loadCandidates();
});
