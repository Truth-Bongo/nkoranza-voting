// assets/js/auth.js (or inline <script> in login view)
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm') || document.getElementById('login-form') || document.querySelector('form#loginForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    if (btn) { btn.disabled = true; btn.dataset.orig = btn.textContent; btn.textContent = 'Logging in...'; }

    const fd = new FormData(form);
    const payload = {};
    for (const [k,v] of fd.entries()) payload[k] = v;

    try {
      const res = await fetch(`${BASE_URL}/api/auth/login.php`, {
        method: 'POST',
        headers: {
          // don't set content-type so FormData works; if JSON, server handles it
        },
        body: fd
      });
      const data = await res.json();

      if (data.success) {
        // store csrf in a JS global for later API calls
        window.CSRF_TOKEN = data.csrf || window.CSRF_TOKEN;
        // redirect instantly to route returned by server
        window.location.href = data.redirect || `${BASE_URL}/`;
      } else {
        const errEl = document.getElementById('login-error');
        if (errEl) { errEl.textContent = data.message; errEl.classList.remove('hidden'); }
        else alert(data.message || 'Login failed');
      }
    } catch (err) {
      console.error(err);
      alert('Network error. Please try again.');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = btn.dataset.orig || 'Login'; }
    }
  });
});
