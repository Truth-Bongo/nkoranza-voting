class Modal {
    static show(modalId, options = {}) {
        const modal = document.getElementById(modalId);
        if (!modal) return;

        // Set modal content if options provided
        if (options.title) {
            const titleElement = modal.querySelector('.modal-title') || modal.querySelector('h3');
            if (titleElement) titleElement.textContent = options.title;
        }

        if (options.message) {
            const messageElement = modal.querySelector('.modal-message') || modal.querySelector('p');
            if (messageElement) messageElement.textContent = options.message;
        }

        // Show modal
        modal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
    }

    static hide(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        }
    }

    static confirm(options) {
        return new Promise((resolve) => {
            const modal = document.getElementById('confirm-modal');
            if (!modal) return resolve(false);

            // Set title and message
            document.getElementById('confirm-title').textContent = options.title || 'Confirm Action';
            document.getElementById('confirm-message').textContent = options.message || 'Are you sure you want to perform this action?';

            // Set up confirm button
            const confirmBtn = document.getElementById('confirm-action-btn');
            confirmBtn.textContent = options.confirmText || 'Confirm';
            confirmBtn.className = `flex-1 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-${options.danger ? 'red' : 'pink'}-600 hover:bg-${options.danger ? 'red' : 'pink'}-700`;

            // Show modal
            modal.classList.remove('hidden');
            document.body.classList.add('overflow-hidden');

            // Set up event listeners
            const handleConfirm = () => {
                cleanup();
                resolve(true);
            };

            const handleCancel = () => {
                cleanup();
                resolve(false);
            };

            const cleanup = () => {
                confirmBtn.removeEventListener('click', handleConfirm);
                document.querySelector('#confirm-modal button[onclick]').removeEventListener('click', handleCancel);
                modal.classList.add('hidden');
                document.body.classList.remove('overflow-hidden');
            };

            confirmBtn.addEventListener('click', handleConfirm);
            document.querySelector('#confirm-modal button[onclick]').addEventListener('click', handleCancel);
        });
    }
}

// Initialize modal event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Close modals when clicking outside content
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                Modal.hide(modal.id);
            }
        });
    });

    // Handle form submissions
    document.querySelectorAll('[data-modal-form]').forEach(form => {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const action = form.getAttribute('action');
            const method = form.getAttribute('method') || 'POST';

            try {
                const response = await fetch(action, {
                    method,
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    Modal.hide(form.closest('.modal').id);
                    Modal.show('success-modal', {
                        title: 'Success',
                        message: result.message || 'Operation completed successfully'
                    });
                    if (typeof window.refreshData === 'function') {
                        window.refreshData();
                    }
                } else {
                    alert(result.message || 'An error occurred');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred while processing your request');
            }
        });
    });
});

// Helper functions for specific modals
function showAddElectionModal() {
    document.getElementById('election-form').reset();
    document.getElementById('election-id').value = '';
    Modal.show('add-election-modal');
}

function showAddCandidateModal() {
    document.getElementById('candidate-form').reset();
    document.getElementById('candidate-id').value = '';
    Modal.show('add-candidate-modal');
}

function showAddVoterModal() {
    document.getElementById('voter-form').reset();
    Modal.show('add-voter-modal');
}

function showImportVotersModal() {
    document.getElementById('import-voters-form').reset();
    Modal.show('import-voters-modal');
}