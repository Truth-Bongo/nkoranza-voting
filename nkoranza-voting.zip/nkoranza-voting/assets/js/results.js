// Results Module
export class Results {
  static async loadElections() {
    try {
      const response = await fetch(`${BASE_URL}/api/voting/elections?status=ended`);
      if (!response.ok) {
        throw new Error('Failed to load past elections');
      }
      
      const elections = await response.json();
      this.renderElectionDropdown(elections);
    } catch (error) {
      console.error('Error loading elections:', error);
      this.showError('Failed to load past elections');
    }
  }
  
  static renderElectionDropdown(elections) {
    const dropdown = document.getElementById('election-select');
    if (!dropdown) return;
    
    dropdown.innerHTML = '<option value="">Select an election</option>';
    
    elections.forEach(election => {
      const option = document.createElement('option');
      option.value = election.id;
      option.textContent = election.title;
      dropdown.appendChild(option);
    });
    
    dropdown.addEventListener('change', (e) => {
      if (e.target.value) {
        this.loadElectionResults(e.target.value);
      }
    });
  }
  
  static async loadElectionResults(electionId) {
    try {
      const response = await fetch(`${BASE_URL}/api/voting/results?election_id=${electionId}`);
      if (!response.ok) {
        throw new Error('Failed to load election results');
      }
      
      const results = await response.json();
      this.renderResults(results);
    } catch (error) {
      console.error('Error loading results:', error);
      this.showError('Failed to load election results');
    }
  }
  
  static renderResults(results) {
    const container = document.getElementById('results-container');
    if (!container) return;
    
    container.innerHTML = '';
    
    results.positions.forEach(position => {
      const positionCard = document.createElement('div');
      positionCard.className = 'card mb-8';
      positionCard.innerHTML = `
        <h3 class="text-xl font-bold mb-4">${position.name}</h3>
        <div class="space-y-4">
          ${this.renderCandidatesResults(position.candidates)}
        </div>
      `;
      container.appendChild(positionCard);
    });
  }
  
  static renderCandidatesResults(candidates) {
    return candidates.map(candidate => `
      <div class="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
        <div class="flex items-center space-x-4">
          <img src="${candidate.photo || DEFAULT_USER_IMAGE}" 
               alt="${candidate.name}" 
               class="w-12 h-12 rounded-full object-cover">
          <div>
            <h4 class="font-medium">${candidate.name}</h4>
            <p class="text-sm text-gray-600">${candidate.department}</p>
          </div>
        </div>
        <div class="text-right">
          <p class="font-bold">${candidate.votes} votes</p>
          <p class="text-sm text-gray-600">
            ${candidate.percentage.toFixed(1)}%
          </p>
        </div>
      </div>
    `).join('');
  }
  
  static showError(message) {
    const container = document.getElementById('results-container');
    if (container) {
      container.innerHTML = `
        <div class="alert alert-error">
          <p>${message}</p>
        </div>
      `;
    }
  }
}