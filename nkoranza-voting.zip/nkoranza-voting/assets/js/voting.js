// Voting Module
export class Voting {
  static async loadElections() {
    try {
      const response = await fetch(`${BASE_URL}/api/voting/elections`);
      if (!response.ok) {
        throw new Error('Failed to load elections');
      }
      
      const elections = await response.json();
      this.renderElections(elections);
    } catch (error) {
      console.error('Error loading elections:', error);
      this.showError('Failed to load elections. Please try again later.');
    }
  }
  
  static renderElections(elections) {
    const container = document.getElementById('elections-container');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (elections.length === 0) {
      container.innerHTML = `
        <div class="text-center py-8">
          <p class="text-gray-500">No active elections available</p>
        </div>
      `;
      return;
    }
    
    elections.forEach(election => {
      const electionCard = document.createElement('div');
      electionCard.className = 'card mb-6';
      electionCard.innerHTML = `
        <h3 class="text-xl font-bold mb-2">${election.title}</h3>
        <p class="text-gray-600 mb-4">${election.description || 'No description available'}</p>
        <div class="flex justify-between items-center">
          <div>
            <span class="text-sm ${this.getStatusColor(election.status)} px-2 py-1 rounded-full">
              ${election.status.charAt(0).toUpperCase() + election.status.slice(1)}
            </span>
          </div>
          <button class="btn btn-primary" 
                  onclick="window.location.href='vote/${election.id}'">
            View Positions
          </button>
        </div>
      `;
      container.appendChild(electionCard);
    });
  }
  
  static getStatusColor(status) {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'upcoming': return 'bg-yellow-100 text-yellow-800';
      case 'ended': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }
  
  static showError(message) {
    const errorContainer = document.getElementById('error-container');
    if (errorContainer) {
      errorContainer.innerHTML = `
        <div class="alert alert-error fade-in">
          <p>${message}</p>
        </div>
      `;
      setTimeout(() => {
        errorContainer.innerHTML = '';
      }, 5000);
    }
  }
}