// Admin Module
export class Admin {
  static async loadDashboardData() {
    try {
      const [elections, voters, candidates] = await Promise.all([
        this.fetchData('elections'),
        this.fetchData('voters'),
        this.fetchData('candidates')
      ]);
      
      this.renderDashboardStats(elections, voters, candidates);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      this.showError('Failed to load dashboard data');
    }
  }
  
  static async fetchData(endpoint) {
    const response = await fetch(`${BASE_URL}/api/admin/${endpoint}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch ${endpoint}`);
    }
    return await response.json();
  }
  
  static renderDashboardStats(elections, voters, candidates) {
    const statsContainer = document.getElementById('dashboard-stats');
    if (!statsContainer) return;
    
    statsContainer.innerHTML = `
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="card">
          <div class="flex items-center space-x-4">
            <div class="bg-pink-100 p-3 rounded-full">
              <i class="fas fa-calendar-alt text-pink-600 text-xl"></i>
            </div>
            <div>
              <h3 class="font-bold text-lg">Elections</h3>
              <p class="text-2xl font-bold">${elections.length}</p>
            </div>
          </div>
        </div>
        
        <div class="card">
          <div class="flex items-center space-x-4">
            <div class="bg-blue-100 p-3 rounded-full">
              <i class="fas fa-users text-blue-600 text-xl"></i>
            </div>
            <div>
              <h3 class="font-bold text-lg">Voters</h3>
              <p class="text-2xl font-bold">${voters.length}</p>
            </div>
          </div>
        </div>
        
        <div class="card">
          <div class="flex items-center space-x-4">
            <div class="bg-emerald-100 p-3 rounded-full">
              <i class="fas fa-user-tie text-emerald-600 text-xl"></i>
            </div>
            <div>
              <h3 class="font-bold text-lg">Candidates</h3>
              <p class="text-2xl font-bold">${candidates.length}</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  
  static showError(message) {
    const errorContainer = document.getElementById('admin-error-container');
    if (errorContainer) {
      errorContainer.innerHTML = `
        <div class="alert alert-error mb-4">
          <p>${message}</p>
        </div>
      `;
    }
  }
}