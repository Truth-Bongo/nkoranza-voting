class RealTimeResults {
    constructor(electionId) {
        this.electionId = electionId;
        this.socket = null;
        this.chartInstances = {};
        this.connect();
    }

    connect() {
        const protocol = window.location.protocol === 'https:' ? 'wss://' : 'ws://';
        const host = window.location.host;
        this.socket = new WebSocket(`${protocol}${host}:8080`);

        this.socket.onopen = () => {
            console.log('WebSocket connected');
            this.socket.send(JSON.stringify({
                action: 'subscribe',
                electionId: this.electionId
            }));
        };

        this.socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            
            if (data.type === 'initial') {
                this.initializeCharts(data.data);
            } else if (data.type === 'update') {
                this.updateCharts(data.data);
            }
        };

        this.socket.onclose = () => {
            console.log('WebSocket disconnected. Attempting to reconnect...');
            setTimeout(() => this.connect(), 5000);
        };
    }

    initializeCharts(data) {
        // Group by position
        const positions = {};
        data.forEach(row => {
            if (!positions[row.position_name]) {
                positions[row.position_name] = [];
            }
            positions[row.position_name].push(row);
        });

        // Create chart for each position
        Object.keys(positions).forEach(positionName => {
            const positionData = positions[positionName];
            const ctx = document.getElementById(`chart-${positionName.replace(/\s+/g, '-')}`);
            
            if (!ctx) return;

            const labels = positionData.map(c => `${c.first_name} ${c.last_name}`);
            const votes = positionData.map(c => c.votes);
            const backgroundColors = this.generateColors(positionData.length);

            this.chartInstances[positionName] = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Votes',
                        data: votes,
                        backgroundColor: backgroundColors,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    },
                    animation: {
                        duration: 1000
                    }
                }
            });
        });
    }

    updateCharts(updateData) {
        updateData.forEach(update => {
            const chart = this.chartInstances[update.position_name];
            if (chart) {
                // Find the candidate index
                const candidateIndex = chart.data.labels.indexOf(`${update.first_name} ${update.last_name}`);
                if (candidateIndex !== -1) {
                    chart.data.datasets[0].data[candidateIndex] = update.votes;
                    chart.update();
                }
            }
        });
    }

    generateColors(count) {
        const colors = [];
        for (let i = 0; i < count; i++) {
            const hue = (i * 360 / count) % 360;
            colors.push(`hsl(${hue}, 70%, 60%)`);
        }
        return colors;
    }
}