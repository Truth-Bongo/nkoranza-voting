<?php
require_once __DIR__ . '/bootstrap.php';

// Routing - get the page from URL or default to home
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Remove any trailing slashes and ensure proper formatting
$page = rtrim($page, '/');

// Protect admin routes
if (strpos($page, 'admin/') === 0) {
    require_admin();
}

// Allow both regular users and admins to access vote functionality
if ($page === 'vote') {
    require_login(); // This allows both regular users and admins
}

// Route to the appropriate page
switch ($page) {
    case 'admin':
    case 'admin/dashboard':
        require_once APP_ROOT . '/views/admin/dashboard.php';
        break;
    case 'admin/voters':
        require_once APP_ROOT . '/views/admin/voters.php';
        break;
    case 'admin/elections':
        require_once APP_ROOT . '/views/admin/elections.php';
        break;
    case 'admin/candidates':
        require_once APP_ROOT . '/views/admin/candidates.php';
        break;
    case 'admin/results':
        require_once APP_ROOT . '/views/admin/results.php';
        break;
    case 'login':
        require_once APP_ROOT . '/views/auth/login.php';
        break;
    case 'vote':
        require_once APP_ROOT . '/views/vote.php';
        break;
    case 'results':
        require_once APP_ROOT . '/views/results.php';
        break;
    case 'elections':
        require_once APP_ROOT . '/views/elections.php';
        break;
    case 'logout':
        // Handle logout directly
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_destroy();
        header('Location: ' . BASE_URL . '/login');
        exit;
        break;
    case 'home':
    default:
        require_once APP_ROOT . '/views/home.php';
        break;
}