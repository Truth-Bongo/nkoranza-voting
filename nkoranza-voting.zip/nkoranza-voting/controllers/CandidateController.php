<?php
require_once APP_ROOT . '/config/db_connect.php';

class CandidateController {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Get all candidates with joined details
     */
    public function getCandidates() {
        $stmt = $this->db->prepare("
            SELECT 
                c.id,
                c.election_id,
                c.position_id,
                c.user_id,
                c.manifesto,
                c.photo_path,
                e.title AS election_title,
                p.name  AS position_name,
                u.first_name,
                u.last_name,
                u.department
            FROM candidates c
            LEFT JOIN elections e ON c.election_id = e.id
            LEFT JOIN positions p ON c.position_id = p.id
            LEFT JOIN users u ON c.user_id = u.id
            ORDER BY e.start_date DESC, p.id ASC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Add or update candidate
     */
    public function saveCandidate($data, $file = null) {
        // Handle file upload if provided
        $photoPath = null;
        if ($file && isset($file['tmp_name']) && $file['tmp_name']) {
            $uploadDir = APP_ROOT . "/uploads/candidates/";
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            $fileName = time() . "_" . basename($file['name']);
            $targetPath = $uploadDir . $fileName;
            if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                $photoPath = "uploads/candidates/" . $fileName;
            }
        }

        if (!empty($data['id'])) {
            // Update
            $sql = "UPDATE candidates 
                    SET election_id=:election_id, position_id=:position_id, manifesto=:manifesto";
            if ($photoPath) {
                $sql .= ", photo_path=:photo_path";
            }
            $sql .= " WHERE id=:id";

            $stmt = $this->db->prepare($sql);
            $params = [
                ':election_id' => $data['election_id'],
                ':position_id' => $data['position_id'],
                ':manifesto'   => $data['manifesto'],
                ':id'          => $data['id']
            ];
            if ($photoPath) {
                $params[':photo_path'] = $photoPath;
            }
            return $stmt->execute($params);
        } else {
            // Insert
            $stmt = $this->db->prepare("
                INSERT INTO candidates (election_id, position_id, user_id, manifesto, photo_path)
                VALUES (:election_id, :position_id, :user_id, :manifesto, :photo_path)
            ");
            return $stmt->execute([
                ':election_id' => $data['election_id'],
                ':position_id' => $data['position_id'],
                ':user_id'     => $data['user_id'],
                ':manifesto'   => $data['manifesto'],
                ':photo_path'  => $photoPath
            ]);
        }
    }

    /**
     * Delete candidate
     */
    public function deleteCandidate($id) {
        $stmt = $this->db->prepare("DELETE FROM candidates WHERE id = :id");
        return $stmt->execute([":id" => $id]);
    }
}
