<?php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../../controllers/VoterController.php';

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
    exit;
}

// CSRF check
$csrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (empty($_SESSION['csrf_token']) || $csrfToken !== $_SESSION['csrf_token']) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid CSRF token.'
    ]);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON data.'
    ]);
    exit;
}

// Validate required fields
$required = ['student_id', 'first_name', 'last_name', 'department', 'level'];
foreach ($required as $field) {
    if (empty($input[$field])) {
        echo json_encode([
            'success' => false,
            'message' => 'All required fields must be filled.'
        ]);
        exit;
    }
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=nkoranza_voting;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for duplicate ID
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE id = ?");
    $checkStmt->execute([$input['student_id']]);
    if ($checkStmt->fetchColumn() > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'A voter with this Student ID already exists.'
        ]);
        exit;
    }

    // Insert new voter
    $controller = new VoterController();
    $success = $controller->store($input);

    if ($success) {
        echo json_encode([
            'success' => true,
            'message' => 'Voter added successfully.'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to add voter.'
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
