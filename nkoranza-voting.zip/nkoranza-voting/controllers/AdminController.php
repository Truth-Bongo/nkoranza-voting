<?php
require_once APP_ROOT . '/controllers/BaseController.php';
require_once APP_ROOT . '/models/Election.php';
require_once APP_ROOT . '/models/Candidate.php';
require_once APP_ROOT . '/models/User.php';

class AdminController extends BaseController {
    public function dashboard() {
        $this->requireAdmin();
        
        $electionModel = new Election();
        $userModel = new User();
        $candidateModel = new Candidate();
        
        $data = [
            'electionCount' => $electionModel->count(),
            'voterCount' => $userModel->count(),
            'candidateCount' => $candidateModel->count(),
            'activeElections' => $electionModel->getActive()
        ];
        
        $this->render('admin/dashboard', $data);
    }
    
    public function manageElections() {
        $this->requireAdmin();
        $electionModel = new Election();
        
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $data = [
                'elections' => $electionModel->getAll()
            ];
            $this->render('admin/elections', $data);
            return;
        }
        
        $this->validateCsrfToken();
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $id = $electionModel->create($data);
                $this->jsonResponse([
                    'success' => true,
                    'id' => $id
                ], 201);
            } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
                $electionModel->update($data['id'], $data);
                $this->jsonResponse(['success' => true]);
            } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
                $electionModel->delete($_GET['id']);
                $this->jsonResponse(['success' => true]);
            }
        } catch (Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
    
    public function manageCandidates() {
        $this->requireAdmin();
        $candidateModel = new Candidate();
        
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $data = [
                'candidates' => $candidateModel->getAllWithDetails()
            ];
            $this->render('admin/candidates', $data);
            return;
        }
        
        $this->validateCsrfToken();
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $id = $candidateModel->create($data);
                $this->jsonResponse([
                    'success' => true,
                    'id' => $id
                ], 201);
            } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
                $candidateModel->update($data['id'], $data);
                $this->jsonResponse(['success' => true]);
            } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
                $candidateModel->delete($_GET['id']);
                $this->jsonResponse(['success' => true]);
            }
        } catch (Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
    
    public function manageVoters() {
        $this->requireAdmin();
        $userModel = new User();
        
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $page = $_GET['p'] ?? 1;
            $perPage = 10;
            
            $data = [
                'voters' => $userModel->getAll($page, $perPage),
                'totalPages' => ceil($userModel->count() / $perPage),
                'currentPage' => $page
            ];
            
            $this->render('admin/voters', $data);
            return;
        }
        
        $this->validateCsrfToken();
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $id = $userModel->create($data);
                $this->jsonResponse([
                    'success' => true,
                    'id' => $id
                ], 201);
            } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
                $userModel->update($data['id'], $data);
                $this->jsonResponse(['success' => true]);
            } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
                $userModel->delete($_GET['id']);
                $this->jsonResponse(['success' => true]);
            }
        } catch (Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
}
?>