<?php
require_once __DIR__ . '/../models/Election.php';
require_once __DIR__ . '/BaseController.php';

class HomeController extends BaseController {
    private $electionModel;

    public function __construct() {
        parent::__construct();
        $this->electionModel = new Election($this->db);
    }

    public function index() {
        try {
            // Get active and upcoming elections
            $activeElections = $this->electionModel->readActive()->fetchAll(PDO::FETCH_ASSOC);
            $upcomingElections = $this->electionModel->readUpcoming()->fetchAll(PDO::FETCH_ASSOC);
            $pastElections = $this->electionModel->readEnded()->fetchAll(PDO::FETCH_ASSOC);

            // Prepare data for view
            $data = [
                'activeElections' => $activeElections,
                'upcomingElections' => $upcomingElections,
                'pastElections' => $pastElections
            ];

            // Load view
            require_once __DIR__ . '/../views/home.php';
        } catch (Exception $e) {
            $this->handleError($e);
        }
    }

    public function showFeatures() {
        try {
            // Static feature data
            $features = [
                [
                    'icon' => 'user-shield',
                    'title' => 'Secure Voting',
                    'description' => 'Our system uses advanced encryption to ensure your vote remains anonymous and secure.'
                ],
                [
                    'icon' => 'bolt',
                    'title' => 'Fast Results',
                    'description' => 'Get real-time election results as soon as voting ends, eliminating long waits.'
                ],
                [
                    'icon' => 'mobile-alt',
                    'title' => 'Mobile Friendly',
                    'description' => 'Vote from any device, whether you\'re using a computer, tablet, or smartphone.'
                ]
            ];

            require_once __DIR__ . '/../views/features.php';
        } catch (Exception $e) {
            $this->handleError($e);
        }
    }
}
?>