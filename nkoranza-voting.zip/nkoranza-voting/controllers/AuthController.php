<?php
require_once APP_ROOT . '/controllers/BaseController.php';
require_once APP_ROOT . '/models/User.php';

class AuthController extends BaseController {
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->render('auth/login');
            return;
        }
        
        // Handle POST request
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            $userModel = new User();
            $user = $userModel->authenticate($data['id'], $data['password']);
            
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['is_admin'] = $user['is_admin'];
            $_SESSION['full_name'] = $user['first_name'] . ' ' . $user['last_name'];
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
            $this->jsonResponse([
                'success' => true,
                'isAdmin' => $user['is_admin'],
                'fullName' => $_SESSION['full_name']
            ]);
        } catch (Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => $e->getMessage()
            ], 401);
        }
    }
    
    public function logout() {
        session_start();
        session_unset();
        session_destroy();
        
        $this->jsonResponse(['success' => true]);
    }
    
    public function checkSession() {
        session_start();
        
        if (isset($_SESSION['user_id'])) {
            $this->jsonResponse([
                'loggedIn' => true,
                'isAdmin' => $_SESSION['is_admin'],
                'fullName' => $_SESSION['full_name']
            ]);
        } else {
            $this->jsonResponse(['loggedIn' => false]);
        }
    }
}
?>