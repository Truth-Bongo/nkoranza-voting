<?php
require_once APP_ROOT . '/controllers/BaseController.php';
require_once APP_ROOT . '/models/Election.php';
require_once APP_ROOT . '/models/Vote.php';

class ResultsController extends BaseController {
    public function index() {
        $electionModel = new Election();
        $data = [
            'elections' => $electionModel->getByStatus('ended')
        ];
        
        $this->render('results', $data);
    }
    
    public function getResults() {
        $electionId = $_GET['election_id'];
        
        $voteModel = new Vote();
        $results = $voteModel->getResultsByElection($electionId);
        
        $this->jsonResponse($results);
    }
    
    public function exportResults() {
        $this->requireAdmin();
        $electionId = $_GET['election_id'];
        
        $voteModel = new Vote();
        $results = $voteModel->getResultsByElection($electionId);
        $electionModel = new Election();
        $election = $electionModel->getById($electionId);
        
        // Set headers for CSV download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $election['title'] . ' Results.csv"');
        
        $output = fopen('php://output', 'w');
        
        // Write CSV headers
        fputcsv($output, ['Position', 'Candidate', 'Department', 'Votes', 'Percentage']);
        
        // Write data
        foreach ($results['positions'] as $position) {
            foreach ($position['candidates'] as $candidate) {
                fputcsv($output, [
                    $position['name'],
                    $candidate['name'],
                    $candidate['department'],
                    $candidate['votes'],
                    $candidate['percentage'] . '%'
                ]);
            }
        }
        
        fclose($output);
        exit;
    }
}
?>