<?php
require_once APP_ROOT . '/controllers/BaseController.php';
require_once APP_ROOT . '/models/Election.php';
require_once APP_ROOT . '/models/Position.php';
require_once APP_ROOT . '/models/Candidate.php';

class ElectionController extends BaseController {
    public function index() {
        $electionModel = new Election();
        $data = [
            'elections' => $electionModel->getActive()
        ];
        $this->render('home', $data);
    }
    
    public function getElections() {
        $electionModel = new Election();
        $status = $_GET['status'] ?? null;
        
        $elections = $status 
            ? $electionModel->getByStatus($status)
            : $electionModel->getAll();
            
        $this->jsonResponse($elections);
    }
    
    public function getElectionPositions() {
        $this->requireLogin();
        $electionId = $_GET['election_id'];
        
        $positionModel = new Position();
        $positions = $positionModel->getByElection($electionId);
        
        $this->jsonResponse($positions);
    }
    
    public function getPositionCandidates() {
        $this->requireLogin();
        $positionId = $_GET['position_id'];
        
        $candidateModel = new Candidate();
        $candidates = $candidateModel->getByPosition($positionId);
        
        $this->jsonResponse($candidates);
    }
    
    public function viewElection($electionId) {
        $electionModel = new Election();
        $positionModel = new Position();
        
        $data = [
            'election' => $electionModel->getById($electionId),
            'positions' => $positionModel->getByElection($electionId)
        ];
        
        $this->render('vote', $data);
    }
}
?>