<?php
require_once APP_ROOT . '/config/db_connect.php';

class PositionController {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Get all positions for a given election
     */
    public function getPositionsByElection($electionId) {
        if (!$electionId) {
            throw new Exception("Election ID is required");
        }

        $stmt = $this->db->prepare("
            SELECT p.id, p.name, p.description
            FROM positions p
            WHERE p.election_id = :election_id
            ORDER BY p.id ASC
        ");
        $stmt->execute([":election_id" => $electionId]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
