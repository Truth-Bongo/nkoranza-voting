<?php
// Ensure APP_ROOT is defined
if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(dirname(__DIR__)));
}

require_once APP_ROOT . '/config/constants.php';
require_once APP_ROOT . '/config/db_connect.php';
require_once APP_ROOT . '/helpers/functions.php';

abstract class BaseController {
    protected $db;
    
    public function __construct() {
        try {
            $this->db = Database::getInstance()->getConnection();
        } catch (PDOException $e) {
            error_log("Database connection error: " . $e->getMessage());
            $this->handleError('Database connection failed', 500);
        }
    }
    
    protected function render($viewPath, $data = []) {
        try {
            $viewFile = APP_ROOT . "/views/$viewPath.php";
            
            if (!file_exists($viewFile)) {
                throw new Exception("View file not found: $viewPath");
            }
            
            // Extract data to variables
            extract($data);
            
            // Start output buffering
            ob_start();
            
            // Include the view file
            include $viewFile;
            
            // Get the view content
            $content = ob_get_clean();
            
            // Include the layout
            include APP_ROOT . '/includes/header.php';
            echo $content;
            include APP_ROOT . '/includes/footer.php';
            
        } catch (Exception $e) {
            error_log("View rendering error: " . $e->getMessage());
            $this->handleError('Error loading page', 500);
        }
    }
    
    protected function jsonResponse($data, $statusCode = 200) {
        header('Content-Type: application/json');
        http_response_code($statusCode);
        echo json_encode($data);
        exit;
    }
    
    protected function requireAdmin() {
        $this->startSession();
        
        if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
            $this->handleError('Administrator access required', 403);
        }
    }
    
    protected function requireLogin() {
        $this->startSession();
        
        if (!isset($_SESSION['user_id'])) {
            $this->handleError('Authentication required', 401);
        }
    }
    
    protected function validateCsrfToken() {
        $this->startSession();
        
        $headers = getallheaders();
        $token = $headers['X-CSRF-Token'] ?? null;
        
        if (!$token || $token !== $_SESSION['csrf_token']) {
            $this->handleError('Invalid CSRF token', 403);
        }
    }
    
    protected function startSession() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    protected function handleError($message, $statusCode = 400) {
        if (php_sapi_name() === 'cli') {
            throw new Exception($message);
        }
        
        if (strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
            $this->jsonResponse([
                'success' => false,
                'message' => $message
            ], $statusCode);
        } else {
            http_response_code($statusCode);
            include APP_ROOT . '/views/errors/' . $statusCode . '.php';
            exit;
        }
    }
    
    protected function sanitizeInput($input) {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        }
        
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    
    protected function validateRequiredFields($data, $requiredFields) {
        $missingFields = [];
        
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                $missingFields[] = $field;
            }
        }
        
        if (!empty($missingFields)) {
            $this->handleError(
                'Missing required fields: ' . implode(', ', $missingFields),
                400
            );
        }
    }
}