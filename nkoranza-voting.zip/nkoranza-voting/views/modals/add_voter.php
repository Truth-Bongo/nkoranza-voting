<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf_token'];
?>
<div id="add-voter-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
  <div class="bg-white rounded-lg shadow-lg w-full max-w-lg p-6 relative">
    <div class="flex justify-between items-center mb-4">
      <h2 id="add-voter-title" class="text-xl font-semibold text-gray-900">Add/Edit Voter</h2>
      <button type="button" onclick="hideModal('add-voter-modal')" class="text-gray-500 hover:text-gray-700">
        <i class="fas fa-times"></i>
      </button>
    </div>

    <form id="voter-form" class="space-y-4" autocomplete="off">
      <input type="hidden" id="is-edit" name="is_edit" value="false">
      <input type="hidden" name="csrf_token" value="<?= $csrf ?>">

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Voter ID</label>
          <input id="voter-id" name="id" type="text" class="w-full px-3 py-2 border 
          border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
          <input id="voter-password" name="password" type="password" class="w-full px-3 py-2 border 
          border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" 
          placeholder="Leave blank to keep current password">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">First Name</label>
          <input id="voter-firstname" name="first_name" type="text" class="w-full px-3 py-2 border 
          border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
          <input id="voter-lastname" name="last_name" type="text" class="w-full px-3 py-2 border 
          border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Department</label>
          <select id="voter-department" name="department" class="w-full px-3 py-2 border 
          border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required>
            <option value="">--Select Department--</option>
            <option>General Science</option>
            <option>General Arts</option>
            <option>Agric Dept</option>
            <option>Business Dept</option>
            <option>Technical Dept</option>
            <option>Home Economics</option>
            <option>Visual Art</option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Level</label>
          <select id="voter-level" name="level" class="w-full px-3 py-2 border 
          border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required>
            <option value="">--Select Level--</option>
            <option value="100">100</option>
            <option value="200">200</option>
            <option value="300">300</option>
          </select>
        </div>
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
        <input id="voter-email" name="email" type="email" class="w-full px-3 py-2 border 
          border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
      </div>

      <div class="flex justify-end space-x-3 pt-4">
        <button type="button" onclick="hideModal('add-voter-modal')" class="px-4 py-2 border rounded text-sm">Cancel</button>
        <button type="submit" id="voter-save-btn" class="px-4 py-2 bg-gray-900 text-white rounded text-sm">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAddVoterModal(editData = null) {
  const form = document.getElementById('voter-form');
  form.reset();
  document.getElementById('add-voter-title').textContent = editData ? 'Edit Voter' : 'Add Voter';
  document.getElementById('is-edit').value = editData ? 'true' : 'false';
  
  if (editData) {
    document.getElementById('voter-id').value = editData.id || '';
    document.getElementById('voter-firstname').value = editData.first_name || '';
    document.getElementById('voter-lastname').value = editData.last_name || '';
    document.getElementById('voter-department').value = editData.department || '';
    document.getElementById('voter-level').value = editData.level || '';
    document.getElementById('voter-email').value = editData.email || '';
    document.getElementById('voter-id').setAttribute('readonly', 'readonly');
  } else {
    document.getElementById('voter-id').removeAttribute('readonly');
  }
  document.getElementById('add-voter-modal').classList.remove('hidden');
}
</script>
