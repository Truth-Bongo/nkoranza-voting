<?php
// Load users for dropdown
$db = Database::getInstance()->getConnection();
$users = $db->query("SELECT id, first_name, last_name, department FROM users ORDER BY first_name, last_name")->fetchAll(PDO::FETCH_ASSOC);
file_put_contents(__DIR__ . '/debug_candidate_post.log',
    "---- " . date('c') . " ----\n" .
    print_r($_POST, true) . print_r($_FILES, true) . "\n",
    FILE_APPEND
);
?>
<div id="add-candidate-modal" class="fixed inset-0 bg-gray-800 bg-opacity-50 hidden flex items-center justify-center z-50">
  <div class="bg-white rounded-lg w-full max-w-2xl shadow-lg p-6">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-xl font-semibold text-pink-900">Add/Edit Candidate</h2>
      <button type="button" onclick="hideModal('add-candidate-modal')" class="text-gray-500 hover:text-gray-700">
        <i class="fas fa-times"></i>
      </button>
    </div>

    <form id="candidate-form" enctype="multipart/form-data">
      <input type="hidden" id="candidate-id" name="id" />

      <div class="mb-4">
        <label for="candidate-user" class="block text-sm font-medium text-gray-700">Select User</label>
        <select id="candidate-user" name="user_id" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required>
          <option value="">-- Select User --</option>
          <!-- Options will be populated by JavaScript -->
        </select>
      </div>

      <div class="mb-4">
        <label for="candidate-election" class="block text-sm font-medium text-gray-700">Election</label>
        <select id="candidate-election" name="election_id" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required>
          <option value="">Select Election</option>
        </select>
        <p id="candidate-election-help" class="text-xs text-gray-500 mt-1 hidden"></p>
      </div>

      <div class="mb-4">
        <label for="candidate-position" class="block text-sm font-medium text-gray-700">Position</label>
        <select id="candidate-position" name="position_id" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required>
          <option value="">Select Position</option>
        </select>
        <p id="candidate-position-help" class="text-xs text-gray-500 mt-1 hidden"></p>
      </div>

      <div class="mb-4">
        <label for="candidate-description" class="block text-sm font-medium text-gray-700">Manifesto</label>
        <textarea id="candidate-description" name="manifesto" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></textarea>
      </div>

      <div class="mb-4">
        <label for="candidate-photo" class="block text-sm font-medium text-gray-700">Photo</label>
        <input type="file" id="candidate-photo" name="photo" accept="image/*" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" />
      </div>

      <div class="flex justify-end space-x-2">
        <button type="button" onclick="hideModal('add-candidate-modal')" class="bg-gray-200 px-4 py-2 rounded text-sm">Cancel</button>
        <button type="submit" class="bg-pink-900 hover:bg-primary-light text-white px-4 py-2 rounded text-sm">Save Candidate</button>
      </div>
    </form>
  </div>
</div>

<script>
(function() {
  const BASE_URL   = window.BASE_URL || "<?= BASE_URL ?>";
  const CSRF_TOKEN = "<?= $_SESSION['csrf_token'] ?? '' ?>";

  function toArray(payload, ...keys) {
    if (Array.isArray(payload)) return payload;
    if (!payload || typeof payload !== 'object') return [];
    for (const k of keys) if (Array.isArray(payload[k])) return payload[k];
    if (Array.isArray(payload.data)) return payload.data;
    return [];
  }

  async function loadElections(selectEl) {
    selectEl.innerHTML = '<option value="">Select Election</option>';
    try {
      const res = await fetch(`${BASE_URL}/api/voting/elections.php`, { credentials: 'same-origin' });
      const data = await res.json();
      const arr = toArray(data, 'elections');
      for (const e of arr) {
        const opt = document.createElement('option');
        opt.value = e.id; opt.textContent = e.title; selectEl.appendChild(opt);
      }
    } catch (e) { console.error(e); }
  }

  async function loadPositions(electionId, selectEl) {
    selectEl.innerHTML = '<option value="">Select Position</option>';
    if (!electionId) return;
    try {
      const res = await fetch(`${BASE_URL}/api/voting/positions.php?election_id=${encodeURIComponent(electionId)}`, { credentials: 'same-origin' });
      const data = await res.json();
      const arr = toArray(data, 'positions');
      for (const p of arr) {
        const opt = document.createElement('option');
        opt.value = p.id; opt.textContent = p.name; selectEl.appendChild(opt);
      }
    } catch (e) { console.error(e); }
  }

  const electionSelect = document.getElementById('candidate-election');
  const positionSelect = document.getElementById('candidate-position');
  loadElections(electionSelect);
  electionSelect.addEventListener('change', () => loadPositions(electionSelect.value, positionSelect));

  document.getElementById('candidate-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const userId = document.getElementById('candidate-user').value;
  const electionId = document.getElementById('candidate-election').value;
  const positionId = document.getElementById('candidate-position').value;

  if (userId === "" || electionId === "" || positionId === "") {
  alert("Please select User, Election, and Position before saving.");
  return;
}

  const fd = new FormData(e.target);
  const id = document.getElementById('candidate-id').value.trim();
  const url = id ? `${BASE_URL}/api/admin/candidates.php?id=${encodeURIComponent(id)}`
                 : `${BASE_URL}/api/admin/candidates.php`;

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'X-CSRF-Token': CSRF_TOKEN },
        body: fd,
        credentials: 'same-origin',
      });
      const out = await res.json();
      if (out.success) { hideModal('add-candidate-modal'); window.location.reload(); }
      else alert(out.message || 'Failed to save candidate');
    } catch (err) {
      console.error(err); alert('Network error');
    }
  });

  // expose editCandidate globally
  window.editCandidate = function(c) {
    document.getElementById('candidate-id').value = c.id || '';
    document.getElementById('candidate-user').value = c.user_id || '';
    document.getElementById('candidate-description').value = c.manifesto || '';
    electionSelect.value = c.election_id || '';
    loadPositions(c.election_id, positionSelect).then(() => {
      positionSelect.value = c.position_id || '';
    });
    showModal('add-candidate-modal');
  };

  // expose delete helpers globally
  window.confirmDeleteCandidate = function(id) {
    if (confirm('Delete this candidate?')) window.deleteCandidate(id);
  };
  window.deleteCandidate = async function(id) {
    try {
      const res = await fetch(`${BASE_URL}/api/admin/candidates.php?id=${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: { 'X-CSRF-Token': CSRF_TOKEN },
        credentials: 'same-origin'
      });
      const out = await res.json();
      if (out.success) window.location.reload();
      else alert(out.message || 'Failed to delete candidate');
    } catch (e) { console.error(e); alert('Network error'); }
  };
})();
</script>
