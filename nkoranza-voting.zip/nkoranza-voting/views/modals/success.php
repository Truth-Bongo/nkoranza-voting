<div id="success-modal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
        <div class="flex flex-col items-center">
            <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <i class="fas fa-check text-green-600 text-2xl"></i>
            </div>
            <h3 class="text-xl font-bold mb-2 text-center"><?= $modalTitle ?? 'Operation Successful' ?></h3>
            <p class="text-gray-600 text-center mb-4"><?= $modalMessage ?? 'Your action was completed successfully.' ?></p>
            <button onclick="hideModal('success-modal')" 
                    class="bg-primary hover:bg-primary-light text-white px-4 py-2 rounded transition w-full">
                Continue
            </button>
        </div>
    </div>
</div>