<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf_token'];
?>
<div id="add-election-modal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-yellow-900"><?= $modalTitle ?? 'Add New Election' ?></h3>
            <button onclick="hideModal('add-election-modal')" class="text-gray-400 hover:text-gray-500">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <form id="election-form" class="space-y-4">
            <input type="hidden" id="election-id">
            
            <div>
                <label for="election-title" class="block text-sm font-medium text-gray-700 mb-1">Election Title</label>
                <input type="text" id="election-title" class="w-full px-3 py-2 border 
                border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label for="start-date" class="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                    <input type="datetime-local" id="start-date" class="w-full px-3 py-2 border 
                border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required>
                </div>
                <div>
                    <label for="end-date" class="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                    <input type="datetime-local" id="end-date" class="w-full px-3 py-2 border 
                border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required>
                </div>
            </div>
            
            <div>
                <label for="election-description" class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea id="election-description" rows="3" class="w-full px-3 py-2 border 
                border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"></textarea>
            </div>
            
            <div class="flex justify-end space-x-3 pt-4">
                <button type="button" onclick="hideModal('add-election-modal')" 
                        class="px-4 py-2 border border-gray-300 rounded-md text-sm 
                        font-medium text-gray-700 hover:bg-gray-50">
                    Cancel
                </button>
                <button type="submit" 
                        class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium 
                        text-white bg-yellow-900 hover:bg-primary-light">
                    Save Election
                </button>
            </div>
        </form>
    </div>
</div>