<div id="confirm-modal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
        <div class="flex flex-col items-center">
            <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <i class="fas fa-exclamation text-red-600 text-2xl"></i>
            </div>
            <h3 class="text-xl font-bold mb-2 text-center" id="confirm-title">Confirm Action</h3>
            <p class="text-gray-600 text-center mb-4" id="confirm-message">Are you sure you want to perform this action?</p>
            
            <div class="flex space-x-4 w-full">
                <button onclick="hideModal('confirm-modal')" 
                        class="flex-1 px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">
                    Cancel
                </button>
                <button id="confirm-action-btn"
                        class="flex-1 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700">
                    Confirm
                </button>
            </div>
        </div>
    </div>
</div>