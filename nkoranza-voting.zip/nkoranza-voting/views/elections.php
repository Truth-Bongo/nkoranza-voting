<?php
// views/elections.php
require_once __DIR__ . '/../bootstrap.php';

require_login();

// Check if user is admin
$isAdmin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];

// Handle search and filter parameters
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? 'all';

try {
    $db = Database::getInstance()->getConnection();

    // Build query with filters
    $query = "SELECT * FROM elections WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $query .= " AND (title LIKE :search OR description LIKE :search)";
        $params[':search'] = "%$search%";
    }

    if ($status_filter !== 'all') {
        $query .= " AND status = :status";
        $params[':status'] = $status_filter;
    }

    // Pagination setup
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $limit = 9;
    $offset = ($page - 1) * $limit;

    // Get total count for pagination
    $count_query = str_replace('*', 'COUNT(*) as total', $query);
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $totalElections = (int) $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
    $totalPages = max(1, ceil($totalElections / $limit));

    // Add ordering and pagination to main query
    $query .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
    $stmt = $db->prepare($query);
    
    // Bind parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $elections = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $elections = [];
    $totalPages = 1;
    error_log("Error fetching elections: " . $e->getMessage());
}

// Add status to each election
foreach ($elections as &$election) {
    $now   = new DateTime();
    $start = new DateTime($election['start_date']);
    $end   = new DateTime($election['end_date']);

    $election['status'] = ($now < $start) ? 'upcoming' : (($now > $end) ? 'ended' : 'active');
}
unset($election);

// Get statistics
$stats_stmt = $db->query("
    SELECT 
        status,
        COUNT(*) as count
    FROM elections 
    GROUP BY status
");
$stats = $stats_stmt->fetchAll(PDO::FETCH_ASSOC);

$status_counts = [
    'active' => 0,
    'upcoming' => 0,
    'ended' => 0,
    'all' => $totalElections
];

foreach ($stats as $stat) {
    $status_counts[$stat['status']] = $stat['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elections - Nkoranza Voting System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <?php include APP_ROOT . '/includes/header.php'; ?>
    
    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Header Section -->
        <div class="text-center mb-12">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Current Elections</h1>
            <p class="text-gray-600 max-w-2xl mx-auto">
                Participate in ongoing elections or view upcoming and past election activities
            </p>
        </div>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <div class="flex items-center">
                    <div class="bg-blue-100 p-3 rounded-full mr-4">
                        <i class="fas fa-calendar-alt text-blue-600"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Total Elections</p>
                        <p class="text-2xl font-bold text-gray-900"><?= $status_counts['all'] ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <div class="flex items-center">
                    <div class="bg-green-100 p-3 rounded-full mr-4">
                        <i class="fas fa-vote-yea text-green-600"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Active</p>
                        <p class="text-2xl font-bold text-gray-900"><?= $status_counts['active'] ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <div class="flex items-center">
                    <div class="bg-yellow-100 p-3 rounded-full mr-4">
                        <i class="fas fa-clock text-yellow-600"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Upcoming</p>
                        <p class="text-2xl font-bold text-gray-900"><?= $status_counts['upcoming'] ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <div class="flex items-center">
                    <div class="bg-red-100 p-3 rounded-full mr-4">
                        <i class="fas fa-times-circle text-red-600"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Ended</p>
                        <p class="text-2xl font-bold text-gray-900"><?= $status_counts['ended'] ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filter Section -->
        <div class="bg-white p-4 rounded-lg shadow-md mb-6">
            <div class="flex flex-col md:flex-row gap-4">
                <div class="flex-1">
                    <label for="search" class="sr-only">Search</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-search text-gray-400"></i>
                        </div>
                        <input type="text" id="search" name="search" value="<?= htmlspecialchars($search) ?>" 
                               placeholder="Search elections..." class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md">
                    </div>
                </div>
                <div class="w-full md:w-48">
                    <label for="status-filter" class="sr-only">Filter by status</label>
                    <select id="status-filter" name="status" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md">
                        <option value="all" <?= $status_filter === 'all' ? 'selected' : '' ?>>All Statuses</option>
                        <option value="active" <?= $status_filter === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="upcoming" <?= $status_filter === 'upcoming' ? 'selected' : '' ?>>Upcoming</option>
                        <option value="ended" <?= $status_filter === 'ended' ? 'selected' : '' ?>>Ended</option>
                    </select>
                </div>
                <div>
                    <button id="apply-filters" class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-2 rounded-md">
                        Apply Filters
                    </button>
                </div>
                <?php if ($isAdmin): ?>
                    <div>
                        <a href="<?= BASE_URL ?>/admin/elections" class="bg-gray-700 hover:bg-gray-800 text-white px-4 py-2 rounded-md inline-block">
                            <i class="fas fa-cog mr-1"></i> Manage Elections
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Elections Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php if (empty($elections)): ?>
                <div class="col-span-full text-center py-12">
                    <div class="mx-auto h-24 w-24 text-gray-400 mb-4">
                        <i class="fas fa-calendar-times text-5xl"></i>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900">No elections found</h3>
                    <p class="mt-1 text-sm text-gray-500">
                        <?= $isAdmin ? 'Create your first election' : 'Check back later for upcoming elections' ?>
                    </p>
                    <?php if (!empty($search) || $status_filter !== 'all'): ?>
                        <p class="mt-4">
                            <a href="?" class="text-pink-900 hover:text-pink-800">Clear filters</a>
                        </p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($elections as $election): 
                    // Calculate days remaining for active elections
                    $days_remaining = '';
                    if ($election['status'] === 'active') {
                        $end_date = new DateTime($election['end_date']);
                        $now = new DateTime();
                        $interval = $now->diff($end_date);
                        $days_remaining = $interval->format('%a days remaining');
                    }
                ?>
                    <div class="election-card bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                        <div class="p-6">
                            <div class="flex justify-between items-start mb-4">
                                <h3 class="text-xl font-bold text-gray-900"><?= htmlspecialchars($election['title']) ?></h3>
                                <span class="status-badge px-3 py-1 rounded-full text-xs font-medium 
                                    <?= $election['status'] === 'active' ? 'bg-green-100 text-green-800' : 
                                       ($election['status'] === 'upcoming' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800') ?>">
                                    <?= ucfirst($election['status']) ?>
                                </span>
                            </div>
                            
                            <p class="text-gray-600 mb-4"><?= htmlspecialchars($election['description']) ?></p>
                            
                            <div class="mb-4">
                                <p class="text-sm text-gray-500">
                                    <i class="fas fa-calendar-alt mr-2"></i>
                                    <?= date('M j, Y', strtotime($election['start_date'])) ?> - 
                                    <?= date('M j, Y', strtotime($election['end_date'])) ?>
                                </p>
                                <?php if ($days_remaining): ?>
                                    <p class="text-sm text-green-600 mt-1">
                                        <i class="fas fa-clock mr-1"></i> <?= $days_remaining ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="flex justify-between items-center">
                                <?php if ($election['status'] === 'active'): ?>
                                    <!-- FIXED: Vote Now link -->
                                    <a href="<?= BASE_URL ?>/vote?election_id=<?= $election['id'] ?>" 
                                       class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-2 rounded-lg transition-colors">
                                        <i class="fas fa-vote-yea mr-1"></i> Vote Now
                                    </a>
                                <?php elseif ($election['status'] === 'upcoming'): ?>
                                    <button class="bg-gray-300 text-gray-600 px-4 py-2 rounded-lg cursor-not-allowed" disabled>
                                        <i class="fas fa-clock mr-1"></i> Coming Soon
                                    </button>
                                <?php else: ?>
                                    <a href="<?= BASE_URL ?>/results?election_id=<?= $election['id'] ?>" 
                                       class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors">
                                        <i class="fas fa-chart-bar mr-1"></i> View Results
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($isAdmin): ?>
                                    <div class="flex space-x-2">
                                        <a href="<?= BASE_URL ?>/admin/elections/edit?id=<?= $election['id'] ?>" 
                                           class="text-blue-600 hover:text-blue-800 transition-colors" title="Edit Election">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?= BASE_URL ?>/admin/elections/delete?id=<?= $election['id'] ?>" 
                                           class="text-red-600 hover:text-red-800 transition-colors" 
                                           title="Delete Election"
                                           onclick="return confirm('Are you sure you want to delete this election? This action cannot be undone.')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
            <div class="mt-12 flex justify-between items-center">
                <div class="text-sm text-gray-600">
                    Showing <?= $offset + 1 ?> to <?= min($offset + $limit, $totalElections) ?> of <?= $totalElections ?> elections
                </div>
                <nav class="flex items-center gap-2">
                    <?php if ($page > 1): ?>
                        <a href="?page=1<?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= $status_filter !== 'all' ? '&status=' . $status_filter : '' ?>" 
                           class="px-3 py-1 rounded border border-gray-300 hover:bg-gray-100">
                            <i class="fas fa-angle-double-left"></i>
                        </a>
                        <a href="?page=<?= $page - 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= $status_filter !== 'all' ? '&status=' . $status_filter : '' ?>" 
                           class="px-3 py-1 rounded border border-gray-300 hover:bg-gray-100">
                            <i class="fas fa-angle-left"></i>
                        </a>
                    <?php endif; ?>

                    <?php 
                    // Show limited page numbers for better UX
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $startPage + 4);
                    
                    if ($endPage - $startPage < 4) {
                        $startPage = max(1, $endPage - 4);
                    }
                    
                    for ($i = $startPage; $i <= $endPage; $i++): ?>
                        <a href="?page=<?= $i ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= $status_filter !== 'all' ? '&status=' . $status_filter : '' ?>" 
                           class="px-3 py-1 rounded border <?= $i == $page ? 'bg-pink-900 text-white border-pink-900' : 'border-gray-300 hover:bg-gray-100' ?>">
                            <?= $i ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?= $page + 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= $status_filter !== 'all' ? '&status=' . $status_filter : '' ?>" 
                           class="px-3 py-1 rounded border border-gray-300 hover:bg-gray-100">
                            <i class="fas fa-angle-right"></i>
                        </a>
                        <a href="?page=<?= $totalPages ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= $status_filter !== 'all' ? '&status=' . $status_filter : '' ?>" 
                           class="px-3 py-1 rounded border border-gray-300 hover:bg-gray-100">
                            <i class="fas fa-angle-double-right"></i>
                        </a>
                    <?php endif; ?>
                </nav>
            </div>
        <?php endif; ?>
    </div>

    <!-- JavaScript for filtering and search -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Apply filters button
        const applyFiltersBtn = document.getElementById('apply-filters');
        const searchInput = document.getElementById('search');
        const statusFilter = document.getElementById('status-filter');
        
        if (applyFiltersBtn) {
            applyFiltersBtn.addEventListener('click', function() {
                const search = searchInput.value;
                const status = statusFilter.value;
                
                const params = new URLSearchParams();
                if (search) params.set('search', search);
                if (status !== 'all') params.set('status', status);
                
                window.location.href = '?' + params.toString();
            });
        }
        
        // Filter elections by status
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                // Update active button
                filterButtons.forEach(b => {
                    b.classList.remove('active', 'bg-pink-900', 'text-white');
                    b.classList.add('border', 'border-gray-300');
                });
                this.classList.add('active', 'bg-pink-900', 'text-white');
                this.classList.remove('border', 'border-gray-300');
                
                // Filter election cards
                const filter = this.dataset.filter;
                document.querySelectorAll('.election-card').forEach(card => {
                    if (filter === 'all') {
                        card.style.display = 'block';
                    } else {
                        const status = card.querySelector('.status-badge').textContent.toLowerCase();
                        card.style.display = status.includes(filter) ? 'block' : 'none';
                    }
                });
            });
        });

        // Initialize with active filter
        if (filterButtons.length > 0) {
            document.querySelector('.filter-btn.active').click();
        }
        
        // Enter key in search field
        if (searchInput) {
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    applyFiltersBtn.click();
                }
            });
        }
    });
    </script>

    <?php include APP_ROOT . '/includes/footer.php'; ?>
</body>
</html>