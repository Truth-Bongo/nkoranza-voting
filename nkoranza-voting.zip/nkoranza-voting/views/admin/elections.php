<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/db_connect.php';
require_once __DIR__ . '/../../helpers/functions.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Only admin should view this page
if (empty($_SESSION['is_admin'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once APP_ROOT . '/includes/header.php';
$db = Database::getInstance()->getConnection();

// Set timezone to Africa/Accra (Ghana)
date_default_timezone_set('Africa/Accra');

// Auto-update election statuses before display
$now = date('Y-m-d H:i:s');
$db->exec("
    UPDATE elections 
    SET status = CASE
        WHEN '$now' < start_date THEN 'upcoming'
        WHEN '$now' <= end_date THEN 'active'
        ELSE 'ended'
    END
");

// Handle search and filter
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? 'all';

// Build query with filters
$query = "SELECT * FROM elections WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (title LIKE :search OR description LIKE :search)";
    $params[':search'] = "%$search%";
}

if ($status_filter !== 'all') {
    $query .= " AND status = :status";
    $params[':status'] = $status_filter;
}

$query .= " ORDER BY start_date DESC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$elections = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics for dashboard
$stats_stmt = $db->query("
    SELECT 
        status,
        COUNT(*) as count
    FROM elections 
    GROUP BY status
");
$stats = $stats_stmt->fetchAll(PDO::FETCH_ASSOC);

$status_counts = [
    'active' => 0,
    'upcoming' => 0,
    'ended' => 0,
    'all' => count($elections)
];

foreach ($stats as $stat) {
    $status_counts[$stat['status']] = $stat['count'];
}

function js_json($data) {
    return json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
}
?>

<div class="max-w-7xl mx-auto">
  <div class="flex justify-between items-center mb-8">
    <div>
      <h2 class="text-3xl font-bold text-gray-900">Elections Management</h2>
      <p class="text-gray-900">Manage active, upcoming, and past elections</p>
    </div>
    <button id="add-election-btn" class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-2 rounded text-sm transition-colors">
      <i class="fas fa-plus mr-1"></i> Add Election
    </button>
  </div>

  <!-- Statistics Cards -->
  <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div class="flex items-center">
        <div class="bg-blue-100 p-3 rounded-full mr-4">
          <i class="fas fa-calendar-alt text-blue-600"></i>
        </div>
        <div>
          <p class="text-sm text-gray-600">Total Elections</p>
          <p class="text-2xl font-bold text-gray-900"><?= $status_counts['all'] ?></p>
        </div>
      </div>
    </div>
    <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div class="flex items-center">
        <div class="bg-green-100 p-3 rounded-full mr-4">
          <i class="fas fa-vote-yea text-green-600"></i>
        </div>
        <div>
          <p class="text-sm text-gray-600">Active</p>
          <p class="text-2xl font-bold text-gray-900"><?= $status_counts['active'] ?></p>
        </div>
      </div>
    </div>
    <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div class="flex items-center">
        <div class="bg-yellow-100 p-3 rounded-full mr-4">
          <i class="fas fa-clock text-yellow-600"></i>
        </div>
        <div>
          <p class="text-sm text-gray-600">Upcoming</p>
          <p class="text-2xl font-bold text-gray-900"><?= $status_counts['upcoming'] ?></p>
        </div>
      </div>
    </div>
    <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div class="flex items-center">
        <div class="bg-red-100 p-3 rounded-full mr-4">
          <i class="fas fa-times-circle text-red-600"></i>
        </div>
        <div>
          <p class="text-sm text-gray-600">Ended</p>
          <p class="text-2xl font-bold text-gray-900"><?= $status_counts['ended'] ?></p>
        </div>
      </div>
    </div>
  </div>

  <!-- Search and Filter Section -->
  <div class="bg-white p-4 rounded-lg shadow-md mb-6">
    <div class="flex flex-col md:flex-row gap-4">
      <div class="flex-1">
        <label for="search" class="sr-only">Search</label>
        <div class="relative">
          <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <i class="fas fa-search text-gray-400"></i>
          </div>
          <input type="text" id="search" name="search" value="<?= htmlspecialchars($search) ?>" 
                 placeholder="Search elections..." class="block pl-10 pr-3 py-2 border border-gray-300 rounded-md">
        </div>
      </div>
      <div class="w-full md:w-48">
        <label for="status-filter" class="sr-only">Filter by status</label>
        <select id="status-filter" name="status" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md">
          <option value="all" <?= $status_filter === 'all' ? 'selected' : '' ?>>All Statuses</option>
          <option value="active" <?= $status_filter === 'active' ? 'selected' : '' ?>>Active</option>
          <option value="upcoming" <?= $status_filter === 'upcoming' ? 'selected' : '' ?>>Upcoming</option>
          <option value="ended" <?= $status_filter === 'ended' ? 'selected' : '' ?>>Ended</option>
        </select>
      </div>
      <div>
        <button id="apply-filters" class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-2 rounded-md">
          Apply Filters
        </button>
      </div>
    </div>
  </div>

  <div class="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
    <div class="card">
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Date</th>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Date</th>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Candidates</th>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <?php if (!empty($elections)): ?>
              <?php foreach ($elections as $election): 
                // Get candidate count for this election
                $candidate_stmt = $db->prepare("SELECT COUNT(*) as count FROM candidates WHERE election_id = :election_id");
                $candidate_stmt->execute([':election_id' => $election['id']]);
                $candidate_count = $candidate_stmt->fetch(PDO::FETCH_ASSOC)['count'];
              ?>
                <tr>
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    <div class="font-semibold"><?= htmlspecialchars($election['title']) ?></div>
                    <?php if (!empty($election['description'])): ?>
                      <div class="text-xs text-gray-500 mt-1"><?= htmlspecialchars(substr($election['description'], 0, 50)) ?>...</div>
                    <?php endif; ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?= date('M j, Y H:i', strtotime($election['start_date'])) ?></td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?= date('M j, Y H:i', strtotime($election['end_date'])) ?></td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                      <?= $election['status'] === 'active' ? 'bg-green-100 text-green-800' :
                          ($election['status'] === 'upcoming' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') ?>">
                      <?= ucfirst($election['status']) ?>
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      <?= $candidate_count ?> candidates
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div class="flex space-x-2">
                      <a href="<?= BASE_URL ?>/admin/candidates?election_id=<?= $election['id'] ?>" 
                         class="text-indigo-600 hover:text-indigo-900" title="Manage Candidates">
                        <i class="fas fa-users"></i>
                      </a>
                      <button class="edit-election-btn text-blue-600 hover:text-blue-900" 
                              data-election='<?= js_json($election) ?>' title="Edit Election">
                        <i class="fas fa-edit"></i>
                      </button>
                      <button class="delete-election-btn text-red-600 hover:text-red-900" 
                              data-id="<?= $election['id'] ?>" title="Delete Election">
                        <i class="fas fa-trash"></i>
                      </button>
                      <?php if ($election['status'] === 'ended'): ?>
                        <a href="<?= BASE_URL ?>/admin/results?election_id=<?= $election['id'] ?>" 
                           class="text-green-600 hover:text-green-900" title="View Results">
                          <i class="fas fa-chart-bar"></i>
                        </a>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="6" class="text-center py-8 text-gray-500">
                  <i class="fas fa-calendar-times text-4xl mb-3 text-gray-300"></i>
                  <p>No elections found</p>
                  <?php if (!empty($search) || $status_filter !== 'all'): ?>
                    <p class="text-sm mt-2">Try adjusting your search or filters</p>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Export Section -->
    <div class="mt-6 flex justify-between items-center">
      <div class="text-sm text-gray-600">
        Showing <?= count($elections) ?> election(s)
      </div>
      <div>
        <button id="export-elections" class="bg-gray-700 hover:bg-gray-800 text-white px-4 py-2 rounded text-sm transition-colors">
          <i class="fas fa-file-export mr-1"></i> Export to CSV
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Add/Edit Election Modal -->
<div id="add-election-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
  <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
    <div class="flex justify-between items-center mb-4">
      <h3 class="text-lg font-bold text-pink-900" id="modal-title">Add Election</h3>
      <button type="button" onclick="hideModal()" class="text-gray-500 hover:text-gray-700">
        <i class="fas fa-times"></i>
      </button>
    </div>
    <form id="election-form">
      <input type="hidden" id="election-id" name="id">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">

      <div class="mb-4">
        <label for="election-title" class="block text-sm font-medium text-gray-700">Title *</label>
        <input type="text" id="election-title" name="title" required class="mt-1 block w-full border border-gray-300 rounded-md p-2">
      </div>

      <div class="mb-4">
        <label for="election-description" class="block text-sm font-medium text-gray-700">Description</label>
        <textarea id="election-description" name="description" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md p-2"></textarea>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label for="start-date" class="block text-sm font-medium text-gray-700">Start Date *</label>
          <input type="datetime-local" id="start-date" name="start_date" required class="mt-1 block w-full border border-gray-300 rounded-md p-2">
        </div>
        <div>
          <label for="end-date" class="block text-sm font-medium text-gray-700">End Date *</label>
          <input type="datetime-local" id="end-date" name="end_date" required class="mt-1 block w-full border border-gray-300 rounded-md p-2">
        </div>
      </div>

      <div id="form-error" class="mb-4 text-red-600 text-sm hidden"></div>

      <div class="flex justify-end space-x-2">
        <button type="button" onclick="hideModal()" class="px-4 py-2 border border-gray-300 rounded text-gray-700 hover:bg-gray-100">Cancel</button>
        <button type="submit" class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-2 rounded">Save Election</button>
      </div>
    </form>
  </div>
</div>

<?php require_once APP_ROOT . '/includes/footer.php'; ?>

<script>
// Global variables
const BASE_URL = '<?= BASE_URL ?>';
const CSRF_TOKEN = '<?= $_SESSION['csrf_token'] ?>';

document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('add-election-modal');
  const form = document.getElementById('election-form');
  const modalTitle = document.getElementById('modal-title');
  const idEl = document.getElementById('election-id');
  const titleEl = document.getElementById('election-title');
  const descEl = document.getElementById('election-description');
  const startEl = document.getElementById('start-date');
  const endEl = document.getElementById('end-date');
  const errorEl = document.getElementById('form-error');
  const openBtn = document.getElementById('add-election-btn');
  const searchEl = document.getElementById('search');
  const statusFilterEl = document.getElementById('status-filter');
  const applyFiltersBtn = document.getElementById('apply-filters');
  const exportBtn = document.getElementById('export-elections');

  // Show modal function
  function showModal() {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }

  // Hide modal function
  function hideModal() {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
    form.reset();
    idEl.value = '';
    errorEl.classList.add('hidden');
    errorEl.textContent = '';
    modalTitle.textContent = 'Add Election';
  }

  // Apply filters
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener('click', () => {
      const search = searchEl.value;
      const status = statusFilterEl.value;
      
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (status !== 'all') params.set('status', status);
      
      window.location.href = window.location.pathname + '?' + params.toString();
    });
  }

  // Export to CSV
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      const search = searchEl.value;
      const status = statusFilterEl.value;
      
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (status !== 'all') params.set('status', status);
      params.set('export', 'csv');
      
      window.location.href = window.location.pathname + '?' + params.toString();
    });
  }

  // Add button click handler
  if (openBtn) {
    openBtn.addEventListener('click', () => {
      form.reset();
      idEl.value = '';
      modalTitle.textContent = 'Add Election';
      
      // Set default dates (now and 1 day from now)
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      startEl.value = formatDateTimeLocal(now);
      endEl.value = formatDateTimeLocal(tomorrow);
      
      showModal();
    });
  }

  // Edit buttons
  document.querySelectorAll('.edit-election-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const election = JSON.parse(btn.dataset.election);
      idEl.value = election.id;
      titleEl.value = election.title || '';
      descEl.value = election.description || '';
      
      // Convert UTC times to local datetime-local format
      if (election.start_date) {
        const startDate = new Date(election.start_date);
        startEl.value = formatDateTimeLocal(startDate);
      }
      
      if (election.end_date) {
        const endDate = new Date(election.end_date);
        endEl.value = formatDateTimeLocal(endDate);
      }
      
      modalTitle.textContent = 'Edit Election';
      showModal();
    });
  });

  // Format date for datetime-local input
  function formatDateTimeLocal(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  }

  // Delete buttons
  document.querySelectorAll('.delete-election-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('Are you sure you want to delete this election? This action cannot be undone.')) return;
      
      const id = btn.dataset.id;

      try {
        const response = await fetch(`${BASE_URL}/api/admin/elections.php?id=${encodeURIComponent(id)}`, {
          method: 'DELETE',
          headers: {
            'X-CSRF-Token': CSRF_TOKEN,
            'Content-Type': 'application/json'
          }
        });

        const data = await response.json();
        
        if (data.success) {
          alert('Election deleted successfully');
          location.reload();
        } else {
          alert(data.message || 'Failed to delete election');
        }
      } catch (error) {
        console.error('Delete error:', error);
        alert('Network error while deleting election');
      }
    });
  });

  // Form submission handler
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Validate dates
    const startDate = new Date(startEl.value);
    const endDate = new Date(endEl.value);
    const now = new Date();
    
    if (endDate <= startDate) {
      showError('End date must be after start date');
      return;
    }
    
    if (startDate <= now) {
      showError('Start date must be in the future');
      return;
    }

    const formData = new FormData(form);
    const isEdit = !!idEl.value;
    const url = `${BASE_URL}/api/admin/elections.php${isEdit ? `?id=${encodeURIComponent(idEl.value)}` : ''}`;

    try {
      const response = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        body: formData
      });

      const data = await response.json();
      
      if (data.success) {
        hideModal();
        alert('Election saved successfully');
        location.reload();
      } else {
        showError(data.message || 'Failed to save election');
      }
    } catch (error) {
      console.error('Save error:', error);
      showError('Network error while saving election');
    }
  });

  // Show error message
  function showError(message) {
    errorEl.textContent = message;
    errorEl.classList.remove('hidden');
  }

  // Close modal when clicking outside
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      hideModal();
    }
  });

  // Close modal with Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
      hideModal();
    }
  });

  // Expose hideModal globally for the cancel button
  window.hideModal = hideModal;
});
</script>