<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/db_connect.php';
require_once __DIR__ . '/../../helpers/functions.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Only admin should view this page
if (empty($_SESSION['is_admin'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

// Get page number from query string
$page = isset($_GET['p']) && is_numeric($_GET['p']) ? (int)$_GET['p'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

try {
    $db = Database::getInstance()->getConnection();
    
    // Get total count for pagination
    $countStmt = $db->query("SELECT COUNT(*) as total FROM users WHERE is_admin = 0");
    $totalVoters = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    $totalPages = ceil($totalVoters / $limit);
    
    // Get voters with pagination
    $stmt = $db->prepare("SELECT id, first_name, last_name, department, level, email, has_voted 
                         FROM users WHERE is_admin = 0 ORDER BY id ASC LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $voters = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
    $voters = [];
    $totalVoters = 0;
    $totalPages = 1;
}

require_once APP_ROOT . '/includes/header.php';

// Get current URL without page parameter to build pagination links
$currentUrl = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$queryParams = $_GET;
unset($queryParams['p']);
$baseUrl = $currentUrl . (!empty($queryParams) ? '?' . http_build_query($queryParams) . '&' : '?');
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between items-center mb-8">
        <div>
            <h2 class="text-3xl font-bold text-gray-900">Voters Management</h2>
            <p class="text-gray-600">Manage voter registration and information</p>
        </div>
        <div class="flex space-x-3">
            <button onclick="showModal('import-voters-modal')" class="bg-gray-700 hover:bg-gray-800 text-white px-4 py-2 rounded text-sm transition-colors">
                <i class="fas fa-file-import mr-1"></i> Import CSV
            </button>
            <button onclick="openAddVoterModal()" class="bg-pink-700 hover:bg-pink-800 text-white px-4 py-2 rounded text-sm transition-colors">
                <i class="fas fa-plus mr-1"></i> Add Voter
            </button>
        </div>
    </div>

    <!-- Stats Overview Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <?php
        try {
            $statsStmt = $db->query("
                SELECT 
                    COUNT(*) as total,
                    SUM(has_voted) as voted,
                    COUNT(*) - SUM(has_voted) as not_voted
                FROM users
                WHERE is_admin = 0
            ");
            $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $stats = ['total' => 0, 'voted' => 0, 'not_voted' => 0];
        }
        ?>
        <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
            <div class="flex items-center">
                <div class="bg-blue-100 p-3 rounded-full mr-4">
                    <i class="fas fa-users text-blue-600"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Total Voters</p>
                    <p class="text-2xl font-bold text-gray-900"><?= htmlspecialchars($stats['total']) ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
            <div class="flex items-center">
                <div class="bg-green-100 p-3 rounded-full mr-4">
                    <i class="fas fa-vote-yea text-green-600"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Voted</p>
                    <p class="text-2xl font-bold text-gray-900"><?= htmlspecialchars($stats['voted']) ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
            <div class="flex items-center">
                <div class="bg-red-100 p-3 rounded-full mr-4">
                    <i class="fas fa-times-circle text-red-600"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Not Voted</p>
                    <p class="text-2xl font-bold text-gray-900"><?= htmlspecialchars($stats['not_voted']) ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
            <div class="flex items-center">
                <div class="bg-purple-100 p-3 rounded-full mr-4">
                    <i class="fas fa-percentage text-purple-600"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Participation</p>
                    <p class="text-2xl font-bold text-gray-900">
                        <?= $stats['total'] > 0 ? round(($stats['voted'] / $stats['total']) * 100, 1) : 0 ?>%
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
        <div class="mb-4 flex justify-between items-center">
            <div class="relative max-w-xs">
                <label for="voter-search" class="sr-only">Search</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="fas fa-search text-gray-400"></i>
                    </div>
                    <input type="text" id="voter-search" placeholder="Search voters..." 
                           class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white 
                                  placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary sm:text-sm" 
                           oninput="searchVoters(this.value)">
                </div>
            </div>
            <div class="flex items-center space-x-2">
                <span class="text-sm text-gray-600">Filter by:</span>
                <select class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md
                              focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary sm:text-sm" 
                        onchange="filterVoters(this.value)">
                    <option value="all">All Voters</option>
                    <option value="voted">Voted Only</option>
                    <option value="not_voted">Not Voted Only</option>
                </select>
            </div>
        </div>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Student ID
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Full Name
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Email
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Program
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Level
                        </th>
                        <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Voted
                        </th>
                        <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody id="voters-table-body" class="bg-white divide-y divide-gray-200">
                    <?php foreach ($voters as $voter): ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            <?= htmlspecialchars($voter['id']) ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <?= htmlspecialchars($voter['first_name'] . ' ' . $voter['last_name']) ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <?= htmlspecialchars($voter['email']) ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <?= htmlspecialchars($voter['department']) ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <?= htmlspecialchars($voter['level']) ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-center">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?= $voter['has_voted'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                <?= $voter['has_voted'] ? 'Yes' : 'No' ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-center">
                            <div class="flex space-x-2 justify-center">
                                <button onclick='editVoter(<?= json_encode($voter) ?>)' 
                                        class="text-blue-600 hover:text-blue-800 transition-colors"
                                        title="Edit Voter">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button onclick="confirmDeleteVoter('<?= htmlspecialchars($voter['id']) ?>')" 
                                        class="text-red-600 hover:text-red-800 transition-colors"
                                        title="Delete Voter">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if (empty($voters)): ?>
            <div class="text-center py-8 text-gray-500">
                <i class="fas fa-users text-4xl mb-3 text-gray-300"></i>
                <p>No voters found</p>
            </div>
        <?php endif; ?>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
<div class="mt-6 flex justify-between items-center">
    <div class="text-sm text-gray-600">
        Showing <span class="font-medium"><?= $offset + 1 ?></span> to 
        <span class="font-medium"><?= min($offset + $limit, $totalVoters) ?></span> of 
        <span class="font-medium"><?= $totalVoters ?></span> voters
    </div>
    <nav class="flex space-x-2">
        <?php if ($page > 1): ?>
            <a href="<?= $baseUrl ?>p=<?= $page - 1 ?>" 
               class="px-3 py-1 border border-gray-300 rounded text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                Previous
            </a>
        <?php else: ?>
            <span class="px-3 py-1 border border-gray-300 rounded text-sm font-medium text-gray-400 bg-gray-100 cursor-not-allowed">
                Previous
            </span>
        <?php endif; ?>
        
        <?php 
        // Show limited page numbers for better UX
        $startPage = max(1, $page - 2);
        $endPage = min($totalPages, $startPage + 4);
        
        if ($endPage - $startPage < 4) {
            $startPage = max(1, $endPage - 4);
        }
        
        for ($i = $startPage; $i <= $endPage; $i++): ?>
            <a href="<?= $baseUrl ?>p=<?= $i ?>" 
               class="px-3 py-1 border rounded text-sm font-medium <?= $i == $page ? 'bg-gray-900 text-white border-gray-900' : 'text-gray-700 bg-white border-gray-300 hover:bg-gray-50' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
        
        <?php if ($page < $totalPages): ?>
            <a href="<?= $baseUrl ?>p=<?= $page + 1 ?>" 
               class="px-3 py-1 border border-gray-300 rounded text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                Next
            </a>
        <?php else: ?>
            <span class="px-3 py-1 border border-gray-300 rounded text-sm font-medium text-gray-400 bg-gray-100 cursor-not-allowed">
                Next
            </span>
        <?php endif; ?>
    </nav>
</div>
<?php endif; ?>

<!-- Loading Spinner -->
<div id="loading-spinner" class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-lg shadow-lg flex items-center">
        <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mr-3"></div>
        <span>Processing...</span>
    </div>
</div>

<!-- Notification Toast -->
<div id="toast" class="fixed top-4 right-4 p-4 rounded-lg shadow-lg bg-gray-800 text-white transition-opacity duration-300 opacity-0 hidden z-50">
    <div class="flex items-center">
        <span id="toast-message"></span>
        <button onclick="hideToast()" class="ml-4 text-white hover:text-gray-300">
            <i class="fas fa-times"></i>
        </button>
    </div>
</div>

<script>
// Global variables
const API_BASE = '<?= BASE_URL ?>';
const CSRF_TOKEN = '<?= $_SESSION['csrf_token'] ?>';
let allVoters = <?= json_encode($voters) ?>;

// Utility functions
function escapeHtml(unsafe) {
    if (unsafe === null || unsafe === undefined) return '';
    return String(unsafe)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function showLoading() {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) spinner.classList.remove('hidden');
}

function hideLoading() {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) spinner.classList.add('hidden');
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');
    
    if (!toast || !toastMessage) return;
    
    toastMessage.textContent = message;
    toast.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg transition-opacity duration-300 z-50 ${
        type === 'success' ? 'bg-green-600' : 'bg-red-600'
    } text-white`;
    toast.classList.remove('hidden', 'opacity-0');
    
    setTimeout(() => {
        toast.classList.add('opacity-100');
    }, 10);
    
    setTimeout(hideToast, 5000);
}

function hideToast() {
    const toast = document.getElementById('toast');
    if (!toast) return;
    
    toast.classList.remove('opacity-100');
    setTimeout(() => {
        toast.classList.add('hidden');
    }, 300);
}

// Modal functions
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }
}

// Voter management functions
function searchVoters(query) {
    const searchTerm = query.toLowerCase().trim();
    const filteredVoters = allVoters.filter(voter => {
        const searchString = `${voter.id} ${voter.first_name} ${voter.last_name} ${voter.email} ${voter.department} ${voter.level}`.toLowerCase();
        return searchString.includes(searchTerm);
    });
    renderVotersTable(filteredVoters);
}

function filterVoters(filterType) {
    let filteredVoters = allVoters;
    
    switch (filterType) {
        case 'voted':
            filteredVoters = allVoters.filter(voter => voter.has_voted);
            break;
        case 'not_voted':
            filteredVoters = allVoters.filter(voter => !voter.has_voted);
            break;
    }
    
    renderVotersTable(filteredVoters);
}

function renderVotersTable(voters) {
    const tbody = document.getElementById('voters-table-body');
    if (!tbody) return;
    
    tbody.innerHTML = voters.map(voter => `
        <tr class="hover:bg-gray-50">
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${escapeHtml(voter.id)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(voter.first_name)} ${escapeHtml(voter.last_name)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(voter.email)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(voter.department)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(voter.level)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-center">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${voter.has_voted ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                    ${voter.has_voted ? 'Yes' : 'No'}
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-center">
                <div class="flex space-x-2 justify-center">
                    <button onclick='editVoter(${JSON.stringify(voter)})' 
                            class="text-blue-600 hover:text-blue-800 transition-colors"
                            title="Edit Voter">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button onclick="confirmDeleteVoter('${escapeHtml(voter.id)}')" 
                            class="text-red-600 hover:text-red-800 transition-colors"
                            title="Delete Voter">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

function openAddVoterModal() {
    const form = document.getElementById('voter-form');
    if (form) {
        form.reset();
        document.getElementById('form-title').textContent = 'Add New Voter';
        document.getElementById('submit-btn').textContent = 'Add Voter';
        document.getElementById('is-edit').value = 'false';
        const voterIdField = document.getElementById('voter-id');
        if (voterIdField) {
            voterIdField.removeAttribute('readonly');
            voterIdField.value = '';
        }
    }
    showModal('add-voter-modal');
}

function editVoter(voter) {
    console.log('Editing voter:', voter);
    const form = document.getElementById('voter-form');
    if (form) {
        form.reset();
        document.getElementById('form-title').textContent = 'Edit Voter';
        document.getElementById('submit-btn').textContent = 'Update Voter';
        document.getElementById('is-edit').value = 'true';
        document.getElementById('voter-id').value = voter.id || '';
        document.getElementById('voter-id').setAttribute('readonly', 'readonly');
        document.getElementById('voter-firstname').value = voter.first_name || '';
        document.getElementById('voter-lastname').value = voter.last_name || '';
        document.getElementById('voter-email').value = voter.email || '';
        document.getElementById('voter-department').value = voter.department || '';
        document.getElementById('voter-level').value = voter.level || '';
    }
    showModal('add-voter-modal');
}

async function confirmDeleteVoter(voterId) {
    if (!confirm(`Are you sure you want to delete voter ${voterId}? This action cannot be undone.`)) {
        return;
    }
    
    try {
        showLoading();
        const response = await fetch(`${API_BASE}/api/admin/voters.php?id=${encodeURIComponent(voterId)}`, {
        method: 'DELETE',
        headers: {
            'X-CSRF-Token': CSRF_TOKEN
        }
    });
            
        // Check if response is JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            console.error('Non-JSON response:', text);
            throw new Error('Server returned an invalid response');
        }
        
        const data = await response.json();
        
        if (data.success) {
            showToast('Voter deleted successfully');
            // Reload after a short delay
            setTimeout(() => location.reload(), 1000);
        } else {
            throw new Error(data.message || 'Failed to delete voter');
        }
    } catch (error) {
        console.error('Delete error:', error);
        showToast(error.message, 'error');
    } finally {
        hideLoading();
    }
}

// Form submission handling
document.addEventListener('DOMContentLoaded', function() {
    // Voter form submission
    const voterForm = document.getElementById('voter-form');
    if (voterForm) {
        voterForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(voterForm);
            formData.append('csrf_token', CSRF_TOKEN);
            
            try {
                showLoading();
                const response = await fetch(`${API_BASE}/api/admin/voters.php`, {
                    method: 'POST',
                    body: formData
                });
                
                // Check if response is JSON
                const contentType = response.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    const text = await response.text();
                    console.error('Non-JSON response:', text);
                    throw new Error('Server returned an invalid response');
                }
                
                const data = await response.json();
                
                if (data.success) {
                    showToast(data.message || 'Voter saved successfully');
                    hideModal('add-voter-modal');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    throw new Error(data.message || 'Failed to save voter');
                }
            } catch (error) {
                console.error('Save error:', error);
                showToast(error.message, 'error');
            } finally {
                hideLoading();
            }
        });
    }
    
    // Import form handling
    const importForm = document.getElementById('import-form');
    const fileInput = document.getElementById('voter-file');
    const fileName = document.getElementById('csv-filename');
    
    if (fileInput && fileName) {
        fileInput.addEventListener('change', function() {
            fileName.textContent = this.files[0]?.name || 'No file chosen';
        });
    }
    
    if (importForm) {
        importForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            if (!fileInput.files[0]) {
                showToast('Please select a CSV file to import', 'error');
                return;
            }
            
            const formData = new FormData(importForm);
            formData.append('csrf_token', CSRF_TOKEN);
            
            try {
                showLoading();
                const response = await fetch(`${API_BASE}/api/admin/import_voters.php`, {
                    method: 'POST',
                    body: formData
                });
                
                // Check if response is JSON
                const contentType = response.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    const text = await response.text();
                    console.error('Non-JSON response:', text);
                    throw new Error('Server returned an invalid response');
                }
                
                const data = await response.json();
                
                if (data.success) {
                    showToast(data.message || 'Voters imported successfully');
                    hideModal('import-voters-modal');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    throw new Error(data.message || 'Failed to import voters');
                }
            } catch (error) {
                console.error('Import error:', error);
                showToast(error.message, 'error');
            } finally {
                hideLoading();
            }
        });
    }
    
    // Close modals when clicking outside
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-overlay')) {
            const modalId = e.target.id;
            hideModal(modalId);
        }
    });
    
    // Close modals with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const modals = document.querySelectorAll('.modal-overlay:not(.hidden)');
            modals.forEach(modal => hideModal(modal.id));
        }
    });
    
    // Close modal buttons
    document.querySelectorAll('.modal-close').forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal-overlay');
            if (modal) {
                hideModal(modal.id);
            }
        });
    });
    
    // Initialize the table with all voters
    renderVotersTable(allVoters);
});
</script>

<?php require APP_ROOT . '/views/modals/import_voters.php'; ?>
<?php require APP_ROOT . '/views/modals/add_voter.php'; ?>
<?php require_once APP_ROOT . '/includes/footer.php'; ?>