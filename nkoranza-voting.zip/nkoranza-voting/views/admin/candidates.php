<?php 
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/db_connect.php';
require_once __DIR__ . '/../../helpers/functions.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Only admin should view this page
if (empty($_SESSION['is_admin'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once APP_ROOT . '/includes/header.php'; 

// ----------------------
// Load Candidates with search and filter
// ----------------------
$db = Database::getInstance()->getConnection();

// Handle search and filter parameters
$search = $_GET['search'] ?? '';
$election_filter = $_GET['election'] ?? '';
$position_filter = $_GET['position'] ?? '';

// Build query with filters (REMOVED created_at column)
$query = "
    SELECT 
        c.id,
        c.election_id,
        c.position_id,
        c.user_id,
        c.manifesto,
        c.photo_path,
        e.title AS election_title,
        p.name  AS position_name,
        u.first_name,
        u.last_name,
        u.department,
        u.email
    FROM candidates c
    LEFT JOIN elections e ON c.election_id = e.id
    LEFT JOIN positions p ON c.position_id = p.id
    LEFT JOIN users u ON c.user_id = u.id
    WHERE 1=1
";

$params = [];

if (!empty($search)) {
    $query .= " AND (u.first_name LIKE :search OR u.last_name LIKE :search OR u.email LIKE :search OR p.name LIKE :search OR e.title LIKE :search)";
    $params[':search'] = "%$search%";
}

if (!empty($election_filter)) {
    $query .= " AND c.election_id = :election_id";
    $params[':election_id'] = $election_filter;
}

if (!empty($position_filter)) {
    $query .= " AND c.position_id = :position_id";
    $params[':position_id'] = $position_filter;
}

$query .= " ORDER BY e.start_date DESC, p.name ASC, u.first_name ASC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$candidates = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Load elections for filter dropdown
$elections = $db->query("SELECT id, title FROM elections ORDER BY title ASC")->fetchAll(PDO::FETCH_ASSOC);

// Load positions for filter dropdown
$positions = $db->query("SELECT id, name FROM positions ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$stats_stmt = $db->query("
    SELECT 
        COUNT(*) as total_candidates,
        COUNT(DISTINCT election_id) as total_elections,
        COUNT(DISTINCT position_id) as total_positions
    FROM candidates
");
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
?>

<div class="max-w-7xl mx-auto">
  <div class="flex justify-between items-center mb-8">
    <div>
      <h2 class="text-3xl font-bold text-gray-900">Candidates Management</h2>
      <p class="text-gray-900">Add and Manage all election candidates</p>
    </div>
    <button onclick="showModal('add-candidate-modal')" class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-2 rounded text-sm transition-colors">
      <i class="fas fa-plus mr-1"></i> Add Candidate
    </button>
  </div>

  <!-- Statistics Cards -->
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
    <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div class="flex items-center">
        <div class="bg-blue-100 p-3 rounded-full mr-4">
          <i class="fas fa-users text-blue-600"></i>
        </div>
        <div>
          <p class="text-sm text-gray-600">Total Candidates</p>
          <p class="text-2xl font-bold text-gray-900"><?= $stats['total_candidates'] ?></p>
        </div>
      </div>
    </div>
    <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div class="flex items-center">
        <div class="bg-green-100 p-3 rounded-full mr-4">
          <i class="fas fa-vote-yea text-green-600"></i>
        </div>
        <div>
          <p class="text-sm text-gray-600">Elections</p>
          <p class="text-2xl font-bold text-gray-900"><?= $stats['total_elections'] ?></p>
        </div>
      </div>
    </div>
    <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div class="flex items-center">
        <div class="bg-purple-100 p-3 rounded-full mr-4">
          <i class="fas fa-briefcase text-purple-600"></i>
        </div>
        <div>
          <p class="text-sm text-gray-600">Positions</p>
          <p class="text-2xl font-bold text-gray-900"><?= $stats['total_positions'] ?></p>
        </div>
      </div>
    </div>
  </div>

  <!-- Search and Filter Section -->
  <div class="bg-white p-4 rounded-lg shadow-md mb-6">
    <div class="flex flex-col md:flex-row gap-4">
      <div class="flex-1">
        <label for="search" class="sr-only">Search</label>
        <div class="relative">
          <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <i class="fas fa-search text-gray-400"></i>
          </div>
          <input type="text" id="search" name="search" value="<?= htmlspecialchars($search) ?>" 
                 placeholder="Search candidates..." class="block pl-10 pr-3 py-2 border border-gray-300 rounded-md">
        </div>
      </div>
      <div class="w-full md:w-48">
        <label for="election-filter" class="sr-only">Filter by election</label>
        <select id="election-filter" name="election" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md">
          <option value="">All Elections</option>
          <?php foreach ($elections as $election): ?>
            <option value="<?= $election['id'] ?>" <?= $election_filter == $election['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($election['title']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="w-full md:w-48">
        <label for="position-filter" class="sr-only">Filter by position</label>
        <select id="position-filter" name="position" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md">
          <option value="">All Positions</option>
          <?php foreach ($positions as $position): ?>
            <option value="<?= $position['id'] ?>" <?= $position_filter == $position['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($position['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <button id="apply-filters" class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-2 rounded-md">
          Apply Filters
        </button>
      </div>
    </div>
  </div>

  <div class="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
    <table class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50">
        <tr>
          <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Photo</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Candidate</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Position</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Election</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
          <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
        </tr>
      </thead>
      <tbody class="bg-white divide-y divide-gray-200">
        <?php if (!empty($candidates)): ?>
          <?php foreach ($candidates as $candidate): ?>
            <tr class="hover:bg-gray-50">
              <!-- Candidate Photo -->
              <td class="px-6 py-4 whitespace-nowrap text-center">
                <?php 
                  $photo = !empty($candidate['photo_path']) 
                            ? BASE_URL . "/" . htmlspecialchars($candidate['photo_path']) 
                            : BASE_URL . "/assets/img/default-avatar.png";
                ?>
                <img src="<?= $photo ?>"
                    alt="Candidate Photo"
                    class="w-12 h-12 rounded-full object-cover border mx-auto" />
              </td>

              <!-- Candidate Name -->
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="font-medium text-gray-900">
                  <?= htmlspecialchars(($candidate['first_name'] ?? '') . ' ' . ($candidate['last_name'] ?? '')) ?>
                </div>
                <?php if (!empty($candidate['manifesto'])): ?>
                  <div class="text-xs text-gray-500 mt-1" title="<?= htmlspecialchars($candidate['manifesto']) ?>">
                    <?= htmlspecialchars(substr($candidate['manifesto'], 0, 50)) ?>...
                  </div>
                <?php endif; ?>
              </td>

              <!-- Position -->
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                <?= htmlspecialchars($candidate['position_name'] ?? '—') ?>
              </td>

              <!-- Election -->
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                <?= htmlspecialchars($candidate['election_title'] ?? '—') ?>
              </td>

              <!-- Department -->
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                <?= htmlspecialchars($candidate['department'] ?? '—') ?>
              </td>

              <!-- Actions -->
              <td class="px-6 py-4 whitespace-nowrap text-center">
                <div class="flex justify-center space-x-2">
                  <button onclick='editCandidate(<?= json_encode($candidate, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'
                          class="text-blue-600 hover:text-blue-800 transition-colors" title="Edit Candidate">
                    <i class="fas fa-edit"></i>
                  </button>
                  <button onclick="confirmDeleteCandidate(<?= (int)$candidate['id'] ?>)"
                          class="text-red-600 hover:text-red-800 transition-colors" title="Delete Candidate">
                    <i class="fas fa-trash"></i>
                  </button>
                  <button onclick='viewCandidate(<?= json_encode($candidate, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'
                          class="text-green-600 hover:text-green-800 transition-colors" title="View Details">
                    <i class="fas fa-eye"></i>
                  </button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="7" class="px-6 py-8 text-center text-gray-500">
              <i class="fas fa-users text-4xl mb-3 text-gray-300"></i>
              <p>No candidates found</p>
              <?php if (!empty($search) || !empty($election_filter) || !empty($position_filter)): ?>
                <p class="text-sm mt-2">Try adjusting your search or filters</p>
              <?php endif; ?>
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>

    <!-- Export Section -->
    <div class="mt-6 flex justify-between items-center">
      <div class="text-sm text-gray-600">
        Showing <?= count($candidates) ?> candidate(s)
      </div>
      <div>
        <button id="export-candidates" class="bg-gray-700 hover:bg-gray-800 text-white px-4 py-2 rounded text-sm transition-colors">
          <i class="fas fa-file-export mr-1"></i> Export to CSV
        </button>
      </div>
    </div>
  </div>
</div>

<script>
/* ---------------------------
   CONFIG
--------------------------- */
const BASE_URL   = "<?= BASE_URL ?>";
const CSRF_TOKEN = "<?= $_SESSION['csrf_token'] ?? '' ?>";

/* ---------------------------
   Small helper: always parse JSON safely
--------------------------- */
async function apiJSON(url, options = {}) {
  const res = await fetch(url, { credentials: 'same-origin', ...options });
  let payload = null;
  try {
    payload = await res.json();
  } catch (e) {
    // server might have thrown a PHP error (HTML), keep payload null
  }
  if (!res.ok) {
    const msg = (payload && (payload.message || payload.error)) || `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return payload || {};
}

/* ---------------------------
   Modal helpers
--------------------------- */
function showModal(id) {
  document.getElementById(id).classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function hideModal(id) {
  document.getElementById(id).classList.add('hidden');
  document.body.style.overflow = 'auto';
}

/* ---------------------------
   View Candidate Details
--------------------------- */
window.viewCandidate = function(candidate) {
  // Create modal content
  const modalContent = `
    <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-lg font-bold text-pink-900">Candidate Details</h3>
          <button type="button" onclick="this.closest('.fixed').remove()" class="text-gray-500 hover:text-gray-700">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="text-center mb-4">
          <img src="${candidate.photo_path ? BASE_URL + '/' + candidate.photo_path : BASE_URL + '/assets/img/default-avatar.png'}" 
               alt="Candidate Photo" class="w-24 h-24 rounded-full object-cover border mx-auto">
        </div>
        <div class="space-y-3">
          <div>
            <label class="font-semibold">Name:</label>
            <p>${candidate.first_name} ${candidate.last_name}</p>
          </div>
          <div>
            <label class="font-semibold">Position:</label>
            <p>${candidate.position_name || '—'}</p>
          </div>
          <div>
            <label class="font-semibold">Election:</label>
            <p>${candidate.election_title || '—'}</p>
          </div>
          <div>
            <label class="font-semibold">Department:</label>
            <p>${candidate.department || '—'}</p>
          </div>
          <div>
            <label class="font-semibold">Email:</label>
            <p>${candidate.email || '—'}</p>
          </div>
          ${candidate.manifesto ? `
          <div>
            <label class="font-semibold">Manifesto:</label>
            <p class="mt-1 text-sm">${candidate.manifesto}</p>
          </div>
          ` : ''}
        </div>
        <div class="mt-6 flex justify-end">
          <button type="button" onclick="this.closest('.fixed').remove()" class="bg-pink-900 text-white px-4 py-2 rounded">
            Close
          </button>
        </div>
      </div>
    </div>
  `;
  
  // Create modal
  const modal = document.createElement('div');
  modal.innerHTML = modalContent;
  document.body.appendChild(modal);
};

/* ---------------------------
   API loaders (Elections, Positions & Users)
--------------------------- */
async function loadElections() {
  return apiJSON(`${BASE_URL}/api/voting/elections.php`);
}

async function loadPositions(electionId) {
  if (!electionId) return { success:false, positions:[] };
  return apiJSON(`${BASE_URL}/api/voting/positions.php?election_id=${encodeURIComponent(electionId)}`);
}

async function loadUsers() {
  try {
    const response = await fetch(`${BASE_URL}/api/admin/users.php`);
    const data = await response.json();
    
    if (data.success) {
      const userSelect = document.getElementById('candidate-user');
      if (userSelect) {
        userSelect.innerHTML = '<option value="">-- Select User --</option>';
        
        data.users.forEach(user => {
          const option = document.createElement('option');
          option.value = user.id;
          option.textContent = `${user.first_name} ${user.last_name} (${user.department})`;
          userSelect.appendChild(option);
        });
      }
    }
  } catch (error) {
    console.error('Failed to load users:', error);
  }
}

/* ---------------------------
   Populate Elections, Positions & Users on page load
--------------------------- */
document.addEventListener('DOMContentLoaded', async () => {
  const electionSelect = document.getElementById('candidate-election');
  const posSelect = document.getElementById('candidate-position');
  const userSelect = document.getElementById('candidate-user');
  const searchEl = document.getElementById('search');
  const electionFilterEl = document.getElementById('election-filter');
  const positionFilterEl = document.getElementById('position-filter');
  const applyFiltersBtn = document.getElementById('apply-filters');
  const exportBtn = document.getElementById('export-candidates');

  // Apply filters
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener('click', () => {
      const search = searchEl.value;
      const election = electionFilterEl.value;
      const position = positionFilterEl.value;
      
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (election) params.set('election', election);
      if (position) params.set('position', position);
      
      window.location.href = window.location.pathname + '?' + params.toString();
    });
  }

  // Export to CSV
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      const search = searchEl.value;
      const election = electionFilterEl.value;
      const position = positionFilterEl.value;
      
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (election) params.set('election', election);
      if (position) params.set('position', position);
      params.set('export', 'csv');
      
      window.location.href = window.location.pathname + '?' + params.toString();
    });
  }

  // Load Users
  await loadUsers();

  // Elections
  if (electionSelect) {
    electionSelect.innerHTML = '<option value="">Select Election</option>';
    try {
      const eRes = await loadElections();
      if (eRes.success && Array.isArray(eRes.elections)) {
        eRes.elections.forEach(e => {
          const opt = document.createElement('option');
          opt.value = e.id;
          opt.textContent = e.title;
          electionSelect.appendChild(opt);
        });
      }
    } catch (err) {
      console.error('Failed to load elections:', err.message);
    }

    // When election changes -> load positions
    electionSelect.addEventListener('change', async () => {
      if (posSelect) {
        posSelect.innerHTML = '<option value="">Select Position</option>';
        if (!electionSelect.value) return;
        try {
          const pRes = await loadPositions(electionSelect.value);
          if (pRes.success && Array.isArray(pRes.positions)) {
            pRes.positions.forEach(p => {
              const opt = document.createElement('option');
              opt.value = p.id;
              opt.textContent = p.name;
              posSelect.appendChild(opt);
            });
          }
        } catch (err) {
          console.error('Failed to load positions:', err.message);
        }
      }
    });
  }
});

/* ---------------------------
   Edit Candidate
--------------------------- */
window.editCandidate = function(candidate) {
  const userSel = document.getElementById('candidate-user');
  if (userSel) userSel.value = candidate.user_id;

  document.getElementById('candidate-id').value = candidate.id;
  document.getElementById('candidate-description').value = candidate.manifesto || '';

  const electionSelect = document.getElementById('candidate-election');
  const posSelect = document.getElementById('candidate-position');

  // Set election first
  if (electionSelect) electionSelect.value = candidate.election_id;

  // Load positions for that election, then select the candidate's position
  if (posSelect) {
    posSelect.innerHTML = '<option value="">Select Position</option>';
    loadPositions(candidate.election_id)
      .then(pRes => {
        if (pRes.success && Array.isArray(pRes.positions)) {
          pRes.positions.forEach(p => {
            const opt = document.createElement('option');
            opt.value = p.id;
            opt.textContent = p.name;
            posSelect.appendChild(opt);
          });
        }
        posSelect.value = candidate.position_id;
      })
      .catch(err => console.error('Failed to load positions for edit:', err.message));
  }

  showModal('add-candidate-modal');
};

/* ---------------------------
   Delete Candidate
--------------------------- */
window.confirmDeleteCandidate = function(id) {
  if (!id) return;
  if (confirm('Are you sure you want to delete this candidate? This action cannot be undone.')) {
    deleteCandidate(id);
  }
};

async function deleteCandidate(id) {
  try {
    const data = await apiJSON(`${BASE_URL}/api/admin/candidates.php?id=${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: { 'X-CSRF-Token': CSRF_TOKEN }
    });
    if (data.success) {
      alert('Candidate deleted successfully');
      location.reload();
    } else {
      alert(data.message || 'Failed to delete candidate');
    }
  } catch (err) {
    console.error('Delete failed:', err);
    alert(err.message || 'Network error');
  }
}

/* ---------------------------
   Save (Create / Update) Candidate
--------------------------- */
document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('candidate-form');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();

      const submitBtn = e.target.querySelector('button[type="submit"]');
      if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Saving...'; }

      const formData = new FormData();

      // Get form values
      const userSel = document.getElementById('candidate-user');
      if (userSel && userSel.value) {
        formData.append('user_id', userSel.value);
      }

      const electionSelect = document.getElementById('candidate-election');
      const posSelect = document.getElementById('candidate-position');
      const descEl = document.getElementById('candidate-description');
      const idEl = document.getElementById('candidate-id');

      if (electionSelect) formData.append('election_id', electionSelect.value);
      if (posSelect) formData.append('position_id', posSelect.value);
      if (descEl) formData.append('manifesto', descEl.value);

      const candidateId = idEl ? idEl.value : '';
      if (candidateId) formData.append('id', candidateId);

      const photoInput = document.getElementById('candidate-photo');
      if (photoInput && photoInput.files.length > 0) {
        formData.append('photo', photoInput.files[0]);
      }

      // POST to the same endpoint for both create/update
      const url = `${BASE_URL}/api/admin/candidates.php${candidateId ? `?id=${encodeURIComponent(candidateId)}` : ''}`;

      try {
        const data = await apiJSON(url, {
          method: 'POST',
          headers: {
            'X-CSRF-Token': CSRF_TOKEN
          },
          body: formData
        });
        if (data.success) {
          hideModal('add-candidate-modal');
          alert('Candidate saved successfully');
          location.reload();
        } else {
          alert(data.message || 'Failed to save candidate');
        }
      } catch (err) {
        console.error('Save failed:', err);
        alert(err.message || 'Network error');
      } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Save Candidate'; }
      }
    });
  }
});
</script>

<?php require APP_ROOT . '/views/modals/add_candidate.php'; ?>
<?php require_once APP_ROOT . '/includes/footer.php'; ?>