<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/db_connect.php';
require_once __DIR__ . '/../../helpers/functions.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Only admin should view this page
if (empty($_SESSION['is_admin'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once APP_ROOT . '/includes/header.php';

$db = Database::getInstance()->getConnection();

// Initialize all variables with default values
$activeElections = [];
$voterCount = $candidateCount = $electionCount = $votedCount = $recentVotes = $pendingElections = 0;
$completedElections = 0;
$upcomingElections = 0;

try {
    $stmt = $db->query("SELECT * FROM elections WHERE status = 'active' ORDER BY start_date DESC");
    $activeElections = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error fetching active elections: " . $e->getMessage());
    $activeElections = [];
}

// Get additional stats for the dashboard
try {
    $voterCount = $db->query("SELECT COUNT(*) as count FROM users WHERE is_admin = 0")->fetch(PDO::FETCH_ASSOC)['count'];
    $candidateCount = $db->query("SELECT COUNT(*) as count FROM candidates")->fetch(PDO::FETCH_ASSOC)['count'];
    $electionCount = $db->query("SELECT COUNT(*) as count FROM elections")->fetch(PDO::FETCH_ASSOC)['count'];
    $votedCount = $db->query("SELECT COUNT(*) as count FROM users WHERE has_voted = 1 AND is_admin = 0")->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Get recent activity data
    $recentVotes = $db->query("SELECT COUNT(*) as count FROM votes WHERE created_at >= NOW() - INTERVAL 1 DAY")->fetch(PDO::FETCH_ASSOC)['count'];
    $completedElections = $db->query("SELECT COUNT(*) as count FROM elections WHERE status = 'ended'")->fetch(PDO::FETCH_ASSOC)['count'];
    $upcomingElections = $db->query("SELECT COUNT(*) as count FROM elections WHERE status = 'upcoming'")->fetch(PDO::FETCH_ASSOC)['count'];
    $pendingElections = $db->query("SELECT COUNT(*) as count FROM elections WHERE status = 'pending'")->fetch(PDO::FETCH_ASSOC)['count'];
    
} catch (PDOException $e) {
    error_log("Database error fetching stats: " . $e->getMessage());
}

// Calculate participation rate safely
$participationRate = 0;
if ($voterCount > 0) {
    $participationRate = round(($votedCount / $voterCount) * 100, 1);
}
?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
  <div class="text-center mb-10">
    <h2 class="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h2>
    <p class="text-gray-600">Manage elections, candidates, and voter information</p>
  </div>

  <!-- Enhanced Stats Section -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
    <!-- Election Card -->
    <div class="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div class="p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500 mb-1">Total Elections</p>
            <h3 class="text-3xl font-bold text-gray-900"><?= htmlspecialchars($electionCount) ?></h3>
            <div class="flex flex-wrap gap-2 mt-2">
              <?php if ($pendingElections > 0): ?>
              <span class="bg-amber-100 text-amber-800 text-xs font-medium px-2 py-0.5 rounded-full">
                <?= htmlspecialchars($pendingElections) ?> pending
              </span>
              <?php endif; ?>
              <?php if ($upcomingElections > 0): ?>
              <span class="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-0.5 rounded-full">
                <?= htmlspecialchars($upcomingElections) ?> upcoming
              </span>
              <?php endif; ?>
            </div>
          </div>
          <div class="bg-pink-100 p-4 rounded-full">
            <i class="fas fa-calendar-alt text-pink-600 text-2xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-3 border-t border-gray-100 flex justify-between items-center">
          <a href="<?= BASE_URL ?>/admin/elections" class="text-xs font-medium text-pink-700 hover:text-pink-900 flex items-center">
            Manage elections <i class="fas fa-arrow-right ml-1 text-xs"></i>
          </a>
          <span class="text-xs text-gray-500"><?= htmlspecialchars($completedElections) ?> completed</span>
        </div>
      </div>
    </div>
    
    <!-- Voter Card -->
    <div class="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div class="p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500 mb-1">Total Voters</p>
            <h3 class="text-3xl font-bold text-gray-900"><?= htmlspecialchars($voterCount) ?></h3>
            <?php if ($voterCount > 0): ?>
            <p class="text-xs text-gray-500 mt-1">
              <?= htmlspecialchars($voterCount - $votedCount) ?> not voted yet
            </p>
            <?php endif; ?>
          </div>
          <div class="bg-blue-100 p-4 rounded-full">
            <i class="fas fa-users text-blue-600 text-2xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-3 border-t border-gray-100">
          <a href="<?= BASE_URL ?>/admin/voters" class="text-xs font-medium text-blue-700 hover:text-blue-900 flex items-center">
            Manage voters <i class="fas fa-arrow-right ml-1 text-xs"></i>
          </a>
        </div>
      </div>
    </div>
    
    <!-- Candidate Card -->
    <div class="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div class="p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500 mb-1">Candidates</p>
            <h3 class="text-3xl font-bold text-gray-900"><?= htmlspecialchars($candidateCount) ?></h3>
            <?php if ($candidateCount > 0 && $electionCount > 0): 
              $avgCandidates = round($candidateCount / $electionCount, 1);
            ?>
            <p class="text-xs text-gray-500 mt-1">
              ~<?= htmlspecialchars($avgCandidates) ?> per election
            </p>
            <?php endif; ?>
          </div>
          <div class="bg-emerald-100 p-4 rounded-full">
            <i class="fas fa-user-tie text-emerald-600 text-2xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-3 border-t border-gray-100">
          <a href="<?= BASE_URL ?>/admin/candidates" class="text-xs font-medium text-emerald-700 hover:text-emerald-900 flex items-center">
            Manage candidates <i class="fas fa-arrow-right ml-1 text-xs"></i>
          </a>
        </div>
      </div>
    </div>
    
    <!-- Votes Card -->
    <div class="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div class="p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500 mb-1">Votes Cast</p>
            <h3 class="text-3xl font-bold text-gray-900"><?= htmlspecialchars($votedCount) ?></h3>
            <?php if ($voterCount > 0): ?>
            <div class="flex items-center mt-1">
              <div class="w-full bg-gray-200 rounded-full h-1.5 mr-2">
                <div class="bg-purple-600 h-1.5 rounded-full" style="width: <?= min($participationRate, 100) ?>%"></div>
              </div>
              <span class="text-xs font-medium text-purple-600"><?= htmlspecialchars($participationRate) ?>%</span>
            </div>
            <?php endif; ?>
            <?php if ($recentVotes > 0): ?>
            <p class="text-xs text-purple-600 mt-1 font-medium">
              <span class="inline-flex items-center">
                <i class="fas fa-bolt mr-1"></i> <?= htmlspecialchars($recentVotes) ?> today
              </span>
            </p>
            <?php endif; ?>
          </div>
          <div class="bg-purple-100 p-4 rounded-full">
            <i class="fas fa-vote-yea text-purple-600 text-2xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-3 border-t border-gray-100">
          <a href="<?= BASE_URL ?>/results" class="text-xs font-medium text-purple-700 hover:text-purple-900 flex items-center">
            View results <i class="fas fa-arrow-right ml-1 text-xs"></i>
          </a>
        </div>
      </div>
    </div>
  </div>

   <div class="grid md:grid-cols-2 gap-8">
    <div class="bg-white p-6 rounded-xl shadow-md">
      <div class="flex justify-between items-center mb-5">
        <h3 class="text-xl font-bold text-gray-900">Active Elections</h3>
        <span class="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full"><?= count($activeElections) ?> Active</span>
      </div>
      
      <div class="space-y-4">
        <?php if (!empty($activeElections)): ?>
          <?php foreach ($activeElections as $election): ?>
            <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors duration-200">
              <div class="flex justify-between items-start">
                <div>
                  <h4 class="font-medium text-gray-900"><?= htmlspecialchars($election['title']) ?></h4>
                  <p class="text-sm text-gray-600 mt-1">
                    <i class="far fa-calendar-alt mr-1"></i> 
                    <?= date('M j, Y', strtotime($election['start_date'])) ?> - <?= date('M j, Y', strtotime($election['end_date'])) ?>
                  </p>
                </div>
                <span class="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                  <?= ucfirst(htmlspecialchars($election['status'])) ?>
                </span>
              </div>
              <div class="mt-3 flex space-x-2">
                <!-- Fixed links using router-friendly URLs -->
                 <a href="<?= BASE_URL ?>/admin/elections?action=view&id=<?= $election['id'] ?>" class="text-xs text-blue-600 hover:text-blue-800 font-medium">
                  <i class="fas fa-eye mr-1"></i> View
                </a>
                 <a href="<?= BASE_URL ?>/admin/elections?action=edit&id=<?= $election['id'] ?>"  class="text-xs text-gray-600 hover:text-gray-800 font-medium">
                  <i class="fas fa-edit mr-1"></i> Edit
                </a>
                <a href="<?= BASE_URL ?>/results?election_id=<?= $election['id'] ?>" class="text-xs text-purple-600 hover:text-purple-800 font-medium">
                  <i class="fas fa-chart-bar mr-1"></i> Results
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="text-center py-6 text-gray-500">
            <i class="fas fa-calendar-times text-3xl mb-3 text-gray-300"></i>
            <p>No active elections at the moment</p>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="bg-white p-6 rounded-xl shadow-md">
      <h3 class="text-xl font-bold mb-4 text-gray-900">Quick Actions</h3>
      <div class="grid grid-cols-2 gap-3 mb-6">
        <a href="<?= BASE_URL ?>/admin/elections" 
           class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-3 rounded-lg text-center transition-colors">
          <i class="fas fa-vote-yea mr-2"></i> Elections
        </a>
        <a href="<?= BASE_URL ?>/admin/candidates" 
           class="bg-gray-900 hover:bg-gray-800 text-white px-4 py-3 rounded-lg text-center transition-colors">
          <i class="fas fa-users mr-2"></i> Candidates
        </a>
        <a href="<?= BASE_URL ?>/admin/voters" 
           class="bg-yellow-700 hover:bg-yellow-800 text-white px-4 py-3 rounded-lg text-center transition-colors">
          <i class="fas fa-user-graduate mr-2"></i> Voters
        </a>
        <a href="<?= BASE_URL ?>/results" 
           class="bg-purple-900 hover:bg-purple-800 text-white px-4 py-3 rounded-lg text-center transition-colors">
          <i class="fas fa-chart-bar mr-2"></i> Results
        </a>
      </div>
      
      <!-- Recent Activity -->
      <div class="pt-6 border-t border-gray-200">
        <h4 class="font-semibold text-gray-900 mb-3">Recent Activity</h4>
        <div class="space-y-3">
          <?php if ($recentVotes > 0): ?>
            <div class="flex items-center text-sm text-gray-600 p-2 bg-blue-50 rounded-lg">
              <i class="fas fa-vote-yea text-green-500 mr-2"></i>
              <span><?= $recentVotes ?> votes cast today</span>
            </div>
          <?php endif; ?>
          <?php if ($upcomingElections > 0): ?>
            <div class="flex items-center text-sm text-gray-600 p-2 bg-blue-50 rounded-lg">
              <i class="fas fa-calendar-plus text-blue-500 mr-2"></i>
              <span><?= $upcomingElections ?> upcoming elections</span>
            </div>
          <?php endif; ?>
          <div class="flex items-center text-sm text-gray-600 p-2 bg-blue-50 rounded-lg">
            <i class="fas fa-users text-purple-500 mr-2"></i>
            <span><?= $voterCount ?> total voters registered</span>
          </div>
          <div class="flex items-center text-sm text-gray-600 p-2 bg-blue-50 rounded-lg">
            <i class="fas fa-user-tie text-emerald-500 mr-2"></i>
            <span><?= $candidateCount ?> candidates registered</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once APP_ROOT . '/includes/footer.php'; ?>