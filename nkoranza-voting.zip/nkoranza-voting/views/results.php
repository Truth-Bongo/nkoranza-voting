<?php require_once APP_ROOT . '/includes/header.php'; ?>

<div class="max-w-7xl mx-auto px-4 py-8">
  <!-- Header Section -->
  <div class="text-center mb-8">
    <h2 class="text-3xl font-bold text-gray-900 mb-2">Live Election Results</h2>
    <p class="text-gray-600">Real-time updates as votes are cast</p>
    <div class="mt-4 flex flex-wrap justify-center items-center gap-4">
      <span class="flex items-center bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
        <span class="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
        Live Updates Enabled
      </span>
      <span id="last-update" class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
        Last update: Just now
      </span>
      <span id="total-voters" class="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm">
        Loading voter data...
      </span>
    </div>
    
    <!-- Overall Progress Bar -->
    <div id="overall-progress" class="hidden mt-6 max-w-2xl mx-auto">
      <div class="flex justify-between text-sm text-gray-600 mb-1">
        <span>Overall Turnout Progress</span>
        <span id="overall-turnout">0%</span>
      </div>
      <div class="w-full bg-gray-200 rounded-full h-2.5">
        <div id="progress-bar" class="bg-pink-600 h-2.5 rounded-full transition-all duration-500" style="width: 0%"></div>
      </div>
    </div>
  </div>
  
  <!-- Controls Section -->
  <div class="mb-6 flex flex-wrap justify-between items-center gap-4">
    <div class="flex-1 min-w-64">
      <label for="results-election-select" class="block text-sm font-medium text-gray-700 mb-1">Select Election</label>
      <select id="results-election-select" class="block pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 sm:text-sm">
        <option value="">Loading elections...</option>
      </select>
    </div>
    
    <div class="flex items-center gap-3 flex-wrap">
      <!-- Category Filter -->
      <div class="w-40">
        <label for="category-filter" class="block text-sm font-medium text-gray-700 mb-1">Filter by Category</label>
        <select id="category-filter" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 sm:text-sm">
          <option value="all">All Categories</option>
          <!-- Categories will be populated dynamically -->
        </select>
      </div>
      
      <!-- Vote Threshold Filter -->
      <div class="w-32">
        <label for="vote-threshold" class="block text-sm font-medium text-gray-700 mb-1">Min Votes</label>
        <input type="number" id="vote-threshold" min="0" value="0" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 sm:text-sm">
      </div>
      
      <!-- Winner Only Filter -->
      <div class="w-40 mt-6">
        <label for="winner-only" class="flex items-center">
          <input type="checkbox" id="winner-only" class="rounded border-gray-300 text-pink-600 focus:ring-pink-500">
          <span class="ml-2 text-sm text-gray-600">Show winners only</span>
        </label>
      </div>
      
      <!-- Chart Type Selector -->
      <div class="w-40">
        <label for="chart-type" class="block text-sm font-medium text-gray-700 mb-1">Chart Type</label>
        <select id="chart-type" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 sm:text-sm">
          <option value="bar">Bar Chart</option>
          <option value="horizontalBar">Horizontal Bar</option>
          <option value="pie">Pie Chart</option>
          <option value="doughnut">Doughnut Chart</option>
        </select>
      </div>
      
      <!-- Export Format Selector -->
      <div class="w-32">
        <label for="export-format" class="block text-sm font-medium text-gray-700 mb-1">Export Format</label>
        <select id="export-format" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 sm:text-sm">
          <option value="csv">CSV</option>
          <option value="excel">Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </div>
      
      <!-- Auto-refresh toggle -->
      <div class="flex items-center">
        <label class="switch mr-2">
          <input type="checkbox" id="auto-refresh-toggle" checked>
          <span class="slider"></span>
        </label>
        <span class="text-sm text-gray-600">Auto Refresh</span>
      </div>
      
      <!-- Refresh interval -->
      <div class="w-32">
        <label for="refresh-interval" class="block text-sm font-medium text-gray-700 mb-1">Refresh Every</label>
        <select id="refresh-interval" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 sm:text-sm">
          <option value="5000">5 seconds</option>
          <option value="10000" selected>10 seconds</option>
          <option value="30000">30 seconds</option>
          <option value="60000">1 minute</option>
        </select>
      </div>
      
      <!-- View Toggle -->
      <div class="w-32">
        <label for="view-mode" class="block text-sm font-medium text-gray-700 mb-1">View Mode</label>
        <select id="view-mode" class="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 sm:text-sm">
          <option value="combined">Chart & Table</option>
          <option value="chart-only">Chart Only</option>
          <option value="table-only">Table Only</option>
        </select>
      </div>
      
      <!-- Export Button with Options -->
      <div class="relative">
        <button id="export-results-btn" class="bg-pink-900 hover:bg-pink-800 text-white px-4 py-2.5 rounded-lg text-sm flex items-center">
          <i class="fas fa-file-export mr-2"></i> Export
        </button>
        <button id="export-options-btn" class="absolute -right-2 -top-2 bg-gray-300 hover:bg-gray-400 text-gray-700 rounded-full w-5 h-5 flex items-center justify-center text-xs" title="Export options">
          <i class="fas fa-cog"></i>
        </button>
      </div>
      
      <!-- Manual Refresh Button -->
      <button id="manual-refresh-btn" class="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-lg text-sm" title="Refresh Now">
        <i class="fas fa-sync-alt"></i>
      </button>
      
      <!-- Accessibility Toggle -->
      <button id="accessibility-toggle" class="bg-gray-200 hover:bg-gray-300 text-gray-700 p-2.5 rounded-lg text-sm" title="High Contrast Mode">
        <i class="fas fa-contrast"></i>
      </button>
    </div>
  </div>
  
  <!-- Election Summary Cards -->
  <div id="election-summary" class="hidden grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-lg shadow p-4 bg-gradient-to-r from-blue-50 to-blue-100">
      <div class="flex items-center">
        <div class="bg-blue-100 p-3 rounded-full">
          <i class="fas fa-users text-blue-600"></i>
        </div>
        <div class="ml-4">
          <p class="text-sm text-blue-600">Total Voters</p>
          <p class="text-2xl font-bold text-blue-800" id="total-voters-count">0</p>
        </div>
      </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-4 bg-gradient-to-r from-green-50 to-green-100">
      <div class="flex items-center">
        <div class="bg-green-100 p-3 rounded-full">
          <i class="fas fa-vote-yea text-green-600"></i>
        </div>
        <div class="ml-4">
          <p class="text-sm text-green-600">Votes Cast</p>
          <p class="text-2xl font-bold text-green-800" id="votes-cast-count">0</p>
        </div>
      </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-4 bg-gradient-to-r from-purple-50 to-purple-100">
      <div class="flex items-center">
        <div class="bg-purple-100 p-3 rounded-full">
          <i class="fas fa-percentage text-purple-600"></i>
        </div>
        <div class="ml-4">
          <p class="text-sm text-purple-600">Turnout Rate</p>
          <p class="text-2xl font-bold text-purple-800" id="turnout-rate">0%</p>
        </div>
      </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-4 bg-gradient-to-r from-orange-50 to-orange-100">
      <div class="flex items-center">
        <div class="bg-orange-100 p-3 rounded-full">
          <i class="fas fa-clock text-orange-600"></i>
        </div>
        <div class="ml-4">
          <p class="text-sm text-orange-600">Time Remaining</p>
          <p class="text-2xl font-bold text-orange-800" id="time-remaining">--:--:--</p>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Analytics Dashboard Toggle -->
  <div class="mb-4 flex justify-center">
    <button id="analytics-toggle" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm flex items-center">
      <i class="fas fa-chart-line mr-2"></i> Show Analytics Dashboard
    </button>
  </div>
  
  <!-- Analytics Dashboard -->
  <div id="analytics-dashboard" class="hidden grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
    <div class="bg-white p-4 rounded-lg shadow">
      <h4 class="font-medium text-gray-700 mb-4">Voting Trends</h4>
      <canvas id="trend-chart" height="200"></canvas>
    </div>
    
    <div class="bg-white p-4 rounded-lg shadow">
      <h4 class="font-medium text-gray-700 mb-4">Category Comparison</h4>
      <canvas id="category-chart" height="200"></canvas>
    </div>
    
    <div class="bg-white p-4 rounded-lg shadow">
      <h4 class="font-medium text-gray-700 mb-4">Time Distribution</h4>
      <canvas id="time-chart" height="200"></canvas>
    </div>
    
    <div class="bg-white p-4 rounded-lg shadow">
      <h4 class="font-medium text-gray-700 mb-4">Department Participation</h4>
      <canvas id="department-chart" height="200"></canvas>
    </div>
  </div>
  
  <!-- Results Container -->
  <div id="results-container" class="space-y-6">
    <div class="bg-white rounded-lg shadow p-8 text-center">
      <div class="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
        <i class="fas fa-chart-bar text-3xl text-gray-400"></i>
      </div>
      <h3 class="text-lg font-medium text-gray-600">Select an election to view results</h3>
      <p class="text-sm text-gray-500 mt-1">Choose from the dropdown above to see live election results</p>
    </div>
  </div>
  
  <!-- Loading Overlay -->
  <div id="loading-overlay" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white rounded-lg p-6 flex items-center">
      <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-pink-600 mr-3"></div>
      <span>Loading results...</span>
    </div>
  </div>
</div>

<!-- Include Chart.js with additional plugins -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-annotation@2.0.1"></script>

<script>
// Global variables
let realTimeResults = null;
let chartInstances = {};
let analyticsCharts = {};
let currentElection = null;
let allPositions = []; // Store all positions for filtering
let categories = []; // Store all categories
let highContrastMode = false;
let resultsCache = new Map();

// Register Chart.js plugins
if (typeof Chart !== 'undefined' && typeof ChartDataLabels !== 'undefined') {
  Chart.register(ChartDataLabels);
}

document.addEventListener('DOMContentLoaded', async () => {
  initializeEventListeners();
  setupAccessibility();
  await loadElections();
});

function initializeEventListeners() {
  // Election selection
  document.getElementById('results-election-select').addEventListener('change', handleElectionChange);
  
  // Category filter
  document.getElementById('category-filter').addEventListener('change', filterResults);
  
  // Vote threshold filter
  document.getElementById('vote-threshold').addEventListener('input', debounce(filterResults, 300));
  
  // Winner only filter
  document.getElementById('winner-only').addEventListener('change', filterResults);
  
  // Chart type selector
  document.getElementById('chart-type').addEventListener('change', updateChartType);
  
  // Auto-refresh toggle
  document.getElementById('auto-refresh-toggle').addEventListener('change', toggleAutoRefresh);
  
  // Refresh interval change
  document.getElementById('refresh-interval').addEventListener('change', updateRefreshInterval);
  
  // View mode change
  document.getElementById('view-mode').addEventListener('change', updateViewMode);
  
  // Export button
  document.getElementById('export-results-btn').addEventListener('click', handleExport);
  
  // Export options button
  document.getElementById('export-options-btn').addEventListener('click', showExportOptions);
  
  // Manual refresh
  document.getElementById('manual-refresh-btn').addEventListener('click', manualRefresh);
  
  // Analytics toggle
  document.getElementById('analytics-toggle').addEventListener('click', toggleAnalytics);
  
  // Accessibility toggle
  document.getElementById('accessibility-toggle').addEventListener('click', toggleAccessibility);
  
  // Keyboard shortcuts
  document.addEventListener('keydown', handleKeyboardShortcuts);
}

function setupAccessibility() {
  // Add ARIA labels for better screen reader support
  document.getElementById('export-results-btn').setAttribute('aria-label', 'Export election results');
  document.getElementById('manual-refresh-btn').setAttribute('aria-label', 'Refresh results manually');
  document.getElementById('accessibility-toggle').setAttribute('aria-label', 'Toggle high contrast mode');
}

function handleKeyboardShortcuts(e) {
  // Escape key closes modals
  if (e.key === 'Escape') {
    closeAllModals();
  }
  
  // Ctrl/Cmd + E for export
  if ((e.ctrlKey || e.metaKey) && e.key === 'e') {
    e.preventDefault();
    handleExport();
  }
  
  // Ctrl/Cmd + R for refresh
  if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
    e.preventDefault();
    manualRefresh();
  }
}

async function loadElections() {
  try {
    showLoading(true);
    const response = await fetch(`${BASE_URL}/api/voting/elections.php`);
    const data = await response.json();
    
    if (!data.success) throw new Error(data.message || 'Failed to load elections');
    
    const electionSelect = document.getElementById('results-election-select');
    electionSelect.innerHTML = '<option value="">Select an election</option>';
    
    data.elections.forEach(election => {
      const option = document.createElement('option');
      option.value = election.id;
      option.textContent = election.title;
      option.dataset.endDate = election.end_date;
      electionSelect.appendChild(option);
    });
    
  } catch (error) {
    console.error('Error loading elections:', error);
    showError('Failed to load elections. Please try again later.');
  } finally {
    showLoading(false);
  }
}

function handleElectionChange() {
  const electionId = document.getElementById('results-election-select').value;
  const selectedOption = document.getElementById('results-election-select').selectedOptions[0];
  
  if (!electionId) {
    clearResults();
    return;
  }
  
  currentElection = {
    id: electionId,
    endDate: selectedOption.dataset.endDate
  };
  
  initializeRealTimeResults();
  startTimeRemainingCounter();
}

function initializeRealTimeResults() {
  clearExistingResults();
  
  const electionId = document.getElementById('results-election-select').value;
  if (!electionId) return;
  
  // Load initial results
  loadResults();
  
  // Set up polling if auto-refresh is enabled
  if (document.getElementById('auto-refresh-toggle').checked) {
    const interval = parseInt(document.getElementById('refresh-interval').value);
    startAutoRefresh(interval);
  }
}

async function loadResults() {
  const electionId = document.getElementById('results-election-select').value;
  if (!electionId) return;
  
  // Check cache first
  if (resultsCache.has(electionId)) {
    const cachedData = resultsCache.get(electionId);
    if (Date.now() - cachedData.timestamp < 5000) { // 5 second cache
      processResults(cachedData.data);
      return;
    }
  }
  
  try {
    showLoading(true);
    const response = await fetch(`${BASE_URL}/api/voting/results.php?election_id=${electionId}`);
    const data = await response.json();
    
    if (!data.success) throw new Error(data.message || 'Failed to load results');
    
    // Cache the results
    resultsCache.set(electionId, {
      data: data,
      timestamp: Date.now()
    });
    
    processResults(data);
    
  } catch (error) {
    console.error('Error loading results:', error);
    showError('Failed to load results. Please try again.');
  } finally {
    showLoading(false);
    updateLastUpdatedTime();
  }
}

function processResults(data) {
  if (data.positions && data.positions.length === 0) {
    showNoResults();
    return;
  }
  
  // Store all positions for filtering
  allPositions = data.positions || [];
  
  // Extract and populate categories
  extractCategories(allPositions);
  
  // Update overall progress
  updateOverallProgress(data);
  
  // Display results
  displayResults(allPositions);
  updateElectionSummary(data);
  
  // Update analytics if visible
  if (document.getElementById('analytics-dashboard').classList.contains('hidden') === false) {
    updateAnalyticsDashboard(data);
  }
}

function updateOverallProgress(data) {
  const totalVotes = data.positions ? data.positions.reduce((sum, pos) => sum + (pos.total_votes || 0), 0) : 0;
  const totalVoters = data.total_voters || 1;
  const turnoutPercentage = Math.min((totalVotes / totalVoters) * 100, 100);
  
  document.getElementById('overall-progress').classList.remove('hidden');
  document.getElementById('overall-turnout').textContent = `${turnoutPercentage.toFixed(1)}%`;
  document.getElementById('progress-bar').style.width = `${turnoutPercentage}%`;
}

function extractCategories(positions) {
  categories = [];
  const categorySet = new Set();
  
  positions.forEach(position => {
    if (position.category && !categorySet.has(position.category)) {
      categorySet.add(position.category);
      categories.push(position.category);
    }
  });
  
  // Sort categories alphabetically
  categories.sort();
  
  // Update category filter dropdown
  const categoryFilter = document.getElementById('category-filter');
  categoryFilter.innerHTML = '<option value="all">All Categories</option>';
  
  categories.forEach(category => {
    const option = document.createElement('option');
    option.value = category;
    option.textContent = category;
    categoryFilter.appendChild(option);
  });
}

function filterResults() {
  const selectedCategory = document.getElementById('category-filter').value;
  const voteThreshold = parseInt(document.getElementById('vote-threshold').value) || 0;
  const winnersOnly = document.getElementById('winner-only').checked;
  
  let filteredPositions = allPositions;
  
  // Filter by category
  if (selectedCategory !== 'all') {
    filteredPositions = filteredPositions.filter(position => position.category === selectedCategory);
  }
  
  // Filter by vote threshold and winners only
  filteredPositions = filteredPositions.map(position => {
    const maxVotes = Math.max(...position.candidates.map(c => c.votes || 0));
    
    const filteredCandidates = position.candidates.filter(candidate => {
      // Apply vote threshold
      if (candidate.votes < voteThreshold) return false;
      
      // Apply winners only filter
      if (winnersOnly && candidate.votes !== maxVotes) return false;
      
      return true;
    });
    
    return {
      ...position,
      candidates: filteredCandidates
    };
  }).filter(position => position.candidates.length > 0); // Remove positions with no candidates after filtering
  
  displayResults(filteredPositions);
}

function displayResults(positions) {
  const viewMode = document.getElementById('view-mode').value;
  const chartType = document.getElementById('chart-type').value;
  let html = '';
  
  // Check if we have positions to display
  if (!positions || positions.length === 0) {
    html = `
      <div class="bg-white rounded-lg shadow p-8 text-center">
        <div class="inline-flex items-center justify-center w-16 h-16 bg-yellow-100 rounded-full mb-4">
          <i class="fas fa-exclamation-triangle text-3xl text-yellow-400"></i>
        </div>
        <h3 class="text-lg font-medium text-gray-600">No positions found</h3>
        <p class="text-sm text-gray-500 mt-1">No positions match the selected criteria.</p>
      </div>
    `;
    document.getElementById('results-container').innerHTML = html;
    return;
  }
  
  positions.forEach(position => {
    const canvasId = `chart-${position.id}`;
    const showChart = viewMode !== 'table-only';
    const showTable = viewMode !== 'chart-only';
    
    // Find the maximum votes to determine winners (handle ties)
    const maxVotes = Math.max(...position.candidates.map(c => c.votes || 0));
    const winners = position.candidates.filter(c => c.votes === maxVotes);
    const isTie = winners.length > 1;
    
    html += `
      <div class="bg-white rounded-lg shadow p-6 mb-6">
        <div class="flex justify-between items-start mb-4">
          <div>
            <h3 class="text-xl font-bold text-gray-900">${position.name}</h3>
            ${position.category ? `<span class="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded-full">${position.category}</span>` : ''}
          </div>
          <span class="bg-pink-100 text-pink-800 px-3 py-1 rounded-full text-sm">
            Total Votes: ${position.total_votes || 0}
          </span>
        </div>
        
        ${position.description ? `<p class="text-gray-600 mb-4">${position.description}</p>` : ''}
        
        ${isTie ? `
          <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
            <div class="flex">
              <div class="flex-shrink-0">
                <i class="fas fa-exclamation-triangle text-yellow-400"></i>
              </div>
              <div class="ml-3">
                <p class="text-sm text-yellow-700">
                  <strong>Tie detected!</strong> Multiple candidates have ${maxVotes} votes.
                </p>
              </div>
            </div>
          </div>
        ` : ''}
        
        <div class="grid grid-cols-1 ${showChart && showTable ? 'lg:grid-cols-2' : ''} gap-6">
          ${showChart ? `
            <div class="chart-container" style="position: relative; height: 350px;">
              <canvas id="${canvasId}"></canvas>
            </div>
          ` : ''}
          
          ${showTable ? `
            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Candidate</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Votes</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Percentage</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  ${position.candidates.map((candidate, index) => {
                    const isWinner = candidate.votes === maxVotes;
                    const statusClass = isWinner ? (isTie ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800') : '';
                    const statusText = isWinner ? (isTie ? 'Tied' : 'Winning') : '';
                    
                    return `
                    <tr class="${isWinner ? 'bg-green-50' : ''} hover:bg-gray-50">
                      <td class="px-4 py-3 whitespace-nowrap">
                        <div class="flex items-center">
                          <div class="flex-shrink-0 h-10 w-10">
                            <img class="h-10 w-10 rounded-full object-cover" 
                                 src="${candidate.photo_path || `${BASE_URL}/assets/images/default-user.jpg`}" 
                                 alt="${candidate.name}"
                                 onerror="this.src='${BASE_URL}/assets/images/default-user.jpg'">
                          </div>
                          <div class="ml-3">
                            <div class="text-sm font-medium text-gray-900">${candidate.name}</div>
                            ${candidate.department ? `<div class="text-xs text-gray-500">${candidate.department}</div>` : ''}
                          </div>
                        </div>
                      </td>
                      <td class="px-4 py-3 whitespace-nowrap text-sm font-bold text-gray-900">
                        ${candidate.votes || 0}
                      </td>
                      <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                        <div class="flex items-center">
                          <span class="font-bold">${candidate.percentage || 0}%</span>
                          <div class="ml-2 w-16 bg-gray-200 rounded-full h-2">
                            <div class="bg-pink-600 h-2 rounded-full" style="width: ${candidate.percentage || 0}%"></div>
                          </div>
                        </div>
                      </td>
                      <td class="px-4 py-3 whitespace-nowrap">
                        ${statusText ? `<span class="px-2 py-1 ${statusClass} text-xs rounded-full">${statusText}</span>` : ''}
                      </td>
                    </tr>
                    `;
                  }).join('')}
                </tbody>
              </table>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  });
  
  document.getElementById('results-container').innerHTML = html;
  
  // Create charts
  positions.forEach(position => {
    createChart(position, chartType);
  });
}

function createChart(position, chartType = 'bar') {
  const canvasId = `chart-${position.id}`;
  const canvasElement = document.getElementById(canvasId);
  if (!canvasElement) return;
  
  const ctx = canvasElement.getContext('2d');
  
  // Destroy previous chart instance if it exists
  if (chartInstances[canvasId]) {
    chartInstances[canvasId].destroy();
  }
  
  const candidateNames = position.candidates.map(c => c.name);
  const votes = position.candidates.map(c => c.votes || 0);
  const percentages = position.candidates.map(c => c.percentage || 0);
  
  // Generate colors based on contrast mode
  const backgroundColors = highContrastMode ? 
    generateHighContrastColors(position.candidates.length) : 
    generateChartColors(position.candidates.length);
  
  // Common chart options
  const commonOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: chartType === 'pie' || chartType === 'doughnut',
        position: 'bottom'
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            const candidate = position.candidates[context.dataIndex];
            return `${candidate.name}: ${candidate.votes || 0} votes (${candidate.percentage || 0}%)`;
          }
        }
      },
      datalabels: {
        color: highContrastMode ? '#000' : '#fff',
        font: {
          weight: 'bold',
          size: chartType === 'pie' || chartType === 'doughnut' ? 10 : 12
        },
        formatter: (value, context) => {
          return chartType === 'pie' || chartType === 'doughnut' ? 
            `${candidateNames[context.dataIndex]}: ${value}` : 
            `${value} (${percentages[context.dataIndex]}%)`;
        },
        anchor: 'end',
        align: 'end'
      }
    }
  };
  
  // Chart-specific configurations
  let chartConfig = {
    type: chartType,
    data: {
      labels: candidateNames,
      datasets: [{
        label: 'Votes',
        data: votes,
        backgroundColor: backgroundColors,
        borderColor: backgroundColors.map(color => color.replace('0.8', '1')),
        borderWidth: 2,
        borderRadius: 6,
        barPercentage: 0.7,
      }]
    },
    options: commonOptions
  };
  
  // Adjust options based on chart type
  if (chartType === 'bar' || chartType === 'horizontalBar') {
    chartConfig.options.indexAxis = chartType === 'horizontalBar' ? 'y' : 'x';
    chartConfig.options.scales = {
      x: {
        beginAtZero: true,
        ticks: { precision: 0 },
        grid: { color: 'rgba(0, 0, 0, 0.1)' }
      },
      y: {
        grid: { color: 'rgba(0, 0, 0, 0.1)' }
      }
    };
  } else if (chartType === 'pie' || chartType === 'doughnut') {
    chartConfig.options.plugins.datalabels.anchor = 'center';
    chartConfig.options.plugins.datalabels.align = 'center';
  }
  
  chartInstances[canvasId] = new Chart(ctx, chartConfig);
}

function generateChartColors(count) {
  const colors = [
    'rgba(255, 99, 132, 0.8)', 'rgba(54, 162, 235, 0.8)', 'rgba(255, 206, 86, 0.8)',
    'rgba(75, 192, 192, 0.8)', 'rgba(153, 102, 255, 0.8)', 'rgba(255, 159, 64, 0.8)',
    'rgba(199, 199, 199, 0.8)', 'rgba(83, 102, 255, 0.8)', 'rgba(40, 159, 64, 0.8)'
  ];
  
  // If we need more colors than available, generate random ones
  while (colors.length < count) {
    colors.push(`rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 0.8)`);
  }
  
  return colors.slice(0, count);
}

function generateHighContrastColors(count) {
  const colors = [
    'rgba(255, 0, 0, 0.8)',      // Red
    'rgba(0, 0, 255, 0.8)',      // Blue
    'rgba(0, 128, 0, 0.8)',      // Green
    'rgba(255, 165, 0, 0.8)',    // Orange
    'rgba(128, 0, 128, 0.8)',    // Purple
    'rgba(255, 255, 0, 0.8)',    // Yellow
    'rgba(0, 255, 255, 0.8)',    // Cyan
    'rgba(255, 0, 255, 0.8)',    // Magenta
    'rgba(128, 128, 128, 0.8)'   // Gray
  ];
  
  while (colors.length < count) {
    colors.push(`rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 0.8)`);
  }
  
  return colors.slice(0, count);
}

function updateChartType() {
  const chartType = document.getElementById('chart-type').value;
  allPositions.forEach(position => {
    createChart(position, chartType);
  });
}

function updateElectionSummary(data) {
  const summaryElement = document.getElementById('election-summary');
  summaryElement.classList.remove('hidden');
  
  // Use the values calculated by the server instead of recalculating
  const totalVoters = data.total_voters || 0;
  const totalVotes = data.total_votes_cast || 0;
  const turnoutRate = data.turnout_rate || 0;
  
  // Update summary cards
  document.getElementById('total-voters-count').textContent = totalVoters;
  document.getElementById('votes-cast-count').textContent = totalVotes;
  document.getElementById('turnout-rate').textContent = `${turnoutRate.toFixed(1)}%`;
  
  // Update the main total voters display
  document.getElementById('total-voters').textContent = `${totalVoters} total voters`;
}

function updateAnalyticsDashboard(data) {
  // This would be implemented to create various analytical charts
  // For now, we'll just show placeholder text
  const trendCtx = document.getElementById('trend-chart').getContext('2d');
  const categoryCtx = document.getElementById('category-chart').getContext('2d');
  const timeCtx = document.getElementById('time-chart').getContext('2d');
  const departmentCtx = document.getElementById('department-chart').getContext('2d');
  
  // Destroy existing charts
  Object.values(analyticsCharts).forEach(chart => {
    if (chart && typeof chart.destroy === 'function') {
      chart.destroy();
    }
  });
  
  // Create simple placeholder charts
  analyticsCharts.trend = new Chart(trendCtx, {
    type: 'line',
    data: {
      labels: ['10:00', '11:00', '12:00', '13:00', '14:00', '15:00'],
      datasets: [{
        label: 'Votes per hour',
        data: [65, 59, 80, 81, 56, 55],
        fill: false,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }]
    }
  });
  
  analyticsCharts.category = new Chart(categoryCtx, {
    type: 'bar',
    data: {
      labels: categories,
      datasets: [{
        label: 'Votes by category',
        data: categories.map(() => Math.floor(Math.random() * 100)),
        backgroundColor: 'rgba(255, 99, 132, 0.8)'
      }]
    }
  });
  
  // More charts would be implemented here with real data
}

function toggleAnalytics() {
  const analyticsDashboard = document.getElementById('analytics-dashboard');
  const analyticsToggle = document.getElementById('analytics-toggle');
  
  if (analyticsDashboard.classList.contains('hidden')) {
    analyticsDashboard.classList.remove('hidden');
    analyticsToggle.innerHTML = '<i class="fas fa-chart-line mr-2"></i> Hide Analytics Dashboard';
    
    // Load analytics data if we have election data
    if (document.getElementById('results-election-select').value) {
      // This would load real analytics data
      // For now, we'll just show placeholder charts
      updateAnalyticsDashboard();
    }
  } else {
    analyticsDashboard.classList.add('hidden');
    analyticsToggle.innerHTML = '<i class="fas fa-chart-line mr-2"></i> Show Analytics Dashboard';
  }
}

function toggleAccessibility() {
  highContrastMode = !highContrastMode;
  const accessibilityToggle = document.getElementById('accessibility-toggle');
  
  if (highContrastMode) {
    document.documentElement.classList.add('high-contrast');
    accessibilityToggle.classList.add('bg-yellow-400');
    accessibilityToggle.title = 'Standard Contrast Mode';
    showNotification('High contrast mode enabled');
  } else {
    document.documentElement.classList.remove('high-contrast');
    accessibilityToggle.classList.remove('bg-yellow-400');
    accessibilityToggle.title = 'High Contrast Mode';
    showNotification('High contrast mode disabled');
  }
  
  // Recreate charts with appropriate colors
  if (document.getElementById('results-election-select').value) {
    const chartType = document.getElementById('chart-type').value;
    allPositions.forEach(position => {
      createChart(position, chartType);
    });
  }
}

function startTimeRemainingCounter() {
  if (!currentElection?.endDate) return;
  
  const updateTime = () => {
    const now = new Date();
    const endDate = new Date(currentElection.endDate);
    const diff = endDate - now;
    
    if (diff <= 0) {
      document.getElementById('time-remaining').textContent = 'Election Ended';
      return;
    }
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    
    document.getElementById('time-remaining').textContent = 
      `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  updateTime();
  setInterval(updateTime, 1000);
}

function startAutoRefresh(interval) {
  clearExistingInterval();
  realTimeResults = setInterval(loadResults, interval);
}

function clearExistingInterval() {
  if (realTimeResults) {
    clearInterval(realTimeResults);
    realTimeResults = null;
  }
}

function toggleAutoRefresh() {
  const isEnabled = document.getElementById('auto-refresh-toggle').checked;
  const interval = parseInt(document.getElementById('refresh-interval').value);
  
  if (isEnabled && document.getElementById('results-election-select').value) {
    startAutoRefresh(interval);
  } else {
    clearExistingInterval();
  }
}

function updateRefreshInterval() {
  if (document.getElementById('auto-refresh-toggle').checked) {
    const interval = parseInt(document.getElementById('refresh-interval').value);
    startAutoRefresh(interval);
  }
}

function updateViewMode() {
  if (document.getElementById('results-election-select').value) {
    loadResults();
  }
}

function manualRefresh() {
  if (document.getElementById('results-election-select').value) {
    // Clear cache to force fresh data
    resultsCache.delete(document.getElementById('results-election-select').value);
    loadResults();
  }
}

function handleExport() {
  const electionId = document.getElementById('results-election-select').value;
  if (!electionId) {
    showError('Please select an election first');
    return;
  }
  
  const format = document.getElementById('export-format').value;
  exportResults(format);
}

function exportResults(format = 'csv') {
  const electionId = document.getElementById('results-election-select').value;
  if (!electionId) {
    showError('Please select an election first');
    return;
  }
  
  const electionSelect = document.getElementById('results-election-select');
  const selectedOption = electionSelect.options[electionSelect.selectedIndex];
  const electionName = selectedOption.textContent.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  
  // Show loading state
  const exportBtn = document.getElementById('export-results-btn');
  const originalText = exportBtn.innerHTML;
  exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Exporting...';
  exportBtn.disabled = true;
  
  // Create export URL with timestamp for unique filename
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `election_results_${electionName}_${timestamp}`;
  
  fetch(`${BASE_URL}/api/voting/results.php?election_id=${electionId}&export=1&format=${format}`)
    .then(response => {
      if (!response.ok) {
        throw new Error('Export failed');
      }
      return response.blob();
    })
    .then(blob => {
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `${filename}.${format}`;
      document.body.appendChild(a);
      a.click();
      
      // Clean up
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      // Show success message
      showExportSuccess();
    })
    .catch(error => {
      console.error('Export error:', error);
      showError('Failed to export results. Please try again.');
    })
    .finally(() => {
      // Restore button state
      exportBtn.innerHTML = originalText;
      exportBtn.disabled = false;
    });
}

function showExportOptions() {
  const modalHtml = `
    <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Export Options</h3>
        
        <div class="space-y-4">
          <div>
            <label class="flex items-center">
              <input type="checkbox" id="export-summary" checked class="rounded border-gray-300 text-pink-600 focus:ring-pink-500">
              <span class="ml-2 text-sm text-gray-600">Include election summary</span>
            </label>
          </div>
          
          <div>
            <label class="flex items-center">
              <input type="checkbox" id="export-candidates" checked class="rounded border-gray-300 text-pink-600 focus:ring-pink-500">
              <span class="ml-2 text-sm text-gray-600">Include candidate details</span>
            </label>
          </div>
          
          <div>
            <label class="flex items-center">
              <input type="checkbox" id="export-charts" class="rounded border-gray-300 text-pink-600 focus:ring-pink-500">
              <span class="ml-2 text-sm text-gray-600">Include charts (PDF only)</span>
            </label>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
            <div class="flex space-x-2">
              <input type="date" id="export-start-date" class="flex-1 border border-gray-300 rounded-md px-3 py-2">
              <input type="date" id="export-end-date" class="flex-1 border border-gray-300 rounded-md px-3 py-2">
            </div>
          </div>
        </div>
        
        <div class="mt-6 flex justify-end space-x-3">
          <button onclick="closeExportModal()" class="px-4 py-2 text-sm text-gray-600 hover:text-gray-800">Cancel</button>
          <button onclick="processExport()" class="px-4 py-2 bg-pink-600 text-white rounded-md text-sm hover:bg-pink-700">Export</button>
        </div>
      </div>
    </div>
  `;
  
  const modal = document.createElement('div');
  modal.innerHTML = modalHtml;
  modal.id = 'export-modal';
  document.body.appendChild(modal);
}

function closeExportModal() {
  const modal = document.getElementById('export-modal');
  if (modal) {
    modal.remove();
  }
}

function closeAllModals() {
  const modals = document.querySelectorAll('[id$="-modal"]');
  modals.forEach(modal => modal.remove());
}

function processExport() {
  // Get options from modal
  const includeSummary = document.getElementById('export-summary').checked;
  const includeCandidates = document.getElementById('export-candidates').checked;
  const includeCharts = document.getElementById('export-charts').checked;
  const startDate = document.getElementById('export-start-date').value;
  const endDate = document.getElementById('export-end-date').value;
  
  // Close modal
  closeExportModal();
  
  // Build export URL with options
  const electionId = document.getElementById('results-election-select').value;
  const format = document.getElementById('export-format').value;
  
  let exportUrl = `${BASE_URL}/api/voting/results.php?election_id=${electionId}&export=1&format=${format}`;
  exportUrl += `&summary=${includeSummary ? 1 : 0}`;
  exportUrl += `&candidates=${includeCandidates ? 1 : 0}`;
  exportUrl += `&charts=${includeCharts ? 1 : 0}`;
  
  if (startDate) exportUrl += `&start_date=${startDate}`;
  if (endDate) exportUrl += `&end_date=${endDate}`;
  
  // Trigger download
  window.open(exportUrl, '_blank');
}

function updateLastUpdatedTime() {
  const now = new Date();
  const timeString = now.toLocaleTimeString();
  document.getElementById('last-update').textContent = `Last update: ${timeString}`;
}

function showLoading(show) {
  document.getElementById('loading-overlay').classList.toggle('hidden', !show);
}

function showError(message) {
  const errorDiv = document.createElement('div');
  errorDiv.className = 'fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg z-50';
  errorDiv.innerHTML = `
    <div class="flex items-center">
      <i class="fas fa-exclamation-circle mr-3"></i>
      <span>${message}</span>
      <button class="ml-4 text-red-700 hover:text-red-900" onclick="this.parentElement.parentElement.remove()">
        <i class="fas fa-times"></i>
      </button>
    </div>
  `;
  
  document.body.appendChild(errorDiv);
  setTimeout(() => {
    if (errorDiv.parentElement) {
      errorDiv.remove();
    }
  }, 5000);
}

function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'fixed bottom-4 right-4 bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded-lg shadow-lg';
  notification.innerHTML = `
    <div class="flex items-center">
      <i class="fas fa-info-circle mr-2"></i>
      <span>${message}</span>
    </div>
  `;
  document.body.appendChild(notification);
  
  setTimeout(() => {
    if (notification.parentElement) {
      notification.remove();
    }
  }, 3000);
}

function showExportSuccess() {
  const successDiv = document.createElement('div');
  successDiv.className = 'fixed top-4 right-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-lg z-50';
  successDiv.innerHTML = `
    <div class="flex items-center">
      <i class="fas fa-check-circle mr-3"></i>
      <span>Results exported successfully!</span>
      <button class="ml-4 text-green-700 hover:text-green-900" onclick="this.parentElement.parentElement.remove()">
        <i class="fas fa-times"></i>
      </button>
    </div>
  `;
  
  document.body.appendChild(successDiv);
  setTimeout(() => {
    if (successDiv.parentElement) {
      successDiv.remove();
    }
  }, 5000);
}

function clearResults() {
  document.getElementById('results-container').innerHTML = `
    <div class="bg-white rounded-lg shadow p-8 text-center">
      <div class="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
        <i class="fas fa-chart-bar text-3xl text-gray-400"></i>
      </div>
      <h3 class="text-lg font-medium text-gray-600">Select an election to view results</h3>
    </div>
  `;
  document.getElementById('election-summary').classList.add('hidden');
  document.getElementById('overall-progress').classList.add('hidden');
  document.getElementById('analytics-dashboard').classList.add('hidden');
  document.getElementById('analytics-toggle').innerHTML = '<i class="fas fa-chart-line mr-2"></i> Show Analytics Dashboard';
  document.getElementById('category-filter').innerHTML = '<option value="all">All Categories</option>';
  clearExistingInterval();
}

function clearExistingResults() {
  // Destroy all chart instances
  Object.values(chartInstances).forEach(chart => {
    if (chart && typeof chart.destroy === 'function') {
      chart.destroy();
    }
  });
  chartInstances = {};
  
  // Destroy analytics charts
  Object.values(analyticsCharts).forEach(chart => {
    if (chart && typeof chart.destroy === 'function') {
      chart.destroy();
    }
  });
  analyticsCharts = {};
}

function showNoResults() {
  document.getElementById('results-container').innerHTML = `
    <div class="bg-white rounded-lg shadow p-8 text-center">
      <div class="inline-flex items-center justify-center w-16 h-16 bg-yellow-100 rounded-full mb-4">
        <i class="fas fa-exclamation-triangle text-3xl text-yellow-400"></i>
      </div>
      <h3 class="text-lg font-medium text-gray-600">No results available</h3>
      <p class="text-sm text-gray-500 mt-1">There are no results to display for this election yet.</p>
    </div>
  `;
}

// Utility functions
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function getContrastColor(hexColor) {
  // Convert hex to RGB
  const r = parseInt(hexColor.substr(1, 2), 16);
  const g = parseInt(hexColor.substr(3, 2), 16);
  const b = parseInt(hexColor.substr(5, 2), 16);
  
  // Calculate luminance
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  
  // Return black or white depending on luminance
  return luminance > 0.5 ? '#000000' : '#FFFFFF';
}
</script>

<style>
.switch {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 24px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: .4s;
  border-radius: 24px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 18px;
  width: 18px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  transition: .4s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: #ec4899;
}

input:checked + .slider:before {
  transform: translateX(26px);
}

.chart-container {
  transition: all 0.3s ease;
}

.bg-white.rounded-lg.shadow {
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.bg-white.rounded-lg.shadow:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
}

/* Animation for live updates */
@keyframes highlightUpdate {
  0% { background-color: transparent; }
  50% { background-color: rgba(34, 197, 94, 0.1); }
  100% { background-color: transparent; }
}

.updated-row {
  animation: highlightUpdate 2s ease;
}

/* Custom styles for form elements */
.input-label {
  display: block;
  font-size: 0.875rem;
  font-weight: 500;
  color: #374151;
  margin-bottom: 0.25rem;
}

.input-field {
  display: block;
  width: 100%;
  padding: 0.5rem 0.75rem;
  border: 1px solid #D1D5DB;
  border-radius: 0.375rem;
  font-size: 0.875rem;
}

.card {
  background: white;
  border-radius: 0.5rem;
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
}

/* High contrast mode */
.high-contrast {
  --bg-color: #000;
  --text-color: #fff;
  --border-color: #fff;
  --primary-color: #ffff00;
}

.high-contrast body {
  background-color: var(--bg-color);
  color: var(--text-color);
}

.high-contrast .bg-white {
  background-color: var(--bg-color) !important;
  color: var(--text-color) !important;
  border: 1px solid var(--border-color);
}

.high-contrast .text-gray-900,
.high-contrast .text-gray-700,
.high-contrast .text-gray-600,
.high-contrast .text-gray-500 {
  color: var(--text-color) !important;
}

.high-contrast .border-gray-300 {
  border-color: var(--border-color) !important;
}

.high-contrast .bg-pink-100 {
  background-color: var(--primary-color) !important;
  color: #000 !important;
}

.high-contrast .bg-pink-600 {
  background-color: var(--primary-color) !important;
}

.high-contrast .bg-green-100 {
  background-color: #00ff00 !important;
  color: #000 !important;
}

.high-contrast .bg-blue-100 {
  background-color: #0000ff !important;
  color: #fff !important;
}

.high-contrast .bg-purple-100 {
  background-color: #ff00ff !important;
  color: #000 !important;
}

.high-contrast .bg-orange-100 {
  background-color: #ffa500 !important;
  color: #000 !important;
}

.high-contrast .bg-yellow-100 {
  background-color: #ffff00 !important;
  color: #000 !important;
}

.high-contrast .bg-gray-100 {
  background-color: #333 !important;
  color: #fff !important;
}

.high-contrast .bg-gray-200 {
  background-color: #666 !important;
}

.high-contrast .shadow {
  box-shadow: 0 4px 6px -1px rgba(255, 255, 255, 0.1), 0 2px 4px -1px rgba(255, 255, 255, 0.06) !important;
}

/* Loading animation for export button */
#export-results-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.fa-spinner {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Mobile responsiveness */
@media (max-width: 768px) {
  .max-w-7xl {
    padding: 1rem;
  }
  
  .election-controls {
    flex-direction: column;
    gap: 1rem;
  }
  
  .control-group {
    width: 100% !important;
  }
  
  .chart-container {
    height: 250px !important;
  }
  
  /* Touch-friendly elements */
  button, select, input {
    min-height: 44px;
    min-width: 44px;
  }
}
</style>

<?php require_once APP_ROOT . '/includes/footer.php'; ?>