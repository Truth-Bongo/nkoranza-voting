<?php 
// Remove the session_start() call since it's already handled in bootstrap.php

if (empty($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
    header("Location: ../index.php?page=login");
    exit;
}

// Restrict admin access to vote page
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
    header("Location: ../index.php?page=admin/dashboard");
    exit;
}

require_once __DIR__ . '/../config/constants.php';

// Force student to login before voting - use the function from bootstrap.php
require_student_login();

// Check if user has already voted in any election
try {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare('SELECT election_id FROM votes WHERE user_id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id']]);
    $alreadyVoted = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($alreadyVoted) {
        // User has already voted, show message and exit
        require_once APP_ROOT . '/includes/header.php';
        echo '<div class="max-w-4xl mx-auto mt-8">';
        echo '<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">';
        echo '<strong class="font-bold">Thank you!</strong>';
        echo '<span class="block sm:inline"> You have already cast your vote. Results will be announced after the election period.</span>';
        echo '</div>';
        echo '<div class="text-center mt-6">';
        echo '<a href="' . BASE_URL . '" class="bg-pink-900 hover:bg-pink-800 text-white font-semibold py-2 px-6 rounded-lg inline-block">Return to Home</a>';
        echo '</div>';
        echo '</div>';
        require_once APP_ROOT . '/includes/footer.php';
        exit;
    }
} catch (Exception $e) {
    // Continue even if there's an error checking vote status
    error_log("Error checking vote status: " . $e->getMessage());
}

require_once APP_ROOT . '/includes/header.php'; 

// Get active elections
try {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare('SELECT * FROM elections WHERE start_date <= NOW() AND end_date >= NOW()');
    $stmt->execute();
    $activeElections = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($activeElections)) {
        echo '<div class="max-w-4xl mx-auto mt-8">';
        echo '<div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded relative">';
        echo '<strong class="font-bold">Notice:</strong>';
        echo '<span class="block sm:inline"> There are no active elections at this time. Please check back later.</span>';
        echo '</div>';
        echo '</div>';
        require_once APP_ROOT . '/includes/footer.php';
        exit;
    }
} catch (Exception $e) {
    // Handle error
    error_log("Error checking active elections: " . $e->getMessage());
}
?>
<div class="max-w-7xl mx-auto px-4 py-8">
  <!-- Election Info Bar -->
  <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
    <div>
      <h2 class="text-3xl font-bold text-gray-900 mb-2">Cast Your Vote</h2>
      <p class="text-gray-600">Select your preferred candidates for each position</p>
    </div>
    
    <!-- Quick Actions -->
    <div class="flex flex-wrap gap-2">
      <button id="toggle-help" class="bg-blue-100 hover:bg-blue-200 text-blue-800 px-3 py-2 rounded-lg text-sm font-medium">
        <i class="fas fa-question-circle mr-1"></i> Voting Help
      </button>
      <button id="toggle-contrast" class="bg-gray-200 hover:bg-gray-300 text-gray-800 px-3 py-2 rounded-lg text-sm font-medium">
        <i class="fas fa-adjust mr-1"></i> High Contrast
      </button>
      <button id="share-vote" class="bg-green-100 hover:bg-green-200 text-green-800 px-3 py-2 rounded-lg text-sm font-medium">
        <i class="fas fa-share-alt mr-1"></i> Share
      </button>
    </div>
  </div>
  
  <!-- Progress Indicator -->
  <div class="mb-8 bg-white rounded-lg shadow-sm p-4 border border-gray-200">
    <div class="flex justify-between items-center mb-2">
      <span class="text-sm font-medium text-gray-700">Your Voting Progress</span>
      <span id="progress-percent" class="text-sm font-semibold text-pink-600">0%</span>
    </div>
    <div class="bg-gray-200 rounded-full h-2.5">
      <div id="vote-progress" class="bg-pink-600 h-2.5 rounded-full transition-all duration-300" style="width: 0%"></div>
    </div>
    <div class="flex justify-between mt-2">
      <span class="text-xs text-gray-500">0 positions completed</span>
      <span class="text-xs text-gray-500" id="total-positions">0 positions total</span>
    </div>
  </div>
  
  <div class="flex flex-col lg:flex-row gap-6">
    <!-- Left Column - Election Selection & Info -->
    <div class="lg:w-1/4">
      <div class="bg-white rounded-lg shadow-lg p-6 border border-gray-100 sticky top-6">
        <div class="mb-6">
          <label for="election-select" class="block text-sm font-medium text-gray-700 mb-2">Select Election</label>
          <select id="election-select" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all duration-200">
            <option value="">Loading elections...</option>
          </select>
        </div>
        
        <div id="election-info" class="hidden">
          <div class="p-4 bg-blue-50 rounded-lg border border-blue-100 mb-4">
            <h3 class="text-lg font-semibold text-blue-800" id="election-title"></h3>
            <p class="text-blue-600 text-sm mt-1" id="election-description"></p>
          </div>
          
          <div class="grid grid-cols-2 gap-4 mb-4">
            <div class="bg-gray-50 p-3 rounded-lg text-center">
              <p class="text-xs text-gray-500">Starts</p>
              <p class="text-sm font-medium text-gray-800" id="election-start"></p>
            </div>
            <div class="bg-gray-50 p-3 rounded-lg text-center">
              <p class="text-xs text-gray-500">Ends</p>
              <p class="text-sm font-medium text-gray-800" id="election-end"></p>
            </div>
          </div>
          
          <div class="bg-pink-50 p-3 rounded-lg border border-pink-100 mb-4">
            <div class="flex justify-between items-center mb-2">
              <p class="text-xs text-pink-700 font-medium">TIME REMAINING</p>
              <i class="fas fa-clock text-pink-600"></i>
            </div>
            <p class="text-lg font-bold text-pink-700" id="time-left"></p>
          </div>
        </div>
        
        <!-- Category Navigation -->
        <div id="category-navigation" class="hidden">
          <h3 class="text-sm font-medium text-gray-700 mb-3">Voting Categories</h3>
          <div id="category-tabs" class="space-y-2">
            <!-- Category tabs will be generated here -->
          </div>
        </div>
      </div>
      
      <!-- Help Panel -->
      <div id="help-panel" class="hidden mt-6 bg-white rounded-lg shadow-lg p-6 border border-gray-100">
        <h3 class="text-lg font-semibold text-gray-800 mb-3 flex items-center">
          <i class="fas fa-question-circle text-blue-500 mr-2"></i>Voting Assistance
        </h3>
        <div class="space-y-3 text-sm text-gray-600">
          <div class="flex items-start">
            <div class="bg-blue-100 p-2 rounded-full mr-3">
              <i class="fas fa-info-circle text-blue-500"></i>
            </div>
            <p>Select one candidate for each position in the category.</p>
          </div>
          <div class="flex items-start">
            <div class="bg-blue-100 p-2 rounded-full mr-3">
              <i class="fas fa-check-circle text-green-500"></i>
            </div>
            <p>Complete all categories before submitting your vote.</p>
          </div>
          <div class="flex items-start">
            <div class="bg-blue-100 p-2 rounded-full mr-3">
              <i class="fas fa-undo text-pink-500"></i>
            </div>
            <p>You can change your selection until you submit your vote.</p>
          </div>
          <div class="flex items-start">
            <div class="bg-blue-100 p-2 rounded-full mr-3">
              <i class="fas fa-home text-pink-500"></i>
            </div>
            <p>After successfull submission, return to home and logout.</p>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Right Column - Voting Area -->
    <div class="lg:w-3/4">
      <div id="vote-container" class="bg-white rounded-lg shadow-lg p-6 border border-gray-100">
        <!-- Current Category Display -->
        <div id="current-category" class="hidden mb-6 p-4 bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg border border-pink-200">
          <div class="flex items-center justify-between">
            <div>
              <h3 class="text-xl font-semibold text-pink-800 flex items-center">
                <i class="fas fa-tag mr-2"></i>
                <span id="current-category-name">Loading...</span>
              </h3>
              <p class="text-sm text-pink-600 mt-1">Select your preferred candidate for each position</p>
            </div>
            <div class="bg-white px-3 py-1 rounded-full border border-pink-200">
              <span class="text-sm text-pink-700 font-medium" id="category-progress">0/0</span>
            </div>
          </div>
        </div>
        
        <!-- Positions Container - Side by Side Layout -->
        <div id="positions-container" class="mb-6">
          <div class="text-center py-12">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
              <i class="fas fa-vote-yea text-3xl text-gray-400"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-600">Select an election to view positions</h3>
            <p class="text-sm text-gray-500 mt-1">Choose from the dropdown to see available positions</p>
          </div>
        </div>
        
        <!-- Navigation Buttons -->
        <div id="category-navigation-buttons" class="hidden flex justify-between mt-8 pt-6 border-t border-gray-200">
          <button id="prev-category" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-5 rounded-lg transition-all duration-200">
            <i class="fas fa-arrow-left mr-2"></i>Previous Category
          </button>
          <button id="next-category" class="bg-pink-900 hover:bg-pink-800 text-white font-semibold py-2 px-5 rounded-lg transition-all duration-200">
            Next Category<i class="fas fa-arrow-right ml-2"></i>
          </button>
        </div>
        
        <!-- Review Section -->
        <div id="review-section" class="hidden mt-8 p-6 bg-gray-50 rounded-lg border border-gray-200">
          <h3 class="text-xl font-semibold text-gray-800 mb-6 flex items-center">
            <i class="fas fa-eye mr-2"></i>Review Your Votes
          </h3>
          <div id="review-content" class="space-y-6">
            <!-- Selected candidates will be listed here -->
          </div>
          <div class="mt-8 flex justify-between items-center">
            <button id="edit-votes" class="text-pink-700 hover:text-pink-900 font-medium py-2 px-4 rounded-lg border border-pink-200 hover:bg-pink-50">
              <i class="fas fa-edit mr-2"></i>Edit Votes
            </button>
            <div class="flex gap-3">
              <button id="save-progress" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-5 rounded-lg transition-all duration-200">
                <i class="fas fa-save mr-2"></i>Save Progress
              </button>
              <button id="confirm-votes" class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-lg transition-all duration-200">
                <i class="fas fa-check-circle mr-2"></i>Confirm & Submit
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Candidate Profile Modal -->
<div id="candidate-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
  <div class="bg-white rounded-xl p-6 max-w-2xl mx-4 shadow-2xl max-h-[90vh] overflow-y-auto">
    <div class="flex justify-between items-start mb-4">
      <h3 class="text-xl font-semibold text-gray-900" id="candidate-modal-title">Candidate Profile</h3>
      <button id="close-candidate-modal" class="text-gray-500 hover:text-gray-700">
        <i class="fas fa-times text-xl"></i>
      </button>
    </div>
    <div id="candidate-modal-content" class="space-y-4">
      <!-- Candidate details will be loaded here -->
    </div>
  </div>
</div>

<!-- Compare Candidates Modal -->
<div id="compare-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
  <div class="bg-white rounded-xl p-6 max-w-4xl mx-4 shadow-2xl max-h-[90vh] overflow-y-auto w-full">
    <div class="flex justify-between items-start mb-4">
      <h3 class="text-xl font-semibold text-gray-900">Compare Candidates</h3>
      <button id="close-compare-modal" class="text-gray-500 hover:text-gray-700">
        <i class="fas fa-times text-xl"></i>
      </button>
    </div>
    <div id="compare-modal-content" class="grid grid-cols-1 md:grid-cols-2 gap-6">
      <!-- Candidate comparison will be loaded here -->
    </div>
  </div>
</div>

<!-- Share Modal -->
<div id="share-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
  <div class="bg-white rounded-xl p-6 max-w-md mx-4 shadow-2xl">
    <div class="text-center">
      <h3 class="text-xl font-semibold text-gray-900 mb-4">Share That You Voted</h3>
      <p class="text-gray-600 mb-6">Let others know you've participated in the election (your choices remain private)</p>
      <div class="flex justify-center space-x-4 mb-6">
        <button class="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full">
          <i class="fab fa-facebook-f text-lg"></i>
        </button>
        <button class="bg-blue-400 hover:bg-blue-500 text-white p-3 rounded-full">
          <i class="fab fa-twitter text-lg"></i>
        </button>
        <button class="bg-purple-600 hover:bg-purple-700 text-white p-3 rounded-full">
          <i class="fab fa-instagram text-lg"></i>
        </button>
        <button class="bg-green-500 hover:bg-green-600 text-white p-3 rounded-full">
          <i class="fab fa-whatsapp text-lg"></i>
        </button>
      </div>
      <div class="bg-gray-100 p-4 rounded-lg mb-4">
        <p class="text-sm text-gray-600 mb-2">Or copy this message:</p>
        <div class="flex items-center bg-white border border-gray-300 rounded-lg p-2">
          <span id="share-message" class="flex-1 text-sm text-gray-800">I just voted in the school elections! 🗳️ #SchoolElections #IVoted</span>
          <button id="copy-share-message" class="text-pink-600 hover:text-pink-800 ml-2">
            <i class="fas fa-copy"></i>
          </button>
        </div>
      </div>
      <button id="close-share-modal" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-medium py-2 px-5 rounded-lg">
        Close
      </button>
    </div>
  </div>
</div>

<!-- Success Modal -->
<div id="success-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
  <div class="bg-white rounded-xl p-8 max-w-md mx-4 shadow-2xl">
    <div class="text-center">
      <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
        <i class="fas fa-check-circle text-green-600 text-4xl"></i>
      </div>
      <h3 class="text-2xl font-bold text-gray-900 mb-3">Vote Submitted Successfully!</h3>
      <p class="text-gray-600 mb-6">Thank you for participating in this year's election. Your vote has been recorded.</p>
      
      <!-- Vote Verification -->
      <div class="bg-gray-50 p-4 rounded-lg mb-6 text-left">
        <h4 class="font-semibold text-gray-800 mb-2 flex items-center">
          <i class="fas fa-shield-check text-green-500 mr-2"></i>Vote Verification
        </h4>
        <p class="text-sm text-gray-600">Your vote has been securely recorded with reference ID: <span id="vote-reference" class="font-mono"><?= bin2hex(random_bytes(4)) ?></span></p>
      </div>
      
      <div class="flex flex-col gap-3">
        <button onclick="window.location.href='<?= BASE_URL ?>'" class="bg-pink-900 hover:bg-pink-800 text-white font-semibold py-3 px-8 rounded-lg transition-colors">
          Return to Home
        </button>
        <button id="share-after-vote" class="bg-white border border-gray-300 hover:bg-gray-100 text-gray-800 font-medium py-2 px-5 rounded-lg">
          <i class="fas fa-share-alt mr-2"></i>Share That I Voted
        </button>
      </div>
    </div>
  </div>
</div>

<script>// Global variables
let currentElectionId = null;
let selectedCandidates = {};
let timeLeftInterval = null;
let totalPositions = 0;
let completedPositions = 0;
let currentCategoryIndex = 0;
let categories = [];
let categoryPositions = {};
let candidateDetails = {}; // Store candidate details for modals

// Function to get CSRF token from meta tag
function getCsrfToken() {
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    return metaTag ? metaTag.getAttribute('content') : '';
}

// Function to calculate time left
function calculateTimeLeft(endDate) {
    const now = new Date();
    const end = new Date(endDate);
    const difference = end - now;
    
    if (difference <= 0) {
        return { expired: true };
    }
    
    const days = Math.floor(difference / (1000 * 60 * 60 * 24));
    const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((difference % (1000 * 60)) / 1000);
    
    return {
        days,
        hours,
        minutes,
        seconds,
        expired: false
    };
}

// Function to format time left
function formatTimeLeft(timeLeft) {
    if (timeLeft.expired) {
        return 'Election ended';
    }
    
    if (timeLeft.days > 0) {
        return `${timeLeft.days}d ${timeLeft.hours}h ${timeLeft.minutes}m`;
    } else if (timeLeft.hours > 0) {
        return `${timeLeft.hours}h ${timeLeft.minutes}m ${timeLeft.seconds}s`;
    } else {
        return `${timeLeft.minutes}m ${timeLeft.seconds}s`;
    }
}

// Function to update time left display
function updateTimeLeft(endDate) {
    if (timeLeftInterval) {
        clearInterval(timeLeftInterval);
    }
    
    timeLeftInterval = setInterval(() => {
        const timeLeft = calculateTimeLeft(endDate);
        document.getElementById('time-left').textContent = formatTimeLeft(timeLeft);
        
        if (timeLeft.expired) {
            clearInterval(timeLeftInterval);
            const confirmButton = document.getElementById('confirm-votes');
            if (confirmButton) {
                confirmButton.disabled = true;
                confirmButton.textContent = 'Election Ended';
            }
        }
    }, 1000);
}

// Function to update progress indicator
function updateProgress() {
    completedPositions = Object.keys(selectedCandidates).length;
    const progress = totalPositions > 0 ? (completedPositions / totalPositions) * 100 : 0;
    
    document.getElementById('vote-progress').style.width = `${progress}%`;
    document.getElementById('progress-percent').textContent = `${Math.round(progress)}%`;
    
    // Update the positions completed text
    const completedText = document.querySelector('.flex.justify-between.mt-2 span:first-child');
    if (completedText) {
        completedText.textContent = `${completedPositions} positions completed`;
    }
    
    // Update category tabs
    updateCategoryTabs();
    
    // Enable/disable navigation buttons
    updateNavigationButtons();
}

// Function to update category tabs
function updateCategoryTabs() {
    const tabsContainer = document.getElementById('category-tabs');
    if (!tabsContainer) return;
    
    tabsContainer.innerHTML = '';
    
    categories.forEach((category, index) => {
        const categoryPositionsCount = categoryPositions[category] ? categoryPositions[category].length : 0;
        const completedInCategory = categoryPositions[category] ? 
            categoryPositions[category].filter(pos => selectedCandidates[pos.id]).length : 0;
        
        const tab = document.createElement('button');
        tab.className = `px-3 py-1.5 rounded-full text-xs font-medium transition-all ${index === currentCategoryIndex ? 
            'bg-pink-900 text-white' : 
            completedInCategory === categoryPositionsCount ? 
                'bg-green-100 text-green-800' : 
                'bg-gray-200 text-gray-800'}`;
        
        tab.innerHTML = `${category} <span class="ml-1">${completedInCategory}/${categoryPositionsCount}</span>`;
        tab.addEventListener('click', () => {
            if (index !== currentCategoryIndex) {
                showCategory(index);
            }
        });
        
        tabsContainer.appendChild(tab);
    });
}

// Function to update navigation buttons
function updateNavigationButtons() {
    const currentCategory = categories[currentCategoryIndex];
    const currentCategoryPositions = categoryPositions[currentCategory] || [];
    const completedInCategory = currentCategoryPositions.filter(pos => selectedCandidates[pos.id]).length;
    
    // Show/hide previous button
    const prevButton = document.getElementById('prev-category');
    if (prevButton) {
        prevButton.style.display = currentCategoryIndex > 0 ? 'block' : 'none';
    }
    
    // Update next button text
    const nextButton = document.getElementById('next-category');
    if (nextButton) {
        if (currentCategoryIndex < categories.length - 1) {
            nextButton.innerHTML = `Next Category <i class="fas fa-arrow-right ml-2"></i>`;
        } else {
            nextButton.innerHTML = `Review Votes <i class="fas fa-eye ml-2"></i>`;
        }
        
        // Enable/disable next button based on completion
        nextButton.disabled = completedInCategory < currentCategoryPositions.length;
    }
}

// Function to show a specific category
function showCategory(index) {
    currentCategoryIndex = index;
    const category = categories[index];
    
    // Update current category display
    document.getElementById('current-category-name').textContent = category;
    document.getElementById('current-category').classList.remove('hidden');
    
    // Update category progress
    const categoryPositionsList = categoryPositions[category] || [];
    const completedInCategory = categoryPositionsList.filter(pos => selectedCandidates[pos.id]).length;
    document.getElementById('category-progress').textContent = `${completedInCategory}/${categoryPositionsList.length}`;
    
    // Clear positions container
    const container = document.getElementById('positions-container');
    container.innerHTML = '';
    
    // Add positions for this category in a grid layout
    const positions = categoryPositions[category] || [];
    
    if (positions.length === 0) {
        container.innerHTML = `
            <div class="text-center py-8 text-gray-500">
                <i class="fas fa-info-circle text-2xl mb-2"></i>
                <p>No positions found in this category</p>
            </div>
        `;
        return;
    }
    
    // Create a grid container
    const gridContainer = document.createElement('div');
    gridContainer.className = 'grid grid-cols-1 md:grid-cols-2 gap-6';
    
    positions.forEach(position => {
        const positionCard = document.createElement('div');
        positionCard.className = 'position-card bg-white border border-gray-200 rounded-xl p-5 shadow-sm';
        positionCard.innerHTML = `
            <h4 class="text-lg font-semibold text-gray-800 mb-3 flex items-center">
                <i class="fas fa-user-circle mr-2 text-pink-600"></i>${position.name}
            </h4>
            ${position.description ? `<p class="text-sm text-gray-600 mb-4">${position.description}</p>` : ''}
            <div class="candidates-container" id="candidates-${position.id}">
                <div class="text-center py-4">
                    <div class="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-pink-600"></div>
                    <p class="mt-2 text-sm text-gray-500">Loading candidates...</p>
                </div>
            </div>
        `;
        gridContainer.appendChild(positionCard);
    });
    
    container.appendChild(gridContainer);
    
    // Show navigation buttons
    document.getElementById('category-navigation-buttons').classList.remove('hidden');
    
    // Update navigation buttons
    updateNavigationButtons();
    
    // Load candidates for each position after DOM is updated
    setTimeout(() => {
        positions.forEach(position => {
            loadCandidates(position.id);
        });
    }, 100);
}

// Function to show the review section
function showReviewSection() {
    document.getElementById('positions-container').classList.add('hidden');
    document.getElementById('category-navigation-buttons').classList.add('hidden');
    document.getElementById('current-category').classList.add('hidden');
    document.getElementById('review-section').classList.remove('hidden');
    
    prepareReviewContent();
}

// Function to go back to category voting
function backToVoting() {
    document.getElementById('review-section').classList.add('hidden');
    document.getElementById('positions-container').classList.remove('hidden');
    document.getElementById('category-navigation-buttons').classList.remove('hidden');
    document.getElementById('current-category').classList.remove('hidden');
}

// Function to prepare review content
function prepareReviewContent() {
    const reviewContent = document.getElementById('review-content');
    reviewContent.innerHTML = '';
    
    if (Object.keys(selectedCandidates).length === 0) {
        reviewContent.innerHTML = '<p class="text-gray-500 text-center py-8">No votes selected yet.</p>';
        return;
    }
    
    // Group selected candidates by category for better organization
    categories.forEach(category => {
        const categoryPositionsList = categoryPositions[category] || [];
        const categoryVotes = categoryPositionsList.filter(pos => selectedCandidates[pos.id]);
        
        if (categoryVotes.length > 0) {
            const categoryDiv = document.createElement('div');
            categoryDiv.className = 'mb-6';
            categoryDiv.innerHTML = `<h4 class="font-semibold text-pink-700 mb-3 text-lg border-b border-gray-200 pb-2">${category}</h4>`;
            
            const list = document.createElement('div');
            list.className = 'space-y-3';
            
            categoryVotes.forEach(position => {
                const candidateId = selectedCandidates[position.id];
                const candidateElement = document.querySelector(`#candidates-${position.id} .candidate-card input[value="${candidateId}"]`);
                
                if (candidateElement) {
                    const candidateName = candidateElement.closest('.candidate-card').querySelector('p.text-md').textContent;
                    
                    const listItem = document.createElement('div');
                    listItem.className = 'flex justify-between items-center bg-white p-3 rounded-lg border border-gray-200';
                    listItem.innerHTML = `
                        <div>
                            <span class="font-medium">${position.name}:</span>
                            <span class="text-gray-700 ml-2">${candidateName}</span>
                        </div>
                        <button class="text-pink-600 hover:text-pink-800 edit-vote-btn" data-position-id="${position.id}">
                            <i class="fas fa-edit"></i>
                        </button>
                    `;
                    
                    // Add click event to edit button
                    listItem.querySelector('.edit-vote-btn').addEventListener('click', () => {
                        // Find which category this position belongs to
                        let categoryIndex = 0;
                        for (let i = 0; i < categories.length; i++) {
                            if (categoryPositions[categories[i]].some(p => p.id === position.id)) {
                                categoryIndex = i;
                                break;
                            }
                        }
                        
                        // Go back to that category
                        backToVoting();
                        showCategory(categoryIndex);
                        
                        // Scroll to the position
                        setTimeout(() => {
                            const positionElement = document.getElementById(`candidates-${position.id}`).closest('.position-card');
                            if (positionElement) {
                                positionElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                
                                // Highlight the position
                                positionElement.classList.add('ring-2', 'ring-pink-500');
                                setTimeout(() => {
                                    positionElement.classList.remove('ring-2', 'ring-pink-500');
                                }, 2000);
                            }
                        }, 300);
                    });
                    
                    list.appendChild(listItem);
                }
            });
            
            categoryDiv.appendChild(list);
            reviewContent.appendChild(categoryDiv);
        }
    });
}

// Function to validate election status before submitting vote
async function validateElectionStatus(electionId) {
    try {
        const response = await fetch(`${BASE_URL}/api/voting/validate-election.php?election_id=${electionId}`);
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Election validation failed');
        }
        
        return data;
    } catch (error) {
        console.error('Error validating election:', error);
        throw error;
    }
}

// Function to show error message
function showError(message) {
    // Create or show error notification
    let errorDiv = document.getElementById('error-notification');
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.id = 'error-notification';
        errorDiv.className = 'fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg z-50';
        document.body.appendChild(errorDiv);
    }
    
    errorDiv.innerHTML = `
        <div class="flex items-center">
            <i class="fas fa-exclamation-circle mr-3"></i>
            <span>${message}</span>
            <button class="ml-4 text-red-700 hover:text-red-900" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (errorDiv.parentElement) {
            errorDiv.remove();
        }
    }, 5000);
}

// Function to submit vote
async function submitVote() {
    try {
        // Check if all positions have selections
        if (Object.keys(selectedCandidates).length < totalPositions) {
            showError('Please select candidates for all positions before submitting.');
            return;
        }
        
        // Get CSRF token
        const csrfToken = getCsrfToken();
        if (!csrfToken) {
            showError('Security token missing. Please refresh the page and try again.');
            return;
        }
        
        // Prepare vote data with CSRF token
        const voteData = {
            election_id: currentElectionId,
            votes: selectedCandidates,
            csrf_token: csrfToken
        };
        
        console.log('Submitting vote with data:', voteData);
        
        // Submit vote
        const response = await fetch(`${BASE_URL}/api/voting/vote.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(voteData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Show success modal
            document.getElementById('success-modal').classList.remove('hidden');
            
            // Clear saved progress
            localStorage.removeItem(`voteProgress_${currentElectionId}`);
        } else {
            showError('Failed to submit vote: ' + result.message);
            
            // If it's a CSRF error, suggest refreshing the page
            if (result.message.includes('token') || result.message.includes('security')) {
                showError('Security token invalid. Please refresh the page and try again.');
            }
        }
        
    } catch (error) {
        console.error('Error submitting vote:', error);
        showError('Failed to submit vote. Please try again.');
    }
}

// Function to load candidates for a position
async function loadCandidates(positionId) {
    // Wait a bit to ensure DOM is fully updated
    await new Promise(resolve => setTimeout(resolve, 50));
    
    const container = document.getElementById(`candidates-${positionId}`);
    if (!container) {
        console.warn(`Container not found for position ${positionId}, retrying...`);
        // Retry after a short delay
        setTimeout(() => loadCandidates(positionId), 100);
        return;
    }
    
    // Add loading overlay
    const loadingOverlay = document.createElement('div');
    loadingOverlay.className = 'loading-overlay';
    loadingOverlay.innerHTML = '<div class="loading-spinner"></div>';
    container.appendChild(loadingOverlay);
    
    try {
        console.log(`Loading candidates for position ${positionId}`);
        const response = await fetch(`${BASE_URL}/api/voting/candidates.php?position_id=${positionId}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to fetch candidates');
        }
        
        const candidates = data.candidates || [];
        
        // Remove loading overlay
        if (loadingOverlay.parentNode) {
            loadingOverlay.remove();
        }
        
        // Store candidate details for modal views
        candidates.forEach(candidate => {
            candidateDetails[candidate.id] = candidate;
        });
        
        if (candidates.length === 0) {
            container.innerHTML = `
                <div class="text-center py-4 text-yellow-600 bg-yellow-50 rounded-lg">
                    <i class="fas fa-exclamation-circle text-xl mb-2"></i>
                    <p class="text-sm">No candidates available for this position</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = '';
        
        candidates.forEach(candidate => {
            const photoUrl = candidate.photo_path || `${BASE_URL}/assets/images/default-avatar.png`;
            
            const candidateElement = document.createElement('div');
            candidateElement.className = 'candidate-card bg-white border border-gray-200 rounded-lg p-4 mb-4 hover:border-pink-300 cursor-pointer transition-all duration-200';
            candidateElement.innerHTML = `
                <div class="flex items-center space-x-4">
                    <div class="flex-shrink-0 relative">
                        <img class="h-14 w-14 rounded-full object-cover border-2 border-gray-200" 
                             src="${photoUrl}" 
                             alt="${candidate.first_name} ${candidate.last_name}"
                             onerror="this.onerror=null; this.src='${BASE_URL}/assets/images/default-avatar.png'">
                        <button class="absolute -bottom-1 -right-1 bg-pink-600 text-white p-1 rounded-full text-xs candidate-profile-btn" data-candidate-id="${candidate.id}">
                            <i class="fas fa-user"></i>
                        </button>
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-md font-semibold text-gray-900">${candidate.first_name} ${candidate.last_name}</p>
                        <p class="text-xs text-gray-500 mt-1">${candidate.department || 'General Candidate'}</p>
                        ${candidate.level ? `<p class="text-xs text-gray-400 mt-1">Level ${candidate.level}</p>` : ''}
                    </div>
                    <div class="flex-shrink-0">
                        <input type="radio" name="position-${positionId}" value="${candidate.id}" 
                               class="h-5 w-5 text-pink-600 focus:ring-pink-500 border-gray-300 candidate-radio">
                    </div>
                </div>
                ${candidate.manifesto ? `<div class="mt-3 text-xs text-gray-600 bg-gray-50 p-3 rounded-lg"><strong class="text-pink-600">Manifesto:</strong> ${candidate.manifesto.substring(0, 120)}${candidate.manifesto.length > 120 ? '...' : ''}</div>` : ''}
            `;
            
            // Add click event to select candidate
            candidateElement.addEventListener('click', (e) => {
                if (!e.target.matches('input[type="radio"]') && !e.target.closest('.candidate-profile-btn')) {
                    const radio = candidateElement.querySelector('.candidate-radio');
                    radio.checked = true;
                    radio.dispatchEvent(new Event('change'));
                }
            });
            
            // Add click event to profile button
            candidateElement.querySelector('.candidate-profile-btn').addEventListener('click', (e) => {
                e.stopPropagation();
                showCandidateProfile(candidate.id);
            });
            
            // Add change event to radio button
            const radio = candidateElement.querySelector('.candidate-radio');
            radio.addEventListener('change', (e) => {
                if (e.target.checked) {
                    selectedCandidates[positionId] = candidate.id;
                    // Highlight selected candidate
                    document.querySelectorAll(`#candidates-${positionId} .candidate-card`).forEach(card => {
                        card.classList.remove('border-pink-500', 'bg-pink-50', 'ring-2', 'ring-pink-300');
                    });
                    candidateElement.classList.add('border-pink-500', 'bg-pink-50', 'ring-2', 'ring-pink-300');
                    
                    // Update progress
                    updateProgress();
                }
            });
            
            // Pre-select if this candidate was previously selected
            if (selectedCandidates[positionId] == candidate.id) {
                radio.checked = true;
                candidateElement.classList.add('border-pink-500', 'bg-pink-50', 'ring-2', 'ring-pink-300');
            }
            
            container.appendChild(candidateElement);
        });
    } catch (error) {
        // Remove loading overlay on error
        if (loadingOverlay.parentNode) {
            loadingOverlay.remove();
        }
        
        console.error('Error loading candidates:', error);
        container.innerHTML = `
            <div class="text-center py-4 text-red-600 bg-red-50 rounded-lg">
                <i class="fas fa-exclamation-triangle text-xl mb-2"></i>
                <p class="text-sm font-medium">Failed to load candidates</p>
                <p class="text-xs mt-1 text-red-500">${error.message}</p>
                <button onclick="loadCandidates(${positionId})" class="mt-2 bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded text-xs">
                    Try Again
                </button>
            </div>
        `;
    }
}

// Helper function to format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

// Function to show candidate profile modal
function showCandidateProfile(candidateId) {
    const candidate = candidateDetails[candidateId];
    if (!candidate) return;
    
    document.getElementById('candidate-modal-title').textContent = `${candidate.first_name} ${candidate.last_name}'s Profile`;
    
    const modalContent = document.getElementById('candidate-modal-content');
    modalContent.innerHTML = `
        <div class="flex flex-col md:flex-row gap-6">
            <div class="md:w-1/3">
                <img src="${candidate.photo_path || `${BASE_URL}/assets/images/default-avatar.png`}" 
                     alt="${candidate.first_name} ${candidate.last_name}" 
                     class="w-full h-auto rounded-lg object-cover shadow-md">
            </div>
            <div class="md:w-2/3">
                <h4 class="text-lg font-semibold text-gray-800 mb-2">${candidate.first_name} ${candidate.last_name}</h4>
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <p class="text-xs text-gray-500">Department</p>
                        <p class="text-sm font-medium">${candidate.department || 'Not specified'}</p>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500">Level</p>
                        <p class="text-sm font-medium">${candidate.level || 'Not specified'}</p>
                    </div>
                </div>
                <div class="mb-4">
                    <p class="text-xs text-gray-500">Manifesto</p>
                    <p class="text-sm text-gray-800 mt-1">${candidate.manifesto || 'No manifesto provided.'}</p>
                </div>
                <div class="mb-4">
                    <p class="text-xs text-gray-500">Qualifications</p>
                    <p class="text-sm text-gray-800 mt-1">${candidate.qualifications || 'No qualifications provided.'}</p>
                </div>
                <div class="flex gap-2">
                    <button class="bg-pink-100 hover:bg-pink-200 text-pink-800 text-sm px-3 py-1 rounded-full">
                        <i class="fas fa-user-circle mr-1"></i> Candidate
                    </button>
                    <button class="bg-blue-100 hover:bg-blue-200 text-blue-800 text-sm px-3 py-1 rounded-full compare-candidate-btn" data-candidate-id="${candidateId}">
                        <i class="fas fa-balance-scale mr-1"></i> Compare
                    </button>
                </div>
            </div>
        </div>
    `;
    
    // Add event listener to compare button
    modalContent.querySelector('.compare-candidate-btn').addEventListener('click', function() {
        const candidateId = this.getAttribute('data-candidate-id');
        showCompareModal(candidateId);
    });
    
    document.getElementById('candidate-modal').classList.remove('hidden');
}

// Function to show compare modal
function showCompareModal(selectedCandidateId) {
    const positionId = Object.keys(selectedCandidates).find(posId => 
        document.querySelector(`#candidates-${posId} input[value="${selectedCandidateId}"]`)
    );
    
    if (!positionId) return;
    
    const candidates = Array.from(document.querySelectorAll(`#candidates-${positionId} .candidate-card`)).map(card => {
        const candidateId = card.querySelector('input').value;
        return candidateDetails[candidateId];
    }).filter(candidate => candidate);
    
    const modalContent = document.getElementById('compare-modal-content');
    modalContent.innerHTML = '';
    
    candidates.forEach(candidate => {
        const isSelected = selectedCandidateId == candidate.id;
        const candidateCard = document.createElement('div');
        candidateCard.className = `bg-white border rounded-lg p-4 ${isSelected ? 'border-pink-500 ring-2 ring-pink-200' : 'border-gray-200'}`;
        candidateCard.innerHTML = `
            <div class="text-center mb-4">
                <img src="${candidate.photo_path || `${BASE_URL}/assets/images/default-avatar.png`}" 
                     alt="${candidate.first_name} ${candidate.last_name}" 
                     class="w-20 h-20 rounded-full mx-auto object-cover border-2 ${isSelected ? 'border-pink-500' : 'border-gray-200'}">
                <h4 class="text-lg font-semibold mt-2">${candidate.first_name} ${candidate.last_name}</h4>
                <p class="text-sm text-gray-600">${candidate.department || ''}</p>
                ${isSelected ? '<span class="inline-block bg-pink-100 text-pink-800 text-xs px-2 py-1 rounded-full mt-1">Your Selection</span>' : ''}
            </div>
            <div class="space-y-3">
                <div>
                    <p class="text-xs text-gray-500">Level</p>
                    <p class="text-sm font-medium">${candidate.level || 'Not specified'}</p>
                </div>
                <div>
                    <p class="text-xs text-gray-500">Manifesto</p>
                    <p class="text-sm text-gray-800 line-clamp-3">${candidate.manifesto || 'No manifesto provided.'}</p>
                </div>
                <div>
                    <p class="text-xs text-gray-500">Qualifications</p>
                    <p class="text-sm text-gray-800 line-clamp-2">${candidate.qualifications || 'No qualifications provided.'}</p>
                </div>
            </div>
        `;
        modalContent.appendChild(candidateCard);
    });
    
    document.getElementById('candidate-modal').classList.add('hidden');
    document.getElementById('compare-modal').classList.remove('hidden');
}

// Function to toggle high contrast mode
function toggleHighContrast() {
    document.body.classList.toggle('high-contrast');
    localStorage.setItem('highContrastMode', document.body.classList.contains('high-contrast'));
    
    if (document.body.classList.contains('high-contrast')) {
        showSuccess('High contrast mode enabled');
    } else {
        showSuccess('High contrast mode disabled');
    }
}

// Function to show success message
function showSuccess(message) {
    // Create or show success notification
    let successDiv = document.getElementById('success-notification');
    if (!successDiv) {
        successDiv = document.createElement('div');
        successDiv.id = 'success-notification';
        successDiv.className = 'fixed top-4 right-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-lg z-50';
        document.body.appendChild(successDiv);
    }
    
    successDiv.innerHTML = `
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-3"></i>
            <span>${message}</span>
            <button class="ml-4 text-green-700 hover:text-green-900" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (successDiv.parentElement) {
            successDiv.remove();
        }
    }, 5000);
}

// Function to save progress to local storage
function saveProgress() {
    if (currentElectionId && Object.keys(selectedCandidates).length > 0) {
        const progressData = {
            electionId: currentElectionId,
            selections: selectedCandidates,
            timestamp: new Date().getTime()
        };
        
        localStorage.setItem(`voteProgress_${currentElectionId}`, JSON.stringify(progressData));
        showSuccess('Progress saved locally!');
    }
}

// Function to load progress from local storage
function loadProgress(electionId) {
    const savedProgress = localStorage.getItem(`voteProgress_${electionId}`);
    if (savedProgress) {
        try {
            const progressData = JSON.parse(savedProgress);
            
            // Check if the saved progress is for the current election and not too old (e.g., 24 hours)
            const now = new Date().getTime();
            if (progressData.electionId === electionId && (now - progressData.timestamp) < 24 * 60 * 60 * 1000) {
                selectedCandidates = progressData.selections;
                
                // Update UI to reflect saved selections
                Object.keys(selectedCandidates).forEach(positionId => {
                    const radio = document.querySelector(`input[name="position-${positionId}"][value="${selectedCandidates[positionId]}"]`);
                    if (radio) {
                        radio.checked = true;
                        radio.dispatchEvent(new Event('change'));
                    }
                });
                
                showSuccess('Previous progress loaded!');
                return true;
            }
        } catch (e) {
            console.error('Error loading saved progress:', e);
        }
    }
    return false;
}

// Function to create side-by-side layout for positions
function createPositionsLayout(positions) {
    const container = document.getElementById('positions-container');
    container.innerHTML = '';
    
    if (positions.length === 0) {
        container.innerHTML = `
            <div class="text-center py-8 text-gray-500">
                <i class="fas fa-info-circle text-2xl mb-2"></i>
                <p>No positions found in this category</p>
            </div>
        `;
        return;
    }
    
    // Create grid layout based on number of positions
    let gridCols = 'grid-cols-1';
    if (positions.length === 2) {
        gridCols = 'grid-cols-1 md:grid-cols-2';
    } else if (positions.length >= 3) {
        gridCols = 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
    }
    
    const grid = document.createElement('div');
    grid.className = `grid ${gridCols} gap-6`;
    
    positions.forEach(position => {
        const positionCard = document.createElement('div');
        positionCard.className = 'position-card bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow duration-200 h-full';
        positionCard.innerHTML = `
            <h4 class="text-lg font-semibold text-gray-800 mb-3 flex items-center">
                <i class="fas fa-user-circle mr-2 text-pink-600"></i>${position.name}
            </h4>
            ${position.description ? `<p class="text-sm text-gray-600 mb-4">${position.description}</p>` : ''}
            <div class="candidates-container" id="candidates-${position.id}">
                <div class="text-center py-4">
                    <div class="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-pink-600"></div>
                    <p class="mt-2 text-sm text-gray-500">Loading candidates...</p>
                </div>
            </div>
        `;
        grid.appendChild(positionCard);
        
        // Load candidates for this position
        loadCandidates(position.id);
    });
    
    container.appendChild(grid);
}

// Function to handle election selection change
function handleElectionChange(event) {
    const electionId = event.target.value;
    const selectedOption = event.target.options[event.target.selectedIndex];
    
    if (!electionId) {
        document.getElementById('election-info').classList.add('hidden');
        document.getElementById('positions-container').innerHTML = '<p class="text-center text-gray-500">Select an election to view positions</p>';
        document.getElementById('category-navigation').classList.add('hidden');
        document.getElementById('category-navigation-buttons').classList.add('hidden');
        document.getElementById('current-category').classList.add('hidden');
        document.getElementById('review-section').classList.add('hidden');
        return;
    }
    
    currentElectionId = electionId;
    selectedCandidates = {};
    currentCategoryIndex = 0;
    candidateDetails = {};
    
    // Reset progress
    completedPositions = 0;
    document.getElementById('vote-progress').style.width = '0%';
    document.getElementById('progress-percent').textContent = '0%';
    const completedText = document.querySelector('.flex.justify-between.mt-2 span:first-child');
    if (completedText) {
        completedText.textContent = '0 positions completed';
    }
    
    // Show election info
    const electionInfo = document.getElementById('election-info');
    document.getElementById('election-title').textContent = selectedOption.textContent;
    document.getElementById('election-description').textContent = selectedOption.getAttribute('data-description');
    document.getElementById('election-start').textContent = formatDate(selectedOption.getAttribute('data-start-date'));
    document.getElementById('election-end').textContent = formatDate(selectedOption.getAttribute('data-end-date'));
    electionInfo.classList.remove('hidden');
    
    // Start time left counter
    updateTimeLeft(selectedOption.getAttribute('data-end-date'));
    
    // Hide review section and show positions container
    document.getElementById('review-section').classList.add('hidden');
    document.getElementById('positions-container').classList.remove('hidden');
    
    loadPositionsByCategory(electionId);
}

// Function to load positions by category
async function loadPositionsByCategory(electionId) {
    const container = document.getElementById('positions-container');
    container.innerHTML = `
        <div class="text-center py-12">
            <div class="inline-block animate-spin rounded-full h-10 w-10 border-b-2 border-pink-600"></div>
            <p class="mt-4 text-gray-500">Loading positions...</p>
        </div>
    `;
    
    try {
        const response = await fetch(`${BASE_URL}/api/voting/positions.php?election_id=${electionId}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to fetch positions');
        }
        
        const positions = data.positions || [];
        totalPositions = positions.length;
        document.getElementById('total-positions').textContent = `${totalPositions} positions total`;
        
        if (positions.length === 0) {
            container.innerHTML = '<p class="text-center text-gray-500 py-12">No positions found for this election</p>';
            return;
        }
        
        // Group positions by category
        categoryPositions = {};
        positions.forEach(position => {
            const category = position.category || 'General';
            if (!categoryPositions[category]) {
                categoryPositions[category] = [];
            }
            categoryPositions[category].push(position);
        });
        
        // Get all unique categories from the database
        categories = Object.keys(categoryPositions);
        
        // Show category navigation
        document.getElementById('category-navigation').classList.remove('hidden');
        
        // Update category tabs
        updateCategoryTabs();
        
        // Try to load saved progress
        loadProgress(electionId);
        
        // Show the first category
        showCategory(0);
        
        // Update progress
        updateProgress();
        
    } catch (error) {
        console.error('Error loading positions:', error);
        container.innerHTML = `
            <div class="text-center py-12 text-red-600">
                <i class="fas fa-exclamation-triangle text-4xl mb-4"></i>
                <p class="text-lg font-semibold">Failed to load positions</p>
                <p class="text-sm mt-2">${error.message}</p>
                <button onclick="loadPositionsByCategory(${electionId})" class="mt-4 bg-pink-900 hover:bg-pink-800 text-white px-5 py-2.5 rounded-lg">
                    Try Again
                </button>
            </div>
        `;
    }
}

// Debounce function to prevent multiple rapid API calls
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Debounced version of loadCandidates
const debouncedLoadCandidates = debounce(loadCandidates, 300);

// Add keyboard navigation support
function addKeyboardNavigation() {
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowRight') {
            document.getElementById('next-category')?.click();
        } else if (e.key === 'ArrowLeft') {
            document.getElementById('prev-category')?.click();
        } else if (e.key === 'Enter') {
            const focusedElement = document.activeElement;
            if (focusedElement.classList.contains('candidate-card')) {
                focusedElement.querySelector('.candidate-radio')?.click();
            }
        }
    });
}

// Initialize the page
document.addEventListener('DOMContentLoaded', async () => {
    console.log('Vote page loaded, BASE_URL:', BASE_URL);
    
    // Load high contrast mode preference
    if (localStorage.getItem('highContrastMode') === 'true') {
        document.body.classList.add('high-contrast');
    }
    
    // Add keyboard navigation
    addKeyboardNavigation();
    
    // Add event listeners
    document.getElementById('next-category').addEventListener('click', () => {
        if (currentCategoryIndex < categories.length - 1) {
            showCategory(currentCategoryIndex + 1);
        } else {
            showReviewSection();
        }
    });
    
    document.getElementById('prev-category').addEventListener('click', () => {
        if (currentCategoryIndex > 0) {
            showCategory(currentCategoryIndex - 1);
        }
    });
    
    document.getElementById('confirm-votes').addEventListener('click', submitVote);
    document.getElementById('edit-votes').addEventListener('click', backToVoting);
    document.getElementById('save-progress').addEventListener('click', saveProgress);
    document.getElementById('toggle-contrast').addEventListener('click', toggleHighContrast);
    document.getElementById('toggle-help').addEventListener('click', () => {
        document.getElementById('help-panel').classList.toggle('hidden');
    });
    document.getElementById('share-vote').addEventListener('click', () => {
        document.getElementById('share-modal').classList.remove('hidden');
    });
    document.getElementById('close-share-modal').addEventListener('click', () => {
        document.getElementById('share-modal').classList.add('hidden');
    });
    document.getElementById('share-after-vote').addEventListener('click', () => {
        document.getElementById('success-modal').classList.add('hidden');
        document.getElementById('share-modal').classList.remove('hidden');
    });
    document.getElementById('copy-share-message').addEventListener('click', () => {
        const message = document.getElementById('share-message').textContent;
        navigator.clipboard.writeText(message).then(() => {
            showSuccess('Message copied to clipboard!');
        });
    });
    document.getElementById('close-candidate-modal').addEventListener('click', () => {
        document.getElementById('candidate-modal').classList.add('hidden');
    });
    document.getElementById('close-compare-modal').addEventListener('click', () => {
        document.getElementById('compare-modal').classList.add('hidden');
    });
    
    // Load elections
    try {
        const response = await fetch(`${BASE_URL}/api/voting/elections.php?status=active`);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to fetch elections');
        }
        
        const elections = data.elections || [];
        
        const electionSelect = document.getElementById('election-select');
        electionSelect.innerHTML = '<option value="">Select an election</option>';
        
        if (elections.length === 0) {
            electionSelect.innerHTML = '<option value="">No active elections available</option>';
            return;
        }
        
        elections.forEach(election => {
            const option = document.createElement('option');
            option.value = election.id;
            option.textContent = election.title;
            option.setAttribute('data-description', election.description || '');
            option.setAttribute('data-start-date', election.start_date || '');
            option.setAttribute('data-end-date', election.end_date || '');
            electionSelect.appendChild(option);
        });
        
        electionSelect.addEventListener('change', handleElectionChange);
        
        // If there's only one election, select it automatically
        if (elections.length === 1) {
            electionSelect.value = elections[0].id;
            electionSelect.dispatchEvent(new Event('change'));
        }
    } catch (error) {
        console.error('Error loading elections:', error);
        showError('Failed to load elections. Please try again later.');
        
        // Fallback: try to load without the status parameter
        try {
            const response = await fetch(`${BASE_URL}/api/voting/elections.php`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            
            const data = await response.json();
            
            if (data.success) {
                const elections = data.elections || [];
                const electionSelect = document.getElementById('election-select');
                electionSelect.innerHTML = '<option value="">Select an election</option>';
                
                elections.forEach(election => {
                    const option = document.createElement('option');
                    option.value = election.id;
                    option.textContent = election.title;
                    option.setAttribute('data-description', election.description || '');
                    option.setAttribute('data-start-date', election.start_date || '');
                    option.setAttribute('data-end-date', election.end_date || '');
                    electionSelect.appendChild(option);
                });
                
                electionSelect.addEventListener('change', handleElectionChange);
            }
        } catch (fallbackError) {
            console.error('Fallback error loading elections:', fallbackError);
            showError('Failed to load elections. Please contact support if this issue persists.');
        }
    }
});
</script>
<style>
.category-section {
    transition: all 0.3s ease;
}

.category-section:hover {
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

.position-card {
    transition: all 0.3s ease;
    min-height: 280px;
}

.position-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px -5px rgba(0, 0, 0, 0.1);
}

.candidate-card {
    transition: all 0.2s ease;
}

.candidate-card:hover {
    transform: translateX(4px);
}

/* High contrast mode */
.high-contrast {
    --tw-bg-opacity: 1;
    background-color: rgba(0, 0, 0, var(--tw-bg-opacity)) !important;
    color: white !important;
}

.high-contrast .bg-white {
    background-color: black !important;
    color: white !important;
    border-color: yellow !important;
}

.high-contrast .text-gray-800 {
    color: white !important;
}

.high-contrast .text-gray-600 {
    color: #ccc !important;
}

/* Line clamp utility */
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.line-clamp-3 {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

/* Responsive design */
@media (max-width: 768px) {
    .category-section .grid {
        grid-template-columns: 1fr !important;
    }
    
    .position-card {
        min-height: auto;
    }
    
    #category-navigation-buttons {
        flex-direction: column;
        gap: 1rem;
    }
    
    #category-navigation-buttons button {
        width: 100%;
    }
    
    #category-tabs {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    #category-tabs button {
        width: 100%;
        text-align: left;
    }
    
    .flex.flex-col.lg\:flex-row {
        flex-direction: column;
    }
    
    .lg\:w-1\/4, .lg\:w-3\/4 {
        width: 100%;
    }
}
/* Add to the existing style section */
.loading-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 10;
    border-radius: 0.5rem;
}

.loading-spinner {
    width: 40px;
    height: 40px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid #ec4899;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>
<?php require_once APP_ROOT . '/includes/footer.php'; ?>