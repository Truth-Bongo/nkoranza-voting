<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../helpers/functions.php';
require_once APP_ROOT . '/includes/header.php';

$csrf_token = generate_csrf_token();
?>

<div class="flex items-center justify-center min-h-screen px-4 py-8">
  <div class="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-gray-200 p-8">
    <div class="text-center mb-8">
      <i class="fas fa-user-lock text-4xl text-pink-900 mb-4"></i>
      <h2 class="text-4xl font-extrabold text-pink-900">Voter Login</h2>
      <p class="text-gray-600 mt-2 text-sm">Enter your credentials to access the voting system</p>
    </div>

    <!-- Flash messages -->
    <?php if (isset($_SESSION['flash_message'])): ?>
      <div class="mb-4 p-3 rounded-lg <?= $_SESSION['flash_type'] === 'error' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700' ?>">
        <?= htmlspecialchars($_SESSION['flash_message']) ?>
        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
      </div>
    <?php endif; ?>

    <form id="login-form" class="space-y-6">
      <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

      <div>
        <label for="username" class="block text-sm font-medium text-gray-700">User ID</label>
        <input type="text" id="username" name="username"
               class="mt-1 w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-pink-500"
               required>
      </div>

      <div>
        <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
        <input type="password" id="password" name="password"
               class="mt-1 w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-pink-500"
               required>
      </div>

      <div id="login-error" class="hidden text-red-600 text-sm text-center"></div>

      <div>
        <button type="submit"
                class="w-full bg-pink-900 hover:bg-pink-800 text-white font-semibold py-3 rounded-xl transition-all shadow-lg">
          Login
        </button>
      </div>

      <p class="text-center text-xs text-gray-500 mt-4">
        Forgot your password? Contact the electoral committee.
      </p>
    </form>
  </div>
</div>

<script>
document.getElementById('login-form').addEventListener('submit', async function (e) {
  e.preventDefault();

  const formData = new FormData(this);
  const payload = {};
  formData.forEach((value, key) => payload[key] = value);

  try {
    const res = await fetch(BASE_URL + '/api/auth/login.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    if (!res.ok || !data.success) {
      // Show error inline instead of alert
      const errorBox = document.getElementById('login-error');
      errorBox.textContent = data.message || 'Login failed';
      errorBox.classList.remove('hidden');
      return;
    }

    // ✅ Store CSRF token if provided
    if (data.csrf_token) {
      sessionStorage.setItem('csrf_token', data.csrf_token);
    }

    // ✅ Force a full page reload to update session state
    // This ensures the header and all session-dependent elements are updated
    if (data.isAdmin) {
      window.location.href = BASE_URL + '/index.php?page=admin/dashboard';
    } else {
      window.location.href = BASE_URL + '/index.php?page=vote';
    }
  } catch (err) {
    console.error(err);
    const errorBox = document.getElementById('login-error');
    errorBox.textContent = 'Network error. Please try again.';
    errorBox.classList.remove('hidden');
  }
});
</script>
<?php require_once APP_ROOT . '/includes/footer.php'; ?>