<?php
require_once APP_ROOT . '/config/db_connect.php';
require_once APP_ROOT . '/includes/header.php';

$db = Database::getInstance()->getConnection();

// Simple query to get upcoming elections (start date in the future)
$upcoming_elections = $db->query("
    SELECT * FROM elections 
    WHERE start_date > NOW() 
    ORDER BY start_date ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="max-w-4xl mx-auto">
  <div class="text-center mb-8">
    <h2 class="text-3xl font-bold text-gray-900 mb-4">Welcome to Nkoranza SHTs E-Voting System</h2>
    <p class="text-gray-600 mb-6">Cast your vote securely and conveniently for your school elections</p>
    <div class="flex justify-center gap-4">
      <?php if (isset($_SESSION['user_id'])): ?>
        <!-- FIXED: Use proper URL format for your routing system -->
        <a href="<?= BASE_URL ?>/?page=vote" class="bg-gray-900 hover:bg-gray-800 text-white px-6 py-2 rounded-lg transition">Vote Now</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/?page=login" class="bg-gray-900 hover:bg-gray-800 text-white px-6 py-2 rounded-lg transition">Login to Vote</a>
      <?php endif; ?>
      <a href="<?= BASE_URL ?>/?page=results" class="bg-pink-900 hover:bg-pink-800 text-white px-6 py-2 rounded-lg transition">View Results</a>
    </div>
  </div>

  <div class="grid md:grid-cols-3 gap-6 mb-12">
    <div class="bg-white p-6 rounded-lg shadow-md">
      <div class="text-pink-900 mb-4 text-2xl">
        <i class="fas fa-user-shield"></i>
      </div>
      <h3 class="font-bold text-lg mb-2">Secure Voting</h3>
      <p class="text-gray-600">Our system uses advanced encryption to ensure your vote remains anonymous and secure.</p>
    </div>
    <div class="bg-white p-6 rounded-lg shadow-md">
      <div class="text-pink-900 mb-4 text-2xl">
        <i class="fas fa-bolt"></i>
      </div>
      <h3 class="font-bold text-lg mb-2">Fast Results</h3>
      <p class="text-gray-600">Get real-time election results as soon as voting ends, eliminating long waits.</p>
    </div>
    <div class="bg-white p-6 rounded-lg shadow-md">
      <div class="text-pink-900 mb-4 text-2xl">
        <i class="fas fa-mobile-alt"></i>
      </div>
      <h3 class="font-bold text-lg mb-2">Mobile Friendly</h3>
      <p class="text-gray-600">Vote from any device, whether you're using a computer, tablet, or smartphone.</p>
    </div>
  </div>

  <div class="mt-12 bg-white p-6 rounded-lg shadow-md">
    <h3 class="font-bold text-xl mb-4 text-center">Upcoming Elections</h3>
    <div class="overflow-x-auto">
      <?php if (empty($upcoming_elections)): ?>
        <p class="text-center text-gray-500 py-4">No upcoming elections at the moment.</p>
      <?php else: ?>
        <table class="min-w-full bg-white">
          <thead class="bg-gray-100">
            <tr>
              <th class="py-2 px-4 border-b">Title</th>
              <th class="py-2 px-4 border-b">Start Date</th>
              <th class="py-2 px-4 border-b">End Date</th>
              <th class="py-2 px-4 border-b">Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($upcoming_elections as $election): ?>
              <tr>
                <td class="py-2 px-4 border-b text-center"><?= htmlspecialchars($election['title']) ?></td>
                <td class="py-2 px-4 border-b text-center"><?= date('M j, Y', strtotime($election['start_date'])) ?></td>
                <td class="py-2 px-4 border-b text-center"><?= date('M j, Y', strtotime($election['end_date'])) ?></td>
                <td class="py-2 px-4 border-b text-center">
                  <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                    Upcoming
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once APP_ROOT . '/includes/footer.php'; ?>