<!-- In views/partials/session_expired.php -->
<div id="session-expired-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
  <div class="bg-white p-6 rounded-lg max-w-md w-full">
    <div class="text-center">
      <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
        <i class="fas fa-exclamation-triangle text-red-600"></i>
      </div>
      <h3 class="mt-3 text-lg font-medium text-gray-900">Session Expired</h3>
      <div class="mt-2 text-sm text-gray-500">
        <p>Your session has expired due to inactivity.</p>
      </div>
      <div class="mt-4">
        <a href="<?= BASE_URL ?>/login" class="btn btn-primary">
          Return to Login
        </a>
      </div>
    </div>
  </div>
</div>