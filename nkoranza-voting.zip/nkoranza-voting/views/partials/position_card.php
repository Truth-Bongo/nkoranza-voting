<?php
/**
 * Position Card Partial
 * @param array $position - Position data with keys: id, title, election_id, candidates
 */
if (!isset($position)) return;
?>

<div class="position-card bg-white rounded-lg shadow-md overflow-hidden">
  <div class="p-6">
    <h3 class="text-xl font-bold text-gray-900 mb-4">
      <?= htmlspecialchars($position['title']) ?>
    </h3>

    <?php if (!empty($position['candidates'])): ?>
      <div class="space-y-4">
        <?php foreach ($position['candidates'] as $candidate): ?>
          <div class="candidate-item flex items-center gap-4 p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
            <?php if (!empty($candidate['image_url'])): ?>
              <img src="<?= htmlspecialchars($candidate['image_url']) ?>" 
                   alt="<?= htmlspecialchars($candidate['name']) ?>"
                   class="w-12 h-12 rounded-full object-cover">
            <?php else: ?>
              <div class="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                <i class="fas fa-user text-gray-500"></i>
              </div>
            <?php endif; ?>

            <div class="flex-1">
              <h4 class="font-medium"><?= htmlspecialchars($candidate['name']) ?></h4>
              <p class="text-sm text-gray-500">
                <?= htmlspecialchars($candidate['department'] ?? '') ?>
              </p>
            </div>

            <?php if (isset($_SESSION['user_id'])): ?>
              <button class="vote-btn btn btn-primary px-4 py-2 text-sm"
                      data-position="<?= $position['id'] ?>"
                      data-candidate="<?= $candidate['id'] ?>">
                Vote
              </button>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="text-gray-500 text-center py-4">No candidates registered</p>
    <?php endif; ?>
  </div>
</div>