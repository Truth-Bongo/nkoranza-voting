<?php
/**
 * Election Card Partial
 * @param array $election - Election data with keys: id, title, start_date, end_date, status
 */
if (!isset($election)) return;
?>

<div class="election-card bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition duration-200">
  <div class="p-6">
    <div class="flex justify-between items-start">
      <h3 class="text-lg font-bold text-gray-900 truncate">
        <?= htmlspecialchars($election['title']) ?>
      </h3>
      <span class="px-2 py-1 text-xs rounded-full 
        <?= match($election['status']) {
          'active' => 'bg-green-100 text-green-800',
          'upcoming' => 'bg-yellow-100 text-yellow-800',
          'ended' => 'bg-gray-100 text-gray-800',
          default => 'bg-blue-100 text-blue-800'
        } ?>">
        <?= ucfirst($election['status']) ?>
      </span>
    </div>

    <div class="mt-4 grid grid-cols-2 gap-4">
      <div>
        <p class="text-sm text-gray-500">Start Date</p>
        <p class="font-medium">
          <?= date('M j, Y', strtotime($election['start_date'])) ?>
        </p>
      </div>
      <div>
        <p class="text-sm text-gray-500">End Date</p>
        <p class="font-medium">
          <?= date('M j, Y', strtotime($election['end_date'])) ?>
        </p>
      </div>
    </div>

    <div class="mt-6 pt-4 border-t border-gray-200">
      <?php if ($election['status'] === 'active'): ?>
        <a href="<?= BASE_URL ?>/vote?election=<?= $election['id'] ?>" 
           class="btn btn-primary w-full">
          Vote Now
        </a>
      <?php elseif ($election['status'] === 'upcoming'): ?>
        <button class="btn btn-secondary w-full" disabled>
          Voting Starts Soon
        </button>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/results?election=<?= $election['id'] ?>" 
           class="btn btn-accent w-full">
          View Results
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>