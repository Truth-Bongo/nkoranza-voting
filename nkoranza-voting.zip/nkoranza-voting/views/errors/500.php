<?php require_once APP_ROOT . '/includes/header.php'; ?>

<div class="max-w-4xl mx-auto text-center py-16">
  <h1 class="text-9xl font-bold text-pink-900 mb-4">500</h1>
  <h2 class="text-3xl font-bold text-gray-900 mb-4">Server Error</h2>
  <p class="text-gray-600 mb-8">Something went wrong on our end. Please try again later.</p>
  <a href="<?= BASE_URL ?>" class="btn btn-primary px-8 py-3">
    Return to Home
  </a>
</div>

<?php require_once APP_ROOT . '/includes/footer.php'; ?>