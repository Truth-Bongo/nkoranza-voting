<?php 
require_once __DIR__ . '/../includes/header.php';

// Check if election is active
$now = new DateTime();
$start = new DateTime($election['start_date']);
$end = new DateTime($election['end_date']);

$isActive = ($now >= $start && $now <= $end);

// Check if user has already voted in this election
$hasVoted = false;
try {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare('SELECT id FROM votes WHERE user_id = ? AND election_id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id'], $election['id']]);
    $hasVoted = (bool)$stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Log error but continue
    error_log("Error checking vote status: " . $e->getMessage());
}
?>

<div class="max-w-6xl mx-auto">
    <div class="flex items-center mb-6">
        <a href="/vote" class="text-pink-900 hover:text-pink-700 mr-4">
            <i class="fas fa-arrow-left"></i> Back to Elections
        </a>
        <h2 class="text-2xl font-bold"><?= htmlspecialchars($election['title']) ?> Candidates</h2>
        
        <!-- Election status badge -->
        <span class="ml-4 px-3 py-1 rounded-full text-xs font-medium 
            <?= $isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' ?>">
            <?= $isActive ? 'Active' : 'Ended' ?>
        </span>
    </div>
    
    <?php if (!$isActive): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6">
            <p>This election has <?= ($now < $start) ? 'not started yet' : 'ended' ?>. 
               <?php if ($now < $start): ?>
                 It will begin on <?= date('M j, Y', strtotime($election['start_date'])) ?>.
               <?php else: ?>
                 It ended on <?= date('M j, Y', strtotime($election['end_date'])) ?>.
               <?php endif; ?>
            </p>
        </div>
    <?php elseif ($hasVoted): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6">
            <p>You have already voted in this election. Thank you for participating!</p>
        </div>
    <?php endif; ?>
    
    <?php if (empty($candidates)): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6">
            <p>No candidates found for this election.</p>
        </div>
    <?php else: ?>
        <div class="grid md:grid-cols-2 gap-6" id="candidates-container">
            <?php foreach ($candidates as $candidate): ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="p-6">
                        <div class="flex items-center mb-4">
                            <img src="<?= htmlspecialchars($candidate['photo'] ?? '/assets/images/default-user.jpg') ?>" 
                                 alt="<?= htmlspecialchars($candidate['name']) ?>" 
                                 class="w-16 h-16 rounded-full object-cover mr-4">
                            <div>
                                <h3 class="text-lg font-bold"><?= htmlspecialchars($candidate['name']) ?></h3>
                                <p class="text-gray-600"><?= htmlspecialchars($candidate['department']) ?></p>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h4 class="font-semibold text-pink-900">Position:</h4>
                            <p><?= htmlspecialchars($candidate['position']) ?></p>
                        </div>
                        
                        <?php if (!empty($candidate['manifesto'])): ?>
                            <div class="mb-4">
                                <h4 class="font-semibold text-pink-900">Manifesto:</h4>
                                <p><?= nl2br(htmlspecialchars($candidate['manifesto'])) ?></p>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($isActive && !$hasVoted): ?>
                            <button class="w-full bg-pink-900 hover:bg-pink-700 text-white py-2 px-4 rounded transition vote-btn"
                                    data-candidate-id="<?= $candidate['id'] ?>"
                                    data-election-id="<?= $election['id'] ?>">
                                Vote for <?= htmlspecialchars(explode(' ', $candidate['name'])[0]) ?>
                            </button>
                        <?php elseif ($isActive && $hasVoted): ?>
                            <button class="w-full bg-gray-400 text-white py-2 px-4 rounded cursor-not-allowed" disabled>
                                Already Voted
                            </button>
                        <?php else: ?>
                            <button class="w-full bg-gray-400 text-white py-2 px-4 rounded cursor-not-allowed" disabled>
                                Election <?= ($now < $start) ? 'Not Started' : 'Ended' ?>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once APP_ROOT . '/includes/footer.php'; ?>