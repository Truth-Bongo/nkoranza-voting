<?php
require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/config/db_connect.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

class ResultsServer implements MessageComponentInterface {
    protected $clients;
    protected $electionData;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->electionData = [];
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        
        if ($data['action'] === 'subscribe') {
            $electionId = $data['electionId'];
            $this->electionData[$from->resourceId] = $electionId;
            $this->sendInitialData($from, $electionId);
        }
    }

    public function onClose(ConnectionInterface $conn) {
        unset($this->electionData[$conn->resourceId]);
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    protected function sendInitialData($conn, $electionId) {
        $db = Database::getInstance()->getConnection();
        
        try {
            $stmt = $db->prepare("
                SELECT p.name as position_name, 
                       c.id as candidate_id,
                       u.first_name, u.last_name,
                       COUNT(v.id) as votes
                FROM positions p
                JOIN candidates c ON p.id = c.position_id
                JOIN users u ON c.user_id = u.id
                LEFT JOIN votes v ON c.id = v.candidate_id
                WHERE p.election_id = ?
                GROUP BY p.id, c.id, u.first_name, u.last_name
                ORDER BY p.name, votes DESC
            ");
            $stmt->execute([$electionId]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $conn->send(json_encode([
                'type' => 'initial',
                'data' => $results
            ]));
        } catch (PDOException $e) {
            $conn->send(json_encode([
                'type' => 'error',
                'message' => 'Failed to load initial data'
            ]));
        }
    }

    public function broadcastUpdate($electionId, $voteData) {
        foreach ($this->clients as $client) {
            if (isset($this->electionData[$client->resourceId]) && 
                $this->electionData[$client->resourceId] === $electionId) {
                $client->send(json_encode([
                    'type' => 'update',
                    'data' => $voteData
                ]));
            }
        }
    }
}

// Run the server
$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new ResultsServer()
        )
    ),
    8080
);

echo "WebSocket server running on port 8080\n";
$server->run();

