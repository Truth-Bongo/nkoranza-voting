<?php
// api/admin/import_voters.php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/db_connect.php';
require_once __DIR__ . '/../../helpers/functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();

if (empty($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) json_response(['success'=>false,'message'=>'Forbidden'], 403);

// Get CSRF token from form data instead of headers
$reqToken = $_POST['csrf_token'] ?? '';
if (!validate_csrf_token($reqToken)) json_response(['success'=>false,'message'=>'Invalid CSRF token'], 403);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['success'=>false,'message'=>'Method not allowed'], 405);
if (empty($_FILES['voter_file']) || $_FILES['voter_file']['error'] !== UPLOAD_ERR_OK) json_response(['success'=>false,'message'=>'No file uploaded'], 400);

$path = $_FILES['voter_file']['tmp_name'];
$handle = fopen($path, 'r');
if (!$handle) json_response(['success'=>false,'message'=>'Cannot open file'], 500);

$db = Database::getInstance()->getConnection();
$inserted = 0; $skipped = 0;
$failed = []; // Track failed rows for better error reporting

// Skip header row if exists
$firstRow = fgetcsv($handle);
if ($firstRow !== false && is_string($firstRow[0]) && !is_numeric($firstRow[0])) {
    // Likely a header row, skip it
} else {
    // Rewind to beginning if no header
    rewind($handle);
}

while (($row = fgetcsv($handle)) !== false) {
    // Expected: Student ID, Password, First Name, Last Name, Department, Level, Email
    if (count($row) < 6) { 
        $skipped++; 
        $failed[] = 'Row with insufficient data: ' . implode(',', $row);
        continue; 
    }
    
    [$id,$password,$first,$last,$dept,$level,$email] = array_map('trim', array_pad($row,7,null));
    if (!$id || !$password || !$first || !$last) { 
        $skipped++; 
        $failed[] = 'Row with missing required fields: ' . implode(',', $row);
        continue; 
    }

    // avoid duplicates
    $exists = $db->prepare("SELECT 1 FROM users WHERE id = ? LIMIT 1");
    $exists->execute([$id]);
    if ($exists->fetch()) { 
        $skipped++; 
        $failed[] = "Duplicate student ID: $id";
        continue; 
    }

    $hashed = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $db->prepare("INSERT INTO users (id,password,first_name,last_name,department,level,email) VALUES (?,?,?,?,?,?,?)");
    
    try {
        $stmt->execute([$id,$hashed,$first,$last,$dept,intval($level),$email]);
        $inserted++;
    } catch (Exception $e) {
        $skipped++;
        $failed[] = "Error inserting $id: " . $e->getMessage();
    }
}
fclose($handle);
json_response(['success'=>true,'inserted'=>$inserted,'skipped'=>$skipped,'failed'=>$failed,'message'=>"Imported: $inserted, skipped: $skipped"]);