<?php
// api/admin/voters.php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/db_connect.php';
require_once __DIR__ . '/../../helpers/functions.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Set JSON header first
header('Content-Type: application/json');

// Validate admin authentication
function validateAdmin() {
    if (empty($_SESSION['is_admin'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
        exit;
    }
}

// CSRF validation
function validateCsrf() {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
            exit;
        }
    }
}

// Input validation and sanitization
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function validateVoterId($id) {
    return preg_match('/^[A-Za-z0-9]{3,20}$/', $id);
}

function validateName($name) {
    return preg_match('/^[A-Za-z\s\-\']{2,50}$/', $name);
}

// Get JSON input for PUT/DELETE requests
function getJsonInput() {
    $input = file_get_contents('php://input');
    return json_decode($input, true);
}

try {
    validateAdmin();
    $db = Database::getInstance()->getConnection();

    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            validateCsrf();
            
            // Get all voters
            $stmt = $db->query("SELECT id, first_name, last_name, department, level, email, has_voted 
                                FROM users 
                                WHERE is_admin = 0
                                ORDER BY id ASC");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'data' => $rows]);
            break;

        case 'POST':
            validateCsrf();
            
            $input = sanitizeInput($_POST);
            $id = $input['id'] ?? '';
            $first = $input['first_name'] ?? '';
            $last = $input['last_name'] ?? '';
            $dept = $input['department'] ?? '';
            $level = $input['level'] ?? '';
            $email = $input['email'] ?? '';
            $password = $input['password'] ?? '';
            $isEdit = ($input['is_edit'] ?? 'false') === 'true';

            // Validate required fields
            if (!$id || !$first || !$last || !$email) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Missing required fields']);
                exit;
            }

            $db->beginTransaction();

            try {
                if ($isEdit) {
                    // Update voter
                    $sql = "UPDATE users SET first_name = :first, last_name = :last, 
                            department = :dept, level = :level, email = :email";
                    $params = [
                        ':first' => $first,
                        ':last' => $last,
                        ':dept' => $dept,
                        ':level' => $level,
                        ':email' => $email,
                        ':id' => $id
                    ];

                    if (!empty($password)) {
                        $sql .= ", password = :password";
                        $params[':password'] = password_hash($password, PASSWORD_BCRYPT);
                    }

                    $sql .= " WHERE id = :id AND is_admin = 0";

                    $stmt = $db->prepare($sql);
                    $stmt->execute($params);

                    $message = 'Voter updated successfully';
                } else {
                    // Insert new voter
                    $stmt = $db->prepare("INSERT INTO users 
                        (id, first_name, last_name, department, level, email, password, has_voted, is_admin) 
                        VALUES (:id, :first, :last, :dept, :level, :email, :password, 0, 0)");
                    
                    $password = !empty($password) ? $password : 'password123'; // Default password
                    
                    $stmt->execute([
                        ':id' => $id,
                        ':first' => $first,
                        ':last' => $last,
                        ':dept' => $dept,
                        ':level' => $level,
                        ':email' => $email,
                        ':password' => password_hash($password, PASSWORD_BCRYPT),
                    ]);

                    $message = 'Voter added successfully';
                }

                $db->commit();
                echo json_encode(['success' => true, 'message' => $message]);

            } catch (Exception $e) {
                $db->rollBack();
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;

        case 'DELETE':
            validateCsrf();
            
            // Get voter ID from query parameters
            $id = $_GET['id'] ?? '';
            
            if (!$id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Missing voter ID']);
                exit;
            }

            try {
                // Delete voter
                $stmt = $db->prepare("DELETE FROM users WHERE id = :id AND is_admin = 0");
                $stmt->execute([':id' => $id]);

                if ($stmt->rowCount() === 0) {
                    throw new Exception('Voter not found or already deleted');
                }

                echo json_encode(['success' => true, 'message' => 'Voter deleted successfully']);

            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    error_log("Voters API Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Internal server error']);
}
?>