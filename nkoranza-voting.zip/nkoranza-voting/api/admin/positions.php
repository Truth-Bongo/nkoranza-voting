<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config/db_connect.php';

function jsend($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
} catch (Exception $e) {
    jsend(['success'=>false,'message'=>'Database connection failed'],500);
}

$method = $_SERVER['REQUEST_METHOD'];

// --- CSRF for non-GET
if ($method !== 'GET') {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $token = $headers['X-CSRF-Token'] ?? $_REQUEST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || !$token || !hash_equals($_SESSION['csrf_token'], $token)) {
        jsend(['success'=>false,'message'=>'Invalid CSRF token'],403);
    }
}

// --- GET (students + admins)
$id = $_GET['id'] ?? null;
if ($method === 'GET') {
    try {
        if ($id) {
            $stmt = $db->prepare("
                SELECT p.*, e.title AS election_title, e.start_date, e.end_date
                FROM positions p
                JOIN elections e ON p.election_id = e.id
                WHERE p.id = ?
            ");
            $stmt->execute([$id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) jsend(['success'=>false,'message'=>'Not found'],404);
            jsend(['success'=>true,'position'=>$row]);
        } else {
            $electionId = $_GET['election_id'] ?? null;

            $sql = "
                SELECT p.*, e.title AS election_title, e.start_date, e.end_date
                FROM positions p
                JOIN elections e ON p.election_id = e.id
                WHERE 1=1
            ";
            $params = [];

            if ($electionId) {
                $sql .= " AND p.election_id = ?";
                $params[] = $electionId;
            }

            $sql .= " ORDER BY p.name ASC";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            jsend(['success'=>true,'positions'=>$rows]);
        }
    } catch (Exception $e) {
        jsend(['success'=>false,'message'=>'Database error: '.$e->getMessage()],500);
    }
}

// --- Admin guard for POST/PUT/DELETE
if (empty($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    jsend(['success'=>false,'message'=>'Forbidden: admin only'],403);
}

// helper for JSON input
function get_json_input() {
    $raw = file_get_contents('php://input');
    $arr = json_decode($raw, true);
    return is_array($arr) ? $arr : null;
}

// PUT/PATCH: update
if ($method === 'PUT' || $method === 'PATCH') {
    if (!$id) jsend(['success'=>false,'message'=>'Missing id'],400);

    $input = get_json_input();
    if (!is_array($input)) parse_str(file_get_contents('php://input'), $input);

    $fields = []; $params = [':id'=>$id];
    if (isset($input['name'])) { $fields[] = "name = :name"; $params[':name'] = trim($input['name']); }
    if (isset($input['max_votes'])) { $fields[] = "max_votes = :mv"; $params[':mv'] = intval($input['max_votes']); }
    if (isset($input['election_id'])) { $fields[] = "election_id = :eid"; $params[':eid'] = intval($input['election_id']); }

    if (empty($fields)) jsend(['success'=>false,'message'=>'No fields to update'],400);

    try {
        $sql = "UPDATE positions SET " . implode(", ", $fields) . " WHERE id = :id";
        $stmt = $db->prepare($sql);
        $ok = $stmt->execute($params);
        jsend(['success'=>$ok,'message'=>$ok?'Position updated':'Failed to update position']);
    } catch (Exception $e) {
        jsend(['success'=>false,'message'=>'Database error'],500);
    }
}

// DELETE
if ($method === 'DELETE') {
    if (!$id) jsend(['success'=>false,'message'=>'Missing id'],400);
    try {
        $stmt = $db->prepare("DELETE FROM positions WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->rowCount() === 0) jsend(['success'=>false,'message'=>'Not found'],404);
        jsend(['success'=>true,'message'=>'Position deleted']);
    } catch (Exception $e) {
        jsend(['success'=>false,'message'=>'Database error'],500);
    }
}

jsend(['success'=>false,'message'=>'Method not allowed'],405);
