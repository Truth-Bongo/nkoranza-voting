<?php
if (session_status() === PHP_SESSION_NONE) session_start();

// Enable error logging for debugging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../../logs/php_errors.log');

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config/bootstrap.php';

try {
    $db = Database::getInstance()->getConnection();
} catch (Throwable $e) {
    error_log('DB connection failed: ' . $e->getMessage());
    echo json_encode(['success'=>false,'message'=>'DB connection failed']); 
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

// CSRF for non-GET
if ($method !== 'GET') {
    // Improved CSRF token retrieval
    $token = '';
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        $token = $headers['X-CSRF-Token'] ?? '';
    } else {
        foreach ($_SERVER as $name => $value) {
            if (strtoupper($name) === 'HTTP_X_CSRF_TOKEN') {
                $token = $value;
                break;
            }
        }
    }
    // Also check POST data as fallback
    if (empty($token)) {
        $token = $_POST['csrf_token'] ?? '';
    }
    
    if (empty($_SESSION['csrf_token']) || !$token || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        echo json_encode(['success'=>false,'message'=>'Invalid CSRF token']); 
        exit;
    }
}

// ADMIN guard (adjust condition to your auth)
if ($method !== 'GET') {
    if (empty($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
        http_response_code(403);
        echo json_encode(['success'=>false,'message'=>'Forbidden: admin only']); 
        exit;
    }
}

try {
    if ($method === 'GET') {
        $stmt = $db->query("
            SELECT 
                c.id, c.user_id, c.election_id, c.position_id, c.manifesto, c.photo_path,
                u.first_name, u.last_name, u.department,
                e.title AS election_title,
                p.name  AS position_name
            FROM candidates c
            JOIN users u ON u.id = c.user_id
            JOIN elections e ON e.id = c.election_id
            JOIN positions p ON p.id = c.position_id
            ORDER BY c.id DESC
        ");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success'=>true, 'data'=>$rows]); 
        exit;
    }

    if ($method === 'POST') {
        $userId = !empty($_POST['user_id']) ? $_POST['user_id'] : null;
        $electionId = !empty($_POST['election_id']) ? (int)$_POST['election_id'] : null;
        $positionId = !empty($_POST['position_id']) ? (int)$_POST['position_id'] : null;
        $manifesto  = $_POST['manifesto'] ?? null;
        $candidateId= !empty($_POST['id'])          ? (int)$_POST['id']          : null;

        if ($userId === null || $electionId === null || $positionId === null) {
            http_response_code(400);
            echo json_encode([
                'success'=>false,
                'message'=>"Missing required fields. Got: " .
                        "user_id=" . ($_POST['user_id'] ?? 'null') . ", " .
                        "election_id=" . ($_POST['election_id'] ?? 'null') . ", " .
                        "position_id=" . ($_POST['position_id'] ?? 'null')
            ]);
            exit;
        }

        // Validate that user exists
        $userCheck = $db->prepare("SELECT id FROM users WHERE id = ?");
        $userCheck->execute([$userId]);
        $userExists = $userCheck->fetch(PDO::FETCH_ASSOC);

        if (!$userExists) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => "User with ID $userId does not exist"
            ]);
            exit;
        }

        // Validate that election exists
        $electionCheck = $db->prepare("SELECT id FROM elections WHERE id = ?");
        $electionCheck->execute([$electionId]);
        $electionExists = $electionCheck->fetch(PDO::FETCH_ASSOC);

        if (!$electionExists) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => "Election with ID $electionId does not exist"
            ]);
            exit;
        }

        // Validate that position exists
        $positionCheck = $db->prepare("SELECT id FROM positions WHERE id = ?");
        $positionCheck->execute([$positionId]);
        $positionExists = $positionCheck->fetch(PDO::FETCH_ASSOC);

        if (!$positionExists) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => "Position with ID $positionId does not exist"
            ]);
            exit;
        }

        // upload
        $photoPath = null;
        if (!empty($_FILES['photo']['name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = __DIR__ . '/../../uploads/candidates/';
            if (!is_dir($uploadDir)) {
                if (!mkdir($uploadDir, 0775, true)) {
                    error_log("Failed to create directory: $uploadDir");
                    http_response_code(500);
                    echo json_encode(['success'=>false,'message'=>'Failed to create upload directory']);
                    exit;
                }
            }
            
            // Validate file type
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
            $fileType = finfo_file($fileInfo, $_FILES['photo']['tmp_name']);
            finfo_close($fileInfo);
            
            if (!in_array($fileType, $allowedTypes)) {
                echo json_encode(['success'=>false,'message'=>'Invalid file type. Only JPEG, PNG, GIF and WebP are allowed']);
                exit;
            }
            
            $filename = uniqid('', true) . '_' . preg_replace('/[^A-Za-z0-9_.-]/', '_', basename($_FILES['photo']['name']));
            $target = $uploadDir . $filename;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $target)) {
                $photoPath = 'uploads/candidates/' . $filename;
            } else {
                error_log("Failed to move uploaded file to: $target");
            }
        }

        if ($candidateId) {
            $sql = "UPDATE candidates
                    SET user_id=:uid, election_id=:eid, position_id=:pid, manifesto=:man";
            $params = [':uid'=>$userId, ':eid'=>$electionId, ':pid'=>$positionId, ':man'=>$manifesto, ':id'=>$candidateId];
            if ($photoPath) { 
                $sql .= ", photo_path=:photo"; 
                $params[':photo'] = $photoPath; 
            }
            $sql .= " WHERE id=:id";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            echo json_encode(['success'=>true, 'message'=>'Candidate updated']); 
            exit;
        } else {
            $stmt = $db->prepare("
                INSERT INTO candidates (user_id, election_id, position_id, manifesto, photo_path)
                VALUES (:uid, :eid, :pid, :man, :photo)
            ");
            $stmt->execute([
                ':uid'=>$userId, ':eid'=>$electionId, ':pid'=>$positionId,
                ':man'=>$manifesto, ':photo'=>$photoPath
            ]);
            echo json_encode(['success'=>true, 'message'=>'Candidate added']); 
            exit;
        }
    }

    if ($method === 'DELETE') {
        parse_str(file_get_contents('php://input'), $vars);
        $id = $_GET['id'] ?? $vars['id'] ?? null;
        if (!$id) { 
            http_response_code(400); 
            echo json_encode(['success'=>false,'message'=>'Missing candidate id']); 
            exit; 
        }
        
        // First get the photo path to delete the file
        $stmt = $db->prepare("SELECT photo_path FROM candidates WHERE id = ?");
        $stmt->execute([(int)$id]);
        $candidate = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($candidate && !empty($candidate['photo_path'])) {
            $filePath = __DIR__ . '/../../' . $candidate['photo_path'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }
        
        $stmt = $db->prepare("DELETE FROM candidates WHERE id = ?");
        $stmt->execute([(int)$id]);
        
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success'=>true,'message'=>'Candidate deleted']);
        } else { 
            http_response_code(404); 
            echo json_encode(['success'=>false,'message'=>'Candidate not found']); 
        }
        exit;
    }

    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'Method not allowed']);
} catch (Throwable $e) {
    error_log('Candidate API Error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Server error: ' . $e->getMessage()]); 
}