<?php
// api/admin/elections.php
// CRUD for elections with duplicate-check, status-auto-update, CSRF + admin guard

if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json; charset=utf-8');

// Set timezone to Africa/Accra (Ghana)
date_default_timezone_set('Africa/Accra');

// load constants if not present
if (!defined('APP_ROOT')) {
    $maybe = __DIR__ . '/../../config/constants.php';
    if (file_exists($maybe)) require_once $maybe;
}

require_once __DIR__ . '/../../config/db_connect.php';

// small JSON helper
function jsend($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
} catch (Exception $e) {
    jsend(['success' => false, 'message' => 'Database connection failed'], 500);
}

// Admin-only guard
if (empty($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    jsend(['success' => false, 'message' => 'Forbidden: admin only'], 403);
}

// --- Method normalization (support POST override) ---
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'POST' && isset($_POST['_method'])) {
    $override = strtoupper(trim($_POST['_method']));
    if (in_array($override, ['PUT','PATCH','DELETE'], true)) {
        $method = $override;
    }
}

// CSRF validation for state-changing methods
function csrf_from_request() {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $token = $headers['X-CSRF-Token'] ?? $headers['X-Csrf-Token'] ?? '';
    if (!$token) {
        if (isset($_REQUEST['csrf_token'])) $token = $_REQUEST['csrf_token'];
        if (!$token && isset($_POST['csrf_token'])) $token = $_POST['csrf_token'];
    }
    return $token;
}
if ($method !== 'GET') {
    $token = csrf_from_request();
    if (empty($_SESSION['csrf_token']) || !$token || !hash_equals($_SESSION['csrf_token'], $token)) {
        jsend(['success' => false, 'message' => 'Invalid CSRF token'], 403);
    }
}

// auto-update statuses from dates (idempotent)
try {
    $now = (new DateTime())->format('Y-m-d H:i:s');
    $sql = "UPDATE elections SET status =
        CASE
            WHEN :now < start_date THEN 'upcoming'
            WHEN :now <= end_date THEN 'active'
            ELSE 'ended'
        END";
    $stmt = $db->prepare($sql);
    $stmt->execute([':now' => $now]);
} catch (Exception $e) {
    // non-fatal
}

// helper to parse JSON body
function get_json_input() {
    $raw = file_get_contents('php://input');
    $arr = json_decode($raw, true);
    return is_array($arr) ? $arr : null;
}
function normalize_datetime($v) {
    if (!$v) return null;
    $v = str_replace('T', ' ', $v);
    try {
        $dt = new DateTime($v, new DateTimeZone('Africa/Accra'));
        return $dt->format('Y-m-d H:i:s');
    } catch (Exception $e) {
        return null;
    }
}

// routing
$id = $_GET['id'] ?? null;

if ($method === 'GET') {
    try {
        if ($id) {
            $stmt = $db->prepare("SELECT * FROM elections WHERE id = ? LIMIT 1");
            $stmt->execute([$id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) jsend(['success'=>false,'message'=>'Not found'],404);
            jsend(['success'=>true,'election'=>$row]);
        } else {
            $stmt = $db->query("SELECT * FROM elections ORDER BY start_date DESC, id DESC");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            jsend(['success'=>true,'elections'=>$rows]);
        }
    } catch (Exception $e) {
        jsend(['success'=>false,'message'=>'Database error'],500);
    }
}

/**
 * POST: Create OR Update (when id present)
 * - Works with FormData (so CSRF lives in $_POST)
 * - Matches your frontend which posts to ?id=... for edits
 */
if ($method === 'POST') {
    // Prefer form fields; if JSON, merge
    $input = $_POST;
    if (!$input) {
        $json = get_json_input();
        if (is_array($json)) $input = $json;
    }

    // Determine if this is an update
    $postId = $input['id'] ?? null;
    if (!$id && $postId) $id = $postId;

    $title = isset($input['title']) ? trim($input['title']) : '';
    $description = isset($input['description']) ? trim($input['description']) : '';
    $start_raw = $input['start_date'] ?? ($input['start'] ?? '');
    $end_raw   = $input['end_date']   ?? ($input['end']   ?? '');

    if ($id) {
        // ----- UPDATE -----
        $fields = []; $params = [':id'=>$id];

        if ($title !== '') { $fields[] = "title = :title"; $params[':title'] = $title; }
        if ($description !== '') { $fields[] = "description = :desc"; $params[':desc'] = $description; }
        if ($start_raw !== '') {
            $start = normalize_datetime($start_raw);
            if (!$start) jsend(['success'=>false,'message'=>'Invalid start_date'],400);
            $fields[] = "start_date = :start"; $params[':start'] = $start;
        }
        if ($end_raw !== '') {
            $end = normalize_datetime($end_raw);
            if (!$end) jsend(['success'=>false,'message'=>'Invalid end_date'],400);
            $fields[] = "end_date = :end"; $params[':end'] = $end;
        }
        if (empty($fields)) jsend(['success'=>false,'message'=>'No fields to update'],400);

        try {
            $db->beginTransaction();

            $sql = "UPDATE elections SET " . implode(", ", $fields) . " WHERE id = :id";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            // Recompute status for this election; if becomes active, end others
            $row = $db->prepare("SELECT start_date, end_date FROM elections WHERE id = ?");
            $row->execute([$id]);
            if ($r = $row->fetch(PDO::FETCH_ASSOC)) {
                $s = $r['start_date']; $e = $r['end_date'];
                $now = (new DateTime())->format('Y-m-d H:i:s');
                // FIXED: Correct status calculation logic
                $newStatus = ($now < $s) ? 'upcoming' : (($now <= $e) ? 'active' : 'ended');

                if ($newStatus === 'active') {
                    $db->prepare("UPDATE elections SET status = 'ended' WHERE status = 'active' AND id != ?")->execute([$id]);
                }
                $db->prepare("UPDATE elections SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
            }

            $db->commit();
            jsend(['success'=>true,'message'=>'Election updated']);
        } catch (Exception $e) {
            $db->rollBack();
            jsend(['success'=>false,'message'=>'Database error'],500);
        }

    } else {
        // ----- CREATE -----
        if (!$title || !$start_raw || !$end_raw) {
            jsend(['success'=>false,'message'=>'Missing title/start_date/end_date'],400);
        }
        $start = normalize_datetime($start_raw);
        $end   = normalize_datetime($end_raw);
        if (!$start || !$end) jsend(['success'=>false,'message'=>'Invalid date format'],400);
        if (strtotime($end) <= strtotime($start)) jsend(['success'=>false,'message'=>'End date must be after start date'],400);

        // Duplicate check: same title + start + end
        $dupStmt = $db->prepare("SELECT COUNT(*) as cnt FROM elections WHERE title = ? AND start_date = ? AND end_date = ?");
        $dupStmt->execute([$title, $start, $end]);
        $dup = $dupStmt->fetch(PDO::FETCH_ASSOC);
        if ($dup && intval($dup['cnt']) > 0) {
            jsend(['success'=>false,'message'=>'An identical election already exists'],409);
        }

        // compute status - FIXED: Correct status calculation logic
        $now = (new DateTime())->format('Y-m-d H:i:s');
        $status = ($now < $start) ? 'upcoming' : (($now <= $end) ? 'active' : 'ended');

        try {
            $db->beginTransaction();

            if ($status === 'active') {
                // ensure only one active at a time
                $db->prepare("UPDATE elections SET status = 'ended' WHERE status = 'active'")->execute();
            }

            $ins = $db->prepare("INSERT INTO elections (title, description, start_date, end_date, status, created_at) VALUES (:title,:desc,:start,:end,:status,NOW())");
            $ok = $ins->execute([
                ':title'=>$title, ':desc'=>$description, ':start'=>$start, ':end'=>$end, ':status'=>$status
            ]);

            $db->commit();
            jsend(['success'=>true,'message'=>'Election created']);
        } catch (PDOException $e) {
            $db->rollBack();
            if ($e->getCode() === '23000') {
                jsend(['success'=>false,'message'=>'Duplicate or constraint error'],409);
            }
            jsend(['success'=>false,'message'=>'Database error'],500);
        }
    }
}

// PUT/PATCH (kept for API completeness; frontend can still use POST)
if ($method === 'PUT' || $method === 'PATCH') {
    if (!$id) jsend(['success'=>false,'message'=>'Missing id'],400);
    $input = get_json_input();
    if (!is_array($input)) {
        parse_str(file_get_contents('php://input'), $input);
    }

    $title = isset($input['title']) ? trim($input['title']) : null;
    $description = isset($input['description']) ? trim($input['description']) : null;
    $start_raw = $input['start_date'] ?? null;
    $end_raw = $input['end_date'] ?? null;

    $fields = []; $params = [':id'=>$id];
    if ($title !== null) { $fields[] = "title = :title"; $params[':title'] = $title; }
    if ($description !== null) { $fields[] = "description = :desc"; $params[':desc'] = $description; }
    if ($start_raw !== null) {
        $start = normalize_datetime($start_raw);
        if (!$start) jsend(['success'=>false,'message'=>'Invalid start_date'],400);
        $fields[] = "start_date = :start"; $params[':start'] = $start;
    }
    if ($end_raw !== null) {
        $end = normalize_datetime($end_raw);
        if (!$end) jsend(['success'=>false,'message'=>'Invalid end_date'],400);
        $fields[] = "end_date = :end"; $params[':end'] = $end;
    }
    if (empty($fields)) jsend(['success'=>false,'message'=>'No fields to update'],400);

    try {
        $db->beginTransaction();
        $sql = "UPDATE elections SET " . implode(", ", $fields) . " WHERE id = :id";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        $stmt2 = $db->prepare("SELECT start_date, end_date FROM elections WHERE id = ? LIMIT 1");
        $stmt2->execute([$id]);
        if ($row = $stmt2->fetch(PDO::FETCH_ASSOC)) {
            $s = $row['start_date']; $e = $row['end_date'];
            $now = (new DateTime())->format('Y-m-d H:i:s');
            // FIXED: Correct status calculation logic
            $newStatus = ($now < $s) ? 'upcoming' : (($now <= $e) ? 'active' : 'ended');

            if ($newStatus === 'active') {
                $db->prepare("UPDATE elections SET status = 'ended' WHERE status = 'active' AND id != ?")->execute([$id]);
            }
            $db->prepare("UPDATE elections SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
        }

        $db->commit();
        jsend(['success'=>true,'message'=>'Election updated']);
    } catch (Exception $e) {
        $db->rollBack();
        jsend(['success'=>false,'message'=>'Database error'],500);
    }
}

// DELETE (works with POST + _method=DELETE)
if ($method === 'DELETE') {
    if (!$id) jsend(['success'=>false,'message'=>'Missing id'],400);
    try {
        $stmt = $db->prepare("DELETE FROM elections WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->rowCount() === 0) jsend(['success'=>false,'message'=>'Not found'],404);
        jsend(['success'=>true,'message'=>'Election deleted']);
    } catch (Exception $e) {
        jsend(['success'=>false,'message'=>'Database error'],500);
    }
}

jsend(['success'=>false,'message'=>'Method not allowed'],405);