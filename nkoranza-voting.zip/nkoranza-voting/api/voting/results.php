<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

ob_start();

try {
    require_once __DIR__ . '/../../config/bootstrap.php';
    
    if (empty($_GET['election_id'])) {
        throw new Exception('Election ID is required');
    }
    
    $election_id = (int)$_GET['election_id'];
    $db = Database::getInstance()->getConnection();
    
    // Get election details
    $electionStmt = $db->prepare('SELECT id, title, description, start_date, end_date FROM elections WHERE id = ?');
    $electionStmt->execute([$election_id]);
    $election = $electionStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$election) {
        throw new Exception('Election not found');
    }
    
    // Check if export is requested
    $export = isset($_GET['export']) && $_GET['export'] == '1';
    $format = isset($_GET['format']) ? $_GET['format'] : 'csv';
    $includeSummary = !isset($_GET['summary']) || $_GET['summary'] == '1';
    $includeCandidates = !isset($_GET['candidates']) || $_GET['candidates'] == '1';
    $includeCharts = isset($_GET['charts']) && $_GET['charts'] == '1';
    
    // Get total number of eligible voters (only verified voters)
    $votersStmt = $db->prepare('SELECT COUNT(*) as total_voters FROM users WHERE is_admin = 0');
    $votersStmt->execute();
    $totalVoters = $votersStmt->fetch(PDO::FETCH_ASSOC)['total_voters'];
    
    // Get positions for this election
    $positionsStmt = $db->prepare('SELECT id, name, description, category FROM positions WHERE election_id = ? ORDER BY name');
    $positionsStmt->execute([$election_id]);
    $positions = $positionsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total number of distinct voters who have cast votes in this election
    $votesCastStmt = $db->prepare('SELECT COUNT(DISTINCT voter_id) as total_votes_cast FROM votes WHERE election_id = ?');
    $votesCastStmt->execute([$election_id]);
    $totalVotesCast = $votesCastStmt->fetch(PDO::FETCH_ASSOC)['total_votes_cast'];
    
    if (empty($positions)) {
        if ($export) {
            handleExportResponse($format, $election, [], $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates, $includeCharts);
            exit;
        }
        
        echo json_encode([
            'success' => true,
            'positions' => [],
            'total_voters' => $totalVoters,
            'total_votes_cast' => $totalVotesCast,
            'turnout_rate' => $totalVoters > 0 ? round(($totalVotesCast / $totalVoters) * 100, 1) : 0,
            'message' => 'No positions found for this election'
        ]);
        exit;
    }
    
    $results = [];
    
    foreach ($positions as $position) {
        $candidatesStmt = $db->prepare('
            SELECT 
                c.id,
                u.first_name,
                u.last_name,
                u.department,
                c.photo_path,
                c.manifesto,
                COUNT(v.id) as votes
            FROM candidates c
            INNER JOIN users u ON c.user_id = u.id
            LEFT JOIN votes v ON c.id = v.candidate_id AND v.election_id = ? AND v.position_id = ?
            WHERE c.position_id = ?
            GROUP BY c.id, u.first_name, u.last_name, u.department, c.photo_path, c.manifesto
            ORDER BY votes DESC
        ');
        $candidatesStmt->execute([$election_id, $position['id'], $position['id']]);
        $candidates = $candidatesStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $totalVotes = array_sum(array_column($candidates, 'votes'));
        
        $candidatesWithPercentage = array_map(function($candidate) use ($totalVotes) {
            $percentage = $totalVotes > 0 ? ($candidate['votes'] / $totalVotes) * 100 : 0;
            return [
                'id' => $candidate['id'],
                'name' => $candidate['first_name'] . ' ' . $candidate['last_name'],
                'department' => $candidate['department'],
                'photo_path' => formatPhotoPath($candidate['photo_path']),
                'manifesto' => $candidate['manifesto'],
                'votes' => (int)$candidate['votes'],
                'percentage' => round($percentage, 1)
            ];
        }, $candidates);
        
        $results[] = [
            'id' => $position['id'],
            'name' => $position['name'],
            'description' => $position['description'],
            'category' => $position['category'],
            'total_votes' => $totalVotes,
            'candidates' => $candidatesWithPercentage
        ];
    }
    
    // Handle export request
    if ($export) {
        handleExportResponse($format, $election, $results, $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates, $includeCharts);
        exit;
    }
    
    ob_clean();
    
    echo json_encode([
        'success' => true,
        'positions' => $results,
        'election' => $election,
        'total_voters' => $totalVoters,
        'total_votes_cast' => $totalVotesCast,
        'turnout_rate' => $totalVoters > 0 ? round(($totalVotesCast / $totalVoters) * 100, 1) : 0
    ]);
    
} catch (Exception $e) {
    ob_clean();
    
    error_log("Results API Error: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    
    if (isset($export) && $export) {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="error.txt"');
        echo "Error: " . $e->getMessage() . "\n";
        exit;
    }
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Error retrieving results: ' . $e->getMessage(),
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ]);
} finally {
    ob_end_flush();
}

function handleExportResponse($format, $election, $positions, $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates, $includeCharts) {
    switch ($format) {
        case 'excel':
            exportExcel($election, $positions, $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates);
            break;
        case 'pdf':
            exportPDF($election, $positions, $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates, $includeCharts);
            break;
        case 'csv':
        default:
            exportCSV($election, $positions, $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates);
            break;
    }
}

function exportCSV($election, $positions, $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="election_' . $election['id'] . '_results.csv"');
    
    $output = fopen('php://output', 'w');
    
    // Add BOM for UTF-8 compatibility with Excel
    fwrite($output, "\xEF\xBB\xBF");
    
    if ($includeSummary) {
        // Election summary
        fputcsv($output, ['Election Results Export']);
        fputcsv($output, ['Election:', $election['title']]);
        fputcsv($output, ['Description:', $election['description']]);
        fputcsv($output, ['Start Date:', $election['start_date']]);
        fputcsv($output, ['End Date:', $election['end_date']]);
        fputcsv($output, ['Total Voters:', $totalVoters]);
        fputcsv($output, ['Total Votes Cast:', $totalVotesCast]);
        fputcsv($output, ['Turnout Rate:', ($totalVoters > 0 ? round(($totalVotesCast / $totalVoters) * 100, 1) : 0) . '%']);
        fputcsv($output, []); // Empty row
    }
    
    if ($includeCandidates && !empty($positions)) {
        // Positions and candidates
        foreach ($positions as $position) {
            fputcsv($output, ['Position:', $position['name']]);
            if (!empty($position['category'])) {
                fputcsv($output, ['Category:', $position['category']]);
            }
            if (!empty($position['description'])) {
                fputcsv($output, ['Description:', $position['description']]);
            }
            fputcsv($output, ['Total Votes:', $position['total_votes']]);
            fputcsv($output, []); // Empty row
            
            // Candidate headers
            fputcsv($output, ['Rank', 'Candidate Name', 'Department', 'Votes', 'Percentage', 'Status']);
            
            // Find winner(s)
            $maxVotes = max(array_column($position['candidates'], 'votes'));
            $winners = array_filter($position['candidates'], function($candidate) use ($maxVotes) {
                return $candidate['votes'] === $maxVotes;
            });
            $isTie = count($winners) > 1;
            
            // Candidate data
            $rank = 1;
            foreach ($position['candidates'] as $candidate) {
                $status = '';
                if ($candidate['votes'] === $maxVotes) {
                    $status = $isTie ? 'Tied' : 'Winner';
                }
                
                fputcsv($output, [
                    $rank++,
                    $candidate['name'],
                    $candidate['department'] ?? '',
                    $candidate['votes'],
                    $candidate['percentage'] . '%',
                    $status
                ]);
            }
            
            fputcsv($output, []); // Empty row between positions
            fputcsv($output, []); // Empty row between positions
        }
    }
    
    fclose($output);
}

function exportExcel($election, $positions, $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates) {
    // For Excel, we'll create a CSV with semicolon separator which works better in some European Excel versions
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="election_' . $election['id'] . '_results.csv"');
    
    $output = fopen('php://output', 'w');
    
    // Add BOM for UTF-8 compatibility with Excel
    fwrite($output, "\xEF\xBB\xBF");
    
    if ($includeSummary) {
        // Election summary
        fputcsv($output, ['Election Results Export'], ';');
        fputcsv($output, ['Election', $election['title']], ';');
        fputcsv($output, ['Description', $election['description']], ';');
        fputcsv($output, ['Start Date', $election['start_date']], ';');
        fputcsv($output, ['End Date', $election['end_date']], ';');
        fputcsv($output, ['Total Voters', $totalVoters], ';');
        fputcsv($output, ['Total Votes Cast', $totalVotesCast], ';');
        fputcsv($output, ['Turnout Rate', ($totalVoters > 0 ? round(($totalVotesCast / $totalVoters) * 100, 1) : 0) . '%'], ';');
        fputcsv($output, [], ';'); // Empty row
    }
    
    if ($includeCandidates && !empty($positions)) {
        // Positions and candidates
        foreach ($positions as $position) {
            fputcsv($output, ['Position', $position['name']], ';');
            if (!empty($position['category'])) {
                fputcsv($output, ['Category', $position['category']], ';');
            }
            if (!empty($position['description'])) {
                fputcsv($output, ['Description', $position['description']], ';');
            }
            fputcsv($output, ['Total Votes', $position['total_votes']], ';');
            fputcsv($output, [], ';'); // Empty row
            
            // Candidate headers
            fputcsv($output, ['Rank', 'Candidate Name', 'Department', 'Votes', 'Percentage', 'Status'], ';');
            
            // Find winner(s)
            $maxVotes = max(array_column($position['candidates'], 'votes'));
            $winners = array_filter($position['candidates'], function($candidate) use ($maxVotes) {
                return $candidate['votes'] === $maxVotes;
            });
            $isTie = count($winners) > 1;
            
            // Candidate data
            $rank = 1;
            foreach ($position['candidates'] as $candidate) {
                $status = '';
                if ($candidate['votes'] === $maxVotes) {
                    $status = $isTie ? 'Tied' : 'Winner';
                }
                
                fputcsv($output, [
                    $rank++,
                    $candidate['name'],
                    $candidate['department'] ?? '',
                    $candidate['votes'],
                    $candidate['percentage'] . '%',
                    $status
                ], ';');
            }
            
            fputcsv($output, [], ';'); // Empty row between positions
            fputcsv($output, [], ';'); // Empty row between positions
        }
    }
    
    fclose($output);
}

function exportPDF($election, $positions, $totalVoters, $totalVotesCast, $includeSummary, $includeCandidates, $includeCharts) {
    // For PDF export, we would typically use a library like TCPDF or Dompdf
    // This is a simplified version that returns HTML that can be converted to PDF
    
    header('Content-Type: text/html');
    header('Content-Disposition: attachment; filename="election_' . $election['id'] . '_results.html"');
    
    // This HTML can be saved and converted to PDF using browser print or a PDF library
    echo '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Election Results - ' . htmlspecialchars($election['title']) . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            h1 { color: #333; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .summary { background-color: #f9f9f9; padding: 15px; margin-bottom: 20px; }
            .position { margin-bottom: 30px; }
        </style>
    </head>
    <body>
        <h1>Election Results: ' . htmlspecialchars($election['title']) . '</h1>';
        
        if ($includeSummary) {
            echo '<div class="summary">
                <h2>Election Summary</h2>
                <p><strong>Description:</strong> ' . htmlspecialchars($election['description']) . '</p>
                <p><strong>Start Date:</strong> ' . htmlspecialchars($election['start_date']) . '</p>
                <p><strong>End Date:</strong> ' . htmlspecialchars($election['end_date']) . '</p>
                <p><strong>Total Voters:</strong> ' . $totalVoters . '</p>
                <p><strong>Total Votes Cast:</strong> ' . $totalVotesCast . '</p>
                <p><strong>Turnout Rate:</strong> ' . ($totalVoters > 0 ? round(($totalVotesCast / $totalVoters) * 100, 1) : 0) . '%</p>
            </div>';
        }
        
        if ($includeCandidates && !empty($positions)) {
            foreach ($positions as $position) {
                echo '<div class="position">
                    <h2>' . htmlspecialchars($position['name']) . '</h2>';
                    
                if (!empty($position['category'])) {
                    echo '<p><strong>Category:</strong> ' . htmlspecialchars($position['category']) . '</p>';
                }
                
                if (!empty($position['description'])) {
                    echo '<p><strong>Description:</strong> ' . htmlspecialchars($position['description']) . '</p>';
                }
                
                echo '<p><strong>Total Votes:</strong> ' . $position['total_votes'] . '</p>
                    <table>
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Candidate Name</th>
                                <th>Department</th>
                                <th>Votes</th>
                                <th>Percentage</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>';
                
                // Find winner(s)
                $maxVotes = max(array_column($position['candidates'], 'votes'));
                $winners = array_filter($position['candidates'], function($candidate) use ($maxVotes) {
                    return $candidate['votes'] === $maxVotes;
                });
                $isTie = count($winners) > 1;
                
                $rank = 1;
                foreach ($position['candidates'] as $candidate) {
                    $status = '';
                    if ($candidate['votes'] === $maxVotes) {
                        $status = $isTie ? 'Tied' : 'Winner';
                    }
                    
                    echo '<tr>
                        <td>' . $rank++ . '</td>
                        <td>' . htmlspecialchars($candidate['name']) . '</td>
                        <td>' . htmlspecialchars($candidate['department'] ?? '') . '</td>
                        <td>' . $candidate['votes'] . '</td>
                        <td>' . $candidate['percentage'] . '%</td>
                        <td>' . $status . '</td>
                    </tr>';
                }
                
                echo '</tbody>
                    </table>
                </div>';
            }
        }
        
        if ($includeCharts) {
            echo '<div style="page-break-before: always;">
                <h2>Charts</h2>
                <p>Note: Charts would be generated here in a full implementation using a PDF library with chart support.</p>
            </div>';
        }
        
    echo '</body>
    </html>';
}

function formatPhotoPath($path) {
    if (!$path) return null;
    if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
    
    $cleanPath = ltrim($path, '/');
    $cleanPath = str_replace('../', '', $cleanPath);
    return BASE_URL . '/' . $cleanPath;
}
?>