<?php
// Enable CORS for development
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Start output buffering to catch any accidental output
ob_start();

try {
    // Include configuration - use relative paths
    require_once __DIR__ . '/../../config/bootstrap.php';
    
    // Set JSON header
    header('Content-Type: application/json');
    
    // Get election ID from query parameter
    $electionId = isset($_GET['election_id']) ? (int)$_GET['election_id'] : 0;
    
    if ($electionId <= 0) {
        throw new Exception('Valid election ID is required');
    }
    
    // Get database connection
    $db = Database::getInstance()->getConnection();
    
    // Check if election exists and is active
    $checkStmt = $db->prepare("SELECT id, title FROM elections WHERE id = ? AND status = 'active'");
    $checkStmt->execute([$electionId]);
    $election = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$election) {
        throw new Exception("Active election with ID $electionId not found");
    }
    
    // Get positions for the election
    $stmt = $db->prepare("
        SELECT id, name, description, category 
        FROM positions 
        WHERE election_id = ? 
        ORDER BY category, name
    ");
    
    $stmt->execute([$electionId]);
    $positions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Clear any accidental output
    ob_clean();
    
    // Return successful response
    echo json_encode([
        'success' => true,
        'positions' => $positions,
        'count' => count($positions),
        'election_id' => $electionId,
        'election_title' => $election['title']
    ]);
    
} catch (Exception $e) {
    // Clear any accidental output
    ob_clean();
    
    // Log the error
    error_log("Positions API Error: " . $e->getMessage());
    
    // Return error response
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to fetch positions',
        'error' => $e->getMessage(),
        'debug' => [
            'election_id' => $electionId ?? 'not set',
            'timestamp' => date('Y-m-d H:i:s')
        ]
    ]);
} finally {
    // End output buffering
    ob_end_flush();
    exit;
}