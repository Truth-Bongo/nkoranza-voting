<?php
require_once __DIR__ . '/../../config/bootstrap.php';

session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Check if user is logged in
if (empty($_SESSION['user_id']) || empty($_SESSION['logged_in'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login to vote']);
    exit;
}

// CSRF token validation function
function validate_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    
    // Use timing-safe comparison
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);
$election_id = $input['election_id'] ?? null;
$votes = $input['votes'] ?? [];
$csrf_token = $input['csrf_token'] ?? '';

// Validate input
if (!$election_id || empty($votes)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid vote data']);
    exit;
}

// CSRF protection
if (!validate_csrf_token($csrf_token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid security token']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Check if user has already voted in this election
    $stmt = $db->prepare('SELECT id FROM votes WHERE voter_id = ? AND election_id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id'], $election_id]);
    
    if ($stmt->fetch()) {
        echo json_encode([
            'success' => false,
            'message' => 'You have already voted in this election'
        ]);
        exit;
    }
    
    // Begin transaction
    $db->beginTransaction();
    
    // Record each vote
    foreach ($votes as $position_id => $candidate_id) {
        $stmt = $db->prepare('
            INSERT INTO votes (voter_id, election_id, position_id, candidate_id, timestamp) 
            VALUES (?, ?, ?, ?, NOW())
        ');
        $stmt->execute([$_SESSION['user_id'], $election_id, $position_id, $candidate_id]);
    }
    
    // UPDATE: Set has_voted flag in users table
    $updateUserStmt = $db->prepare('UPDATE users SET has_voted = 1 WHERE id = ?');
    $updateUserStmt->execute([$_SESSION['user_id']]);
    
    // Commit transaction
    $db->commit();
    
    // Also update the session variable if needed
    $_SESSION['has_voted'] = true;
    
    echo json_encode([
        'success' => true,
        'message' => 'Vote submitted successfully'
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to submit vote: ' . $e->getMessage()
    ]);
}