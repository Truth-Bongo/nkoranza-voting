<?php
// Enable CORS for development
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Start output buffering to catch any accidental HTML output
ob_start();

try {
    require_once __DIR__ . '/../../config/bootstrap.php';
    
    header('Content-Type: application/json');
    
    $position_id = $_GET['position_id'] ?? null;
    
    if (!$position_id) {
        throw new Exception('Position ID is required');
    }
    
    $db = Database::getInstance()->getConnection();
    
    // Check if position exists
    $checkStmt = $db->prepare('SELECT id, name FROM positions WHERE id = ?');
    $checkStmt->execute([$position_id]);
    $position = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$position) {
        // Clear any accidental output
        ob_clean();
        
        echo json_encode([
            'success' => false,
            'message' => 'Position not found',
            'position_id' => $position_id
        ]);
        exit;
    }
    
    // Get candidates for the specified position
    $stmt = $db->prepare('
        SELECT 
            c.id, 
            c.user_id,
            c.manifesto, 
            c.photo_path,
            u.first_name, 
            u.last_name, 
            u.department, 
            u.level
        FROM candidates c 
        INNER JOIN users u ON c.user_id = u.id 
        WHERE c.position_id = ? 
        ORDER BY u.first_name, u.last_name
    ');
    $stmt->execute([$position_id]);
    $candidates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format photo URLs
    foreach ($candidates as &$candidate) {
        if ($candidate['photo_path'] && !filter_var($candidate['photo_path'], FILTER_VALIDATE_URL)) {
            // Remove any leading slashes or relative paths
            $cleanPath = ltrim($candidate['photo_path'], '/');
            $cleanPath = str_replace('../', '', $cleanPath);
            $candidate['photo_path'] = BASE_URL . '/' . $cleanPath;
        }
    }
    
    // Clear any accidental output
    ob_clean();
    
    echo json_encode([
        'success' => true,
        'position' => $position,
        'candidates' => $candidates,
        'count' => count($candidates)
    ]);
    
} catch (Exception $e) {
    // Clear any accidental output
    ob_clean();
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to fetch candidates',
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
} finally {
    // End output buffering
    ob_end_flush();
}