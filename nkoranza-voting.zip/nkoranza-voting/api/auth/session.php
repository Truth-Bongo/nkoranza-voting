<?php
require_once APP_ROOT . '/controllers/AuthController.php';

header('Content-Type: application/json');

try {
    $authController = new AuthController();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $response = $authController->checkSession();
        echo json_encode($response);
    } else {
        throw new Exception('Method not allowed', 405);
    }
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>