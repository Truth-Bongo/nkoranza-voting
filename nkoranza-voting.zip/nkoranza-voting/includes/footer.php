 <?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<script>
  window.BASE_URL = "<?= rtrim(BASE_URL, '/') ?>";
  window.CSRF_TOKEN = "<?= $_SESSION['csrf_token'] ?? generate_csrf_token() ?>";
</script>

 </main>

  <!-- Footer -->
  <footer class="bg-pink-900 text-white py-8">
    <div class="container mx-auto px-4">
      <div class="grid md:grid-cols-3 gap-8">
        <div>
          <h3 class="text-xl font-bold mb-4">Nkoranza SHTS</h3>
          <p class="text-gray-300">Empowering students through democratic processes and transparent elections.</p>
        </div>
        <div>
          <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
          <ul class="space-y-2">
            <li><a href="<?= BASE_URL ?>" class="text-gray-400 hover:text-white transition">Home</a></li>
            <li><a href="<?= BASE_URL ?>/vote" class="text-gray-400 hover:text-white transition">Vote</a></li>
            <li><a href="<?= BASE_URL ?>/results" class="text-gray-400 hover:text-white transition">Results</a></li>
            <li><a href="<?= BASE_URL ?>/contact" class="text-gray-400 hover:text-white transition">Contact</a></li>
          </ul>
        </div>
        <div>
          <h4 class="text-lg font-semibold mb-4">Contact Us</h4>
          <address class="text-gray-300 not-italic space-y-2">
            <p><i class="fas fa-map-marker-alt mr-2"></i> Nkoranza Senior High/Technical School, Ghana</p>
            <p><i class="fas fa-phone-alt mr-2"></i> +233 24 123 4567</p>
            <p><i class="fas fa-envelope mr-2"></i> election@nkoranzashts.edu.gh</p>
          </address>
        </div>
      </div>
      <div class="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400">
        <p>&copy; <?= date('Y') ?> Nkoranza Senior High Technical School. All rights reserved.</p>
      </div>
    </div>
  </footer>
</div> <!-- End of main wrapper -->
</body>
</html>
