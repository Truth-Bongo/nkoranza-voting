<?php
// bootstrap.php
require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/config/db_connect.php';
require_once __DIR__ . '/helpers/functions.php';

// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Authentication functions
if (!function_exists('require_login')) {
    function require_login() {
        if (empty($_SESSION['logged_in']) || !isset($_SESSION['user_id'])) {
            header("Location: " . BASE_URL . "/index.php?page=login");
            exit;
        }
    }
}

if (!function_exists('require_student_login')) {
    function require_student_login() {
        require_login();
        
        // Restrict admin access
        if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
            header("Location: " . BASE_URL . "/index.php?page=admin/dashboard");
            exit;
        }
    }
}

if (!function_exists('require_admin_login')) {
    function require_admin_login() {
        require_login();
        
        // Restrict non-admin access
        if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
            header("Location: " . BASE_URL . "/index.php?page=vote");
            exit;
        }
    }
}