<?php
require_once APP_ROOT . '/models/BaseModel.php';

class User extends BaseModel {
    public function __construct() {
        parent::__construct('users');
    }
    
    public function authenticate($id, $password) {
        $sql = "SELECT * FROM users WHERE id = ?";
        $stmt = $this->executeQuery($sql, [$id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user || !password_verify($password, $user['password'])) {
            throw new Exception("Invalid credentials");
        }
        
        return $user;
    }
    
    public function create($data) {
        $this->validateFields($data, ['id', 'password', 'first_name', 'last_name', 'department', 'level']);
        
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        $data['is_admin'] = $data['is_admin'] ?? false;
        
        $sql = "INSERT INTO users (id, password, first_name, last_name, department, level, email, is_admin) 
                VALUES (:id, :password, :first_name, :last_name, :department, :level, :email, :is_admin)";
        
        $this->executeQuery($sql, $data);
        return $data['id'];
    }
    
    public function markAsVoted($userId) {
        $sql = "UPDATE users SET has_voted = TRUE WHERE id = ?";
        $this->executeQuery($sql, [$userId]);
    }
    
    public function getVoters($page = 1, $perPage = 10, $search = null) {
        $offset = ($page - 1) * $perPage;
        $params = [$perPage, $offset];
        
        $sql = "SELECT id, first_name, last_name, department, level, has_voted 
                FROM users WHERE is_admin = FALSE";
                
        if ($search) {
            $sql .= " AND (id LIKE ? OR first_name LIKE ? OR last_name LIKE ?)";
            $searchTerm = "%$search%";
            array_push($params, $searchTerm, $searchTerm, $searchTerm);
        }
        
        $sql .= " LIMIT ? OFFSET ?";
        $stmt = $this->executeQuery($sql, $params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function importFromCSV($filePath) {
        // Implementation for CSV import
    }
}
?>