<?php
require_once APP_ROOT . '/models/BaseModel.php';

class Election extends BaseModel {
    public function __construct() {
        parent::__construct('elections');
    }
    
    public function create($data) {
        $this->validateFields($data, ['title', 'start_date', 'end_date']);
        
        $sql = "INSERT INTO elections (title, description, start_date, end_date) 
                VALUES (:title, :description, :start_date, :end_date)";
        
        $this->executeQuery($sql, $data);
        return $this->db->lastInsertId();
    }
    
    public function update($id, $data) {
        $this->validateFields($data, ['title', 'start_date', 'end_date']);
        $data['id'] = $id;
        
        $sql = "UPDATE elections SET 
                title = :title, 
                description = :description, 
                start_date = :start_date, 
                end_date = :end_date 
                WHERE id = :id";
        
        $this->executeQuery($sql, $data);
    }
    
    public function getActive() {
        $sql = "SELECT * FROM elections 
                WHERE start_date <= NOW() AND end_date >= NOW() 
                ORDER BY start_date DESC";
        $stmt = $this->executeQuery($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getByStatus($status) {
        $sql = "SELECT * FROM elections WHERE ";
        
        switch ($status) {
            case 'active':
                $sql .= "start_date <= NOW() AND end_date >= NOW()";
                break;
            case 'upcoming':
                $sql .= "start_date > NOW()";
                break;
            case 'ended':
                $sql .= "end_date < NOW()";
                break;
            default:
                throw new Exception("Invalid status filter");
        }
        
        $sql .= " ORDER BY start_date DESC";
        $stmt = $this->executeQuery($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function updateStatuses() {
        // Update status for all elections based on current time
        $this->executeQuery("
            UPDATE elections SET 
            status = CASE 
                WHEN NOW() < start_date THEN 'upcoming'
                WHEN NOW() BETWEEN start_date AND end_date THEN 'active'
                ELSE 'ended'
            END
        ");
    }
}
?>