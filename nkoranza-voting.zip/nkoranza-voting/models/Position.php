<?php
require_once APP_ROOT . '/models/BaseModel.php';

class Position extends BaseModel {
    public function __construct() {
        parent::__construct('positions');
    }
    
    public function create($data) {
        $this->validateFields($data, ['election_id', 'name']);
        
        $sql = "INSERT INTO positions (election_id, name) VALUES (:election_id, :name)";
        $this->executeQuery($sql, $data);
        return $this->db->lastInsertId();
    }
    
    public function getByElection($electionId) {
        $sql = "SELECT * FROM positions WHERE election_id = ? ORDER BY name";
        $stmt = $this->executeQuery($sql, [$electionId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getWithCandidateCount($electionId) {
        $sql = "SELECT p.*, COUNT(c.id) as candidate_count 
                FROM positions p
                LEFT JOIN candidates c ON p.id = c.position_id
                WHERE p.election_id = ?
                GROUP BY p.id
                ORDER BY p.name";
        $stmt = $this->executeQuery($sql, [$electionId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>