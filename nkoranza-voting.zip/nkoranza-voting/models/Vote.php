<?php
require_once APP_ROOT . '/models/BaseModel.php';

class Vote extends BaseModel {
    public function __construct() {
        parent::__construct('votes');
    }
    
    public function create($data) {
        $this->validateFields($data, ['election_id', 'position_id', 'candidate_id', 'voter_id']);
        
        $sql = "INSERT INTO votes (election_id, position_id, candidate_id, voter_id) 
                VALUES (:election_id, :position_id, :candidate_id, :voter_id)";
        
        $this->executeQuery($sql, $data);
        return $this->db->lastInsertId();
    }
    
    public function hasVoted($electionId, $voterId) {
        $sql = "SELECT 1 FROM votes WHERE election_id = ? AND voter_id = ? LIMIT 1";
        $stmt = $this->executeQuery($sql, [$electionId, $voterId]);
        return $stmt->rowCount() > 0;
    }
    
    public function getResultsByElection($electionId) {
        // Get election details
        $electionModel = new Election();
        $election = $electionModel->getById($electionId);
        
        if (!$election) {
            throw new Exception("Election not found");
        }
        
        // Get positions for this election
        $positionModel = new Position();
        $positions = $positionModel->getByElection($electionId);
        
        // Get results for each position
        $results = [];
        $totalVotesCast = 0;
        
        foreach ($positions as $position) {
            $sql = "SELECT 
                    c.id as candidate_id,
                    u.first_name || ' ' || u.last_name as candidate_name,
                    u.department,
                    COUNT(v.id) as votes,
                    COUNT(v.id) * 100.0 / (SELECT COUNT(*) FROM votes WHERE position_id = ?) as percentage
                FROM candidates c
                JOIN users u ON c.user_id = u.id
                LEFT JOIN votes v ON c.id = v.candidate_id
                WHERE c.position_id = ?
                GROUP BY c.id, u.first_name, u.last_name, u.department
                ORDER BY votes DESC";
            
            $stmt = $this->executeQuery($sql, [$position['id'], $position['id']]);
            $candidates = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Calculate total votes for this position
            $positionVotes = array_sum(array_column($candidates, 'votes'));
            $totalVotesCast += $positionVotes;
            
            $results[] = [
                'position_id' => $position['id'],
                'position_name' => $position['name'],
                'candidates' => $candidates,
                'total_votes' => $positionVotes
            ];
        }
        
        return [
            'election' => $election,
            'positions' => $results,
            'total_votes_cast' => $totalVotesCast,
            'total_registered_voters' => (new User())->count()
        ];
    }
}
?>