<?php
require_once APP_ROOT . '/config/db_connect.php';

abstract class BaseModel {
    protected $db;
    protected $table;
    
    public function __construct($table) {
        $this->db = Database::getInstance()->getConnection();
        $this->table = $table;
    }
    
    protected function executeQuery($sql, $params = []) {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            throw new Exception("Database operation failed");
        }
    }
    
    public function getById($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        $stmt = $this->executeQuery($sql, [$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getAll($page = 1, $perPage = 10) {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT * FROM {$this->table} LIMIT ? OFFSET ?";
        $stmt = $this->executeQuery($sql, [$perPage, $offset]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function count() {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}";
        $stmt = $this->executeQuery($sql);
        return $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    }
    
    protected function validateFields($data, $requiredFields) {
        $missing = array_diff($requiredFields, array_keys($data));
        if (!empty($missing)) {
            throw new Exception("Missing required fields: " . implode(', ', $missing));
        }
    }
}
?>