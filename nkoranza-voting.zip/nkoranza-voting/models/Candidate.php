<?php
require_once APP_ROOT . '/models/BaseModel.php';

class Candidate extends BaseModel {
    public function __construct() {
        parent::__construct('candidates');
    }
    
    public function create($data) {
        $this->validateFields($data, ['position_id', 'user_id']);
        
        $sql = "INSERT INTO candidates (position_id, user_id, manifesto, photo_path) 
                VALUES (:position_id, :user_id, :manifesto, :photo_path)";
        
        $this->executeQuery($sql, $data);
        return $this->db->lastInsertId();
    }
    
    public function getByPosition($positionId) {
        $sql = "SELECT c.*, u.first_name, u.last_name, u.department 
                FROM candidates c
                JOIN users u ON c.user_id = u.id
                WHERE c.position_id = ?";
        $stmt = $this->executeQuery($sql, [$positionId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getAllWithDetails() {
        $sql = "SELECT c.*, u.first_name, u.last_name, u.department, p.name as position_name, e.title as election_title
                FROM candidates c
                JOIN users u ON c.user_id = u.id
                JOIN positions p ON c.position_id = p.id
                JOIN elections e ON p.election_id = e.id
                ORDER BY e.start_date DESC, p.name";
        $stmt = $this->executeQuery($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getVoteCount($candidateId) {
        $sql = "SELECT COUNT(*) as vote_count FROM votes WHERE candidate_id = ?";
        $stmt = $this->executeQuery($sql, [$candidateId]);
        return $stmt->fetch(PDO::FETCH_ASSOC)['vote_count'];
    }
}
?>