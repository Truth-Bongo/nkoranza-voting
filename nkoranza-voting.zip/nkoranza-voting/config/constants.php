<?php
// config/constants.php

// Database (change values as needed)
if (!defined('DB_HOST')) define('DB_HOST', '127.0.0.1');
if (!defined('DB_NAME')) define('DB_NAME', 'nkoranza_voting');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');

// App paths
if (!defined('APP_ROOT')) define('APP_ROOT', dirname(__DIR__));
if (!defined('BASE_URL')) define('BASE_URL', 'http://localhost/nkoranza-voting');

// Default image
if (!defined('DEFAULT_USER_IMAGE')) define('DEFAULT_USER_IMAGE', BASE_URL . '/assets/images/default-user.jpg');

// CSRF secret (you may rotate)
if (!defined('CSRF_TOKEN_SECRET')) define('CSRF_TOKEN_SECRET', 'change_this_secret_to_something_random');
