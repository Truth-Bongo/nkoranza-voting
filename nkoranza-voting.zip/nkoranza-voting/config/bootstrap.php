<?php
// Load constants (only once)
if (!defined('DB_HOST')) {
    require_once __DIR__ . '/constants.php';
}

// Load helper functions
$helpersFile = __DIR__ . '/../helpers/functions.php';
if (file_exists($helpersFile)) {
    require_once $helpersFile;
}

// Load database class
require_once __DIR__ . '/db_connect.php';

