<?php
// helpers/functions.php

// CSRF Token
if (!function_exists('generate_csrf_token')) {
    function generate_csrf_token() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('validate_csrf_token')) {
    function validate_csrf_token($token) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
}

if (!function_exists('request_csrf_token')) {
    function request_csrf_token() {
        return $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? null;
    }
}

// Input sanitization
if (!function_exists('sanitize_input')) {
    function sanitize_input($data) {
        if (is_array($data)) {
            return array_map('sanitize_input', $data);
        }
        return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
    }
}

// JSON response helper
if (!function_exists('json_response')) {
    function json_response($success, $message = '', $data = null) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => $success,
            'message' => $message,
            'data'    => $data
        ]);
        exit;
    }
}

// Request payload
if (!function_exists('request_payload')) {
    function request_payload() {
        return json_decode(file_get_contents('php://input'), true);
    }
}

// Date formatting
if (!function_exists('formatDate')) {
    function formatDate($date, $format = 'M d, Y H:i') {
        return date($format, strtotime($date));
    }
}

// Election status refresher
if (!function_exists('refresh_election_statuses')) {
    function refresh_election_statuses($db) {
        $db->query("UPDATE elections 
                    SET status = CASE 
                        WHEN NOW() < start_date THEN 'upcoming'
                        WHEN NOW() BETWEEN start_date AND end_date THEN 'active'
                        WHEN NOW() > end_date THEN 'closed'
                    END");
    }
}

// Authentication helpers
function require_login() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (empty($_SESSION['user_id'])) {
        $_SESSION['flash_message'] = 'Please login to access this page';
        $_SESSION['flash_type'] = 'error';
        header('Location: ' . BASE_URL . '/login');
        exit;
    }
}

function require_admin() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (empty($_SESSION['user_id'])) {
        $_SESSION['flash_message'] = 'Please login to access this page';
        $_SESSION['flash_type'] = 'error';
        header('Location: ' . BASE_URL . '/login');
        exit;
    }
    
    if (empty($_SESSION['is_admin'])) {
        $_SESSION['flash_message'] = 'Access denied. Admin privileges required';
        $_SESSION['flash_type'] = 'error';
        header('Location: ' . BASE_URL . '/home');
        exit;
    }
}

function is_logged_in() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return !empty($_SESSION['user_id']);
}

function is_admin() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return !empty($_SESSION['user_id']) && !empty($_SESSION['is_admin']);
}

// Flash message helpers
function set_flash_message($message, $type = 'success') {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
}

function get_flash_message() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $message = $_SESSION['flash_message'] ?? '';
    $type = $_SESSION['flash_type'] ?? '';
    unset($_SESSION['flash_message'], $_SESSION['flash_type']);
    return ['message' => $message, 'type' => $type];
}

// Redirect helper
function redirect($url) {
    header('Location: ' . BASE_URL . '/' . ltrim($url, '/'));
    exit;
}

// Password validation
function validate_password($password) {
    // At least 8 characters, 1 uppercase, 1 lowercase, 1 number
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password);
}

// Email validation
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Generate random string
function generate_random_string($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

// File upload helper
function handle_file_upload($file, $allowed_types = [], $max_size = 2097152) {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload error'];
    }
    
    if ($file['size'] > $max_size) {
        return ['success' => false, 'message' => 'File too large'];
    }
    
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!empty($allowed_types) && !in_array($file_ext, $allowed_types)) {
        return ['success' => false, 'message' => 'Invalid file type'];
    }
    
    $new_filename = uniqid() . '.' . $file_ext;
    $upload_path = APP_ROOT . '/uploads/' . $new_filename;
    
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        return ['success' => true, 'filename' => $new_filename];
    }
    
    return ['success' => false, 'message' => 'Failed to move uploaded file'];
}

// Database error handler
function handle_database_error($e) {
    error_log("Database Error: " . $e->getMessage());
    if (defined('ENVIRONMENT') && ENVIRONMENT === 'development') {
        return "Database error: " . $e->getMessage();
    }
    return "A database error occurred. Please try again later.";
}

// Check if election is active
function is_election_active($election_id, $db) {
    $stmt = $db->prepare("SELECT status FROM elections WHERE id = :id");
    $stmt->execute([':id' => $election_id]);
    $election = $stmt->fetch(PDO::FETCH_ASSOC);
    return $election && $election['status'] === 'active';
}

// Check if user has voted in election
function has_user_voted($user_id, $election_id, $db) {
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM votes WHERE user_id = :user_id AND election_id = :election_id");
    $stmt->execute([
        ':user_id' => $user_id,
        ':election_id' => $election_id
    ]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['count'] > 0;
}

// Get user votes count
function get_user_votes_count($user_id, $db) {
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM votes WHERE user_id = :user_id");
    $stmt->execute([':user_id' => $user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['count'];
}

// Get election results
function get_election_results($election_id, $db) {
    $stmt = $db->prepare("
        SELECT c.id, c.name, c.position, COUNT(v.id) as votes
        FROM candidates c
        LEFT JOIN votes v ON c.id = v.candidate_id
        WHERE c.election_id = :election_id
        GROUP BY c.id, c.name, c.position
        ORDER BY c.position, votes DESC
    ");
    $stmt->execute([':election_id' => $election_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get active elections
function get_active_elections($db) {
    $stmt = $db->query("SELECT * FROM elections WHERE status = 'active' ORDER BY start_date ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get upcoming elections
function get_upcoming_elections($db) {
    $stmt = $db->query("SELECT * FROM elections WHERE status = 'upcoming' ORDER BY start_date ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get closed elections
function get_closed_elections($db) {
    $stmt = $db->query("SELECT * FROM elections WHERE status = 'closed' ORDER BY end_date DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}